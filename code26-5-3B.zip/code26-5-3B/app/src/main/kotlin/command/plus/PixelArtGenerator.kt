package command.plus

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import androidx.core.graphics.ColorUtils
import java.io.File
import java.io.FileOutputStream
import java.io.FileWriter
import java.util.concurrent.Executors
import kotlin.math.pow
import kotlin.math.sqrt
import android.widget.Toast
import java.util.HashSet;
import java.util.Arrays;

// 支持的抖动算法
enum class DitherAlgorithm {
    NONE,           // 无抖动
    FLOYD_STEINBERG,// Floyd-Steinberg 误差扩散
    BAYER_2x2,      // Bayer 2x2 有序抖动
    BAYER_4x4,      // Bayer 4x4 有序抖动
    BAYER_8x8,      // Bayer 8x8 有序抖动
    ORDERED_3x3,    // Ordered 3x3 聚集点抖动
    ATKINSON,       // Atkinson 误差扩散
    SIERRA,         // Sierra3 误差扩散
    STUCKI,         // Stucki 误差扩散
    BURKES          // Burkes 误差扩散
}

// 支持的色彩空间
enum class ColorSpace {
    RGB, HSV, LAB
}

// 颜色数据类
private class BlockData(
    val id: String,
    val bitmap: Bitmap?,
    val rgb: FloatArray,
    val hsv: FloatArray,
    val lab: DoubleArray
)

class PixelArtGenerator private constructor(
    private val inputImageFile: File,
    private val outputDir: File,
    private val textureFiles: List<File>,
    private val width: Int,
    private val height: Int,
    private val colorSpace: ColorSpace,
    private val ditherAlgorithm: DitherAlgorithm,
    private val emptyBlockId: String,
    private val Thex: Int,
    private val They: Int,
    private val Thez: Int,
    private val TheMirrorh: Boolean,
    private val TheMirrorv: Boolean,
    private val TheObj: String,
    private val TheName: String,
    private val TheLimit: Int,
    private val TheinnerStep: Int,
    private val TheinnerAxis: McCommandGenerator.Axis,
    private val TheouterStep: Int,
    private val TheouterAxis: McCommandGenerator.Axis,
    private val StartOffset: Int,
    private val ForbiddenScores: Set<Int>,
    private val Multiplier: Int,
    private val isAddTxt: Boolean,
    private val callback: Callback?
) {

    interface Callback {
        fun onProgress(message: String)
        fun onSuccess(resultImage: File, resultTxt: File, resultTotal: String)
        fun onError(e: Exception)
    }

    class Builder {
        private var inputImageFile: File? = null
        private var outputDir: File? = null
        private var textureFiles: List<File> = emptyList()
        private var width: Int = 128
        private var height: Int = 128
        private var colorSpace: ColorSpace = ColorSpace.RGB
        private var ditherAlgorithm: DitherAlgorithm = DitherAlgorithm.NONE
        private var emptyBlockId: String = "air"
        private var Thex: Int = 0
    private var They: Int = 0
    private var Thez: Int = 0
    private var TheMirrorh: Boolean = false
    private var TheMirrorv: Boolean = false
    private var TheObj: String = "n"
    private var TheName: String = "C"
    private var TheLimit: Int = 0
    private var TheinnerStep: Int = 1
    private var TheinnerAxis: McCommandGenerator.Axis = McCommandGenerator.Axis.长
    private var TheouterStep: Int = 1
    private var TheouterAxis: McCommandGenerator.Axis = McCommandGenerator.Axis.宽
    private var StartOffset: Int = 0
    private var ForbiddenScores: Set<Int> = emptySet<Int>()
    private var Multiplier: Int = 0
    private var isAddTxt: Boolean = false
        private var callback: Callback? = null

        fun setInputImage(file: File) = apply { this.inputImageFile = file }
        fun setOutputDir(dir: File) = apply { this.outputDir = dir }
        fun setTextureFiles(files: List<File>) = apply { this.textureFiles = files }
        fun setDimensions(width: Int, height: Int) = apply {
            this.width = width
            this.height = height
        }
        fun setColorSpace(space: ColorSpace) = apply { this.colorSpace = space }
        fun setDitherAlgorithm(algo: DitherAlgorithm) = apply { this.ditherAlgorithm = algo }
        fun setEmptyBlockId(id: String) = apply { this.emptyBlockId = id }
        fun setThex(num: Int) = apply { this.Thex = num }
        fun setThey(num: Int) = apply { this.They= num }
        fun setThez(num: Int) = apply { this.Thez = num }
        fun setTheMirrorh(num: Boolean) = apply { this.TheMirrorh = num }
        fun setTheMirrorv(num: Boolean) = apply { this.TheMirrorv = num }
        fun setTheObj(num: String) = apply { this.TheObj = num }
        fun setTheName(num: String) = apply { this.TheName = num }
        fun setTheLimit(num: Int) = apply { this.TheLimit = num }
        fun setTheinnerStep(num: Int) = apply { this.TheinnerStep = num }
        fun setTheouterStep(num: Int) = apply { this.TheouterStep = num }
        fun setTheinnerAxis(num: McCommandGenerator.Axis) = apply { this.TheinnerAxis = num }
        fun setTheouterAxis(num: McCommandGenerator.Axis) = apply { this.TheouterAxis = num }
        fun setStartOffset(num: Int) = apply { this.StartOffset = num }
        fun setForbiddenScores(num: Set<Int>) = apply { this.ForbiddenScores = num }
        fun setMultiplier(num: Int) = apply { this.Multiplier = num }
        fun setisAddTxt(bl: Boolean) = apply { this.isAddTxt = bl }
        fun setCallback(callback: Callback) = apply { this.callback = callback }

        fun build(): PixelArtGenerator {
            requireNotNull(inputImageFile) { "必须设置输入图片文件" }
            requireNotNull(outputDir) { "必须设置输出文件夹" }
            require(textureFiles.isNotEmpty()) { "贴图文件列表不能为空" }
            return PixelArtGenerator(
                inputImageFile!!, outputDir!!, textureFiles,
                width, height, colorSpace, ditherAlgorithm, emptyBlockId,Thex,They,Thez,TheMirrorh,TheMirrorv,TheObj,TheName,TheLimit,TheinnerStep,TheinnerAxis,TheouterStep,TheouterAxis,StartOffset,ForbiddenScores,Multiplier,isAddTxt,callback
            )
        }
    }

    // 后台线程池与主线程 Handler
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private fun notifyProgress(msg: String) {
        mainHandler.post { callback?.onProgress(msg) }
    }

    private fun notifySuccess(img: File, txt: File, total: String) {
        mainHandler.post { callback?.onSuccess(img, txt, total) }
    }

    private fun notifyError(e: Exception) {
        mainHandler.post { callback?.onError(e) }
    }
    
    companion object {
    private val BAYER_2X2 = arrayOf(
        floatArrayOf(0f/4f, 2f/4f),
        floatArrayOf(3f/4f, 1f/4f)
    )
    private val BAYER_4X4 = arrayOf(
        floatArrayOf( 0f/16f,  8f/16f,  2f/16f, 10f/16f),
        floatArrayOf(12f/16f,  4f/16f, 14f/16f,  6f/16f),
        floatArrayOf( 3f/16f, 11f/16f,  1f/16f,  9f/16f),
        floatArrayOf(15f/16f,  7f/16f, 13f/16f,  5f/16f)
    )
    private val BAYER_8X8 = arrayOf(
        floatArrayOf( 0f/64, 32f/64,  8f/64, 40f/64,  2f/64, 34f/64, 10f/64, 42f/64),
        floatArrayOf(48f/64, 16f/64, 56f/64, 24f/64, 50f/64, 18f/64, 58f/64, 26f/64),
        floatArrayOf(12f/64, 44f/64,  4f/64, 36f/64, 14f/64, 46f/64,  6f/64, 38f/64),
        floatArrayOf(60f/64, 28f/64, 52f/64, 20f/64, 62f/64, 30f/64, 54f/64, 22f/64),
        floatArrayOf( 3f/64, 35f/64, 11f/64, 43f/64,  1f/64, 33f/64,  9f/64, 41f/64),
        floatArrayOf(51f/64, 19f/64, 59f/64, 27f/64, 49f/64, 17f/64, 57f/64, 25f/64),
        floatArrayOf(15f/64, 47f/64,  7f/64, 39f/64, 13f/64, 45f/64,  5f/64, 37f/64),
        floatArrayOf(63f/64, 31f/64, 55f/64, 23f/64, 61f/64, 29f/64, 53f/64, 21f/64)
    )
    private val ORDERED_3X3 = arrayOf(
        floatArrayOf(7f/9f, 2f/9f, 6f/9f),
        floatArrayOf(4f/9f, 0f/9f, 1f/9f),
        floatArrayOf(3f/9f, 8f/9f, 5f/9f)
    )
}

    /**
     * 开始执行生成任务
     */
    fun generate() {
        executor.execute {
            try {
                if (!outputDir.exists()) {
                    outputDir.mkdirs()
                }

                // 1. 加载贴图并计算平均颜色
                notifyProgress("正在加载方块贴图...")
                val blockDataList = loadBlockTextures()
                if (blockDataList.isEmpty()) throw IllegalStateException("未能成功加载任何方块贴图")

                // 2. 加载并缩放输入图片
                notifyProgress("正在处理原图...")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val origBitmap = BitmapFactory.decodeFile(inputImageFile.absolutePath, options)
                    ?: throw IllegalArgumentException("无法解码输入图片")
                val resizedBitmap = Bitmap.createScaledBitmap(origBitmap, width, height, true)

                // 3. 运行核心算法
                notifyProgress("正在执行 ${colorSpace.name} 匹配 (Algorithm=${ditherAlgorithm.name})...")
                val (chosenGrid, blockUsage) = processImage(resizedBitmap, blockDataList)

                // 4. 组装结果图并保存
                notifyProgress("正在拼装结果大图...")
                val resultImageFile = File(outputDir, "${inputImageFile.nameWithoutExtension}_${colorSpace.name.lowercase()}.png")
                assembleAndSaveImage(chosenGrid, blockDataList, resultImageFile)

                // 5. 保存 TXT 数据
                notifyProgress("正在生成 TXT 蓝图...")
                val resultTxtFile = File(outputDir, "Command_${inputImageFile.nameWithoutExtension}_${colorSpace.name.lowercase()}.txt")
                val inputData = generateTextData(chosenGrid)
                if (isAddTxt) saveTextData(chosenGrid, File(outputDir, "Block_${inputImageFile.nameWithoutExtension}_${colorSpace.name.lowercase()}.txt"))
                var commandsSize = 0
                

McCommandGenerator.Builder()
    .setInputData(inputData)  // 直接传入生成的字符串
    .setStartCoords(长 = Thex, 深 = They, 宽 = Thez)
    .setAxisConfig(
        innerAxis = TheinnerAxis, innerStep = TheinnerStep,
        outerAxis = TheouterAxis, outerStep = TheouterStep
    )
    .setMirror(horizontal = TheMirrorh, vertical = TheMirrorv)
    .setScoreboardObj(TheObj)
    .setEntityName(TheName)
    .setCharLimit(TheLimit)
    .setOutputFile(resultTxtFile)
    .setStartScoreOffset(StartOffset)
    .setForbiddenScores(ForbiddenScores)
    .setGenerationMultiplier(Multiplier)
    .setCallback { generatedCommands ->
        if (generatedCommands.isNotEmpty()) {
            println("成功生成了 ${generatedCommands.count { it.contains("/") }} 条指令！")
            commandsSize = generatedCommands.count { it.contains("/") }
           
        } else {
            println("指令生成失败或输入为空。")
           
        }
    }
    .build()
    .generate()
                // 打印日志 (Logcat中可见)
                val resultTotal = buildString {
                appendLine("[统计] 命令方块数量: ${commandsSize}")
        appendLine("[统计] 使用量最多的方块:")
        blockUsage.entries
        .sortedByDescending { it.value }
        .forEach { appendLine("${it.key}: ${it.value}") }
                }

                notifySuccess(resultImageFile, resultTxtFile, resultTotal)

            } catch (e: Exception) {
                e.printStackTrace()
                notifyError(e)
            } finally {
                executor.shutdown()
            }
        }
    }

    private fun loadBlockTextures(): List<BlockData> {
        val list = mutableListOf<BlockData>()
        for (file in textureFiles) {
            if (!file.exists() || !file.isFile) continue
            val id = file.nameWithoutExtension // 使用纯文件名作为 ID
            val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: continue
            
            // 计算平均颜色
            var rSum = 0f; var gSum = 0f; var bSum = 0f; var validPixels = 0
            for (y in 0 until bitmap.height) {
                for (x in 0 until bitmap.width) {
                    val color = bitmap.getPixel(x, y)
                    val alpha = Color.alpha(color)
                    if (alpha > 12) { // 过滤透明像素 (相当于 alpha > 0.05)
                        rSum += Color.red(color) / 255f
                        gSum += Color.green(color) / 255f
                        bSum += Color.blue(color) / 255f
                        validPixels++
                    }
                }
            }
            
            if (validPixels > 0) {
                val rgb = FloatArray(3).apply {
                    this[0] = rSum / validPixels
                    this[1] = gSum / validPixels
                    this[2] = bSum / validPixels
                }
                
                // 转 HSV
                val hsv = FloatArray(3)
                Color.colorToHSV(Color.rgb((rgb[0]*255).toInt(), (rgb[1]*255).toInt(), (rgb[2]*255).toInt()), hsv)
                // 归一化 HSV，让抖动算法的数值量级相对一致
                hsv[0] /= 360f 
                
                // 转 LAB
                val lab = DoubleArray(3)
                ColorUtils.colorToLAB(Color.rgb((rgb[0]*255).toInt(), (rgb[1]*255).toInt(), (rgb[2]*255).toInt()), lab)
                
                list.add(BlockData(id, bitmap, rgb, hsv, lab))
            }
        }
        return list
    }

 private fun safeAddError(errBuff: Array<Array<FloatArray>>, y: Int, x: Int, error: FloatArray, weight: Float) {
    // 安全检查，防止数组越界，使代码更整洁
    if (y < errBuff.size && x >= 0 && x < errBuff[0].size) {
        for (i in 0..2) {
            errBuff[y][x][i] += error[i] * weight
        }
    }
}

private fun processImage(bitmap: Bitmap, blocks: List<BlockData>): Pair<Array<Array<String>>, Map<String, Int>> {
    val grid = Array(height) { Array(width) { "" } }
    val usageMap = mutableMapOf<String, Int>()

    val imgData = Array(height) { Array(width) { FloatArray(3) } }
    val alphaMask = Array(height) { BooleanArray(width) }

    for (y in 0 until height) {
        for (x in 0 until width) {
            val pixel = bitmap.getPixel(x, y)
            alphaMask[y][x] = Color.alpha(pixel) > 12
            if (alphaMask[y][x]) {
                when (colorSpace) {
                    ColorSpace.RGB -> {
                        imgData[y][x][0] = Color.red(pixel) / 255f
                        imgData[y][x][1] = Color.green(pixel) / 255f
                        imgData[y][x][2] = Color.blue(pixel) / 255f
                    }
                    ColorSpace.HSV -> {
                        val hsv = FloatArray(3)
                        Color.colorToHSV(pixel, hsv)
                        imgData[y][x][0] = hsv[0] / 360f
                        imgData[y][x][1] = hsv[1]
                        imgData[y][x][2] = hsv[2]
                    }
                    ColorSpace.LAB -> {
                        val lab = DoubleArray(3)
                        ColorUtils.colorToLAB(pixel, lab)
                        imgData[y][x][0] = lab[0].toFloat()
                        imgData[y][x][1] = lab[1].toFloat()
                        imgData[y][x][2] = lab[2].toFloat()
                    }
                }
            }
        }
    }

    val errBuff = Array(height) { Array(width) { FloatArray(3) } }
    val bayerSpread = 0.15f // 调整有序抖动的强度 (0.1f ~ 0.3f 效果较好)

    for (y in 0 until height) {
        for (x in 0 until width) {
            if (!alphaMask[y][x]) {
                grid[y][x] = emptyBlockId
                continue
            }

            // 1. 处理有序抖动 (Ordered Dithering: 在量化前改变像素值)
            var bayerOffset = 0f
            when (ditherAlgorithm) {
                DitherAlgorithm.BAYER_2x2 -> bayerOffset = (BAYER_2X2[y % 2][x % 2] - 0.5f) * bayerSpread
                DitherAlgorithm.BAYER_4x4 -> bayerOffset = (BAYER_4X4[y % 4][x % 4] - 0.5f) * bayerSpread
                DitherAlgorithm.BAYER_8x8 -> bayerOffset = (BAYER_8X8[y % 8][x % 8] - 0.5f) * bayerSpread
                DitherAlgorithm.ORDERED_3x3 -> bayerOffset = (ORDERED_3X3[y % 3][x % 3] - 0.5f) * bayerSpread
                else -> {}
            }

            val currentVal = FloatArray(3)
            for (c in 0..2) {
                currentVal[c] = imgData[y][x][c] + errBuff[y][x][c] + bayerOffset
                
                // 钳制防止溢出
                if (colorSpace == ColorSpace.RGB) {
                    currentVal[c] = currentVal[c].coerceIn(0f, 1f)
                } else if (colorSpace == ColorSpace.HSV && c > 0) {
                    currentVal[c] = currentVal[c].coerceIn(0f, 1f)
                }
            }

            // 2. 查找最近方块 (Quantization)
            val bestBlock = findNearestBlock(currentVal, blocks)
            grid[y][x] = bestBlock.id
            usageMap[bestBlock.id] = usageMap.getOrDefault(bestBlock.id, 0) + 1

            // 3. 处理误差扩散抖动 (Error Diffusion: 在量化后分发误差)
            if (ditherAlgorithm in listOf(
                    DitherAlgorithm.FLOYD_STEINBERG, DitherAlgorithm.ATKINSON, 
                    DitherAlgorithm.SIERRA, DitherAlgorithm.STUCKI, DitherAlgorithm.BURKES
                )
            ) {
                val blockVal = when (colorSpace) {
                    ColorSpace.RGB -> bestBlock.rgb
                    ColorSpace.HSV -> bestBlock.hsv
                    ColorSpace.LAB -> floatArrayOf(bestBlock.lab[0].toFloat(), bestBlock.lab[1].toFloat(), bestBlock.lab[2].toFloat())
                }
                
                // 计算当前量化误差 (此处不包含 bayerOffset，因为它是人工引入的噪声)
                val err = FloatArray(3) { c -> (imgData[y][x][c] + errBuff[y][x][c]) - blockVal[c] }

                when (ditherAlgorithm) {
                    DitherAlgorithm.FLOYD_STEINBERG -> {
                        safeAddError(errBuff, y, x + 1, err, 7 / 16f)
                        safeAddError(errBuff, y + 1, x - 1, err, 3 / 16f)
                        safeAddError(errBuff, y + 1, x, err, 5 / 16f)
                        safeAddError(errBuff, y + 1, x + 1, err, 1 / 16f)
                    }
                    DitherAlgorithm.ATKINSON -> {
                        safeAddError(errBuff, y, x + 1, err, 1 / 8f)
                        safeAddError(errBuff, y, x + 2, err, 1 / 8f)
                        safeAddError(errBuff, y + 1, x - 1, err, 1 / 8f)
                        safeAddError(errBuff, y + 1, x, err, 1 / 8f)
                        safeAddError(errBuff, y + 1, x + 1, err, 1 / 8f)
                        safeAddError(errBuff, y + 2, x, err, 1 / 8f)
                    }
                    DitherAlgorithm.SIERRA -> { // Sierra3
                        safeAddError(errBuff, y, x + 1, err, 5 / 32f)
                        safeAddError(errBuff, y, x + 2, err, 3 / 32f)
                        safeAddError(errBuff, y + 1, x - 2, err, 2 / 32f)
                        safeAddError(errBuff, y + 1, x - 1, err, 4 / 32f)
                        safeAddError(errBuff, y + 1, x, err, 5 / 32f)
                        safeAddError(errBuff, y + 1, x + 1, err, 4 / 32f)
                        safeAddError(errBuff, y + 1, x + 2, err, 2 / 32f)
                        safeAddError(errBuff, y + 2, x - 1, err, 2 / 32f)
                        safeAddError(errBuff, y + 2, x, err, 3 / 32f)
                        safeAddError(errBuff, y + 2, x + 1, err, 2 / 32f)
                    }
                    DitherAlgorithm.STUCKI -> {
                        safeAddError(errBuff, y, x + 1, err, 8 / 42f)
                        safeAddError(errBuff, y, x + 2, err, 4 / 42f)
                        safeAddError(errBuff, y + 1, x - 2, err, 2 / 42f)
                        safeAddError(errBuff, y + 1, x - 1, err, 4 / 42f)
                        safeAddError(errBuff, y + 1, x, err, 8 / 42f)
                        safeAddError(errBuff, y + 1, x + 1, err, 4 / 42f)
                        safeAddError(errBuff, y + 1, x + 2, err, 2 / 42f)
                        safeAddError(errBuff, y + 2, x - 2, err, 1 / 42f)
                        safeAddError(errBuff, y + 2, x - 1, err, 2 / 42f)
                        safeAddError(errBuff, y + 2, x, err, 4 / 42f)
                        safeAddError(errBuff, y + 2, x + 1, err, 2 / 42f)
                        safeAddError(errBuff, y + 2, x + 2, err, 1 / 42f)
                    }
                    DitherAlgorithm.BURKES -> {
                        safeAddError(errBuff, y, x + 1, err, 8 / 32f)
                        safeAddError(errBuff, y, x + 2, err, 4 / 32f)
                        safeAddError(errBuff, y + 1, x - 2, err, 2 / 32f)
                        safeAddError(errBuff, y + 1, x - 1, err, 4 / 32f)
                        safeAddError(errBuff, y + 1, x, err, 8 / 32f)
                        safeAddError(errBuff, y + 1, x + 1, err, 4 / 32f)
                        safeAddError(errBuff, y + 1, x + 2, err, 2 / 32f)
                    }
                    else -> {}
                }
            }
        }
    }
    return Pair(grid, usageMap)
}

    private fun findNearestBlock(target: FloatArray, blocks: List<BlockData>): BlockData {
    var minDistance = Double.MAX_VALUE
    var bestBlock = blocks.first()

    for (block in blocks) {

        val dist: Double = when (colorSpace) {

            ColorSpace.RGB -> {
                val dr = target[0].toDouble() - block.rgb[0].toDouble()
                val dg = target[1].toDouble() - block.rgb[1].toDouble()
                val db = target[2].toDouble() - block.rgb[2].toDouble()
                dr * dr + dg * dg + db * db
            }

            ColorSpace.HSV -> {
                val dh = target[0].toDouble() - block.hsv[0].toDouble()
                val ds = target[1].toDouble() - block.hsv[1].toDouble()
                val dv = target[2].toDouble() - block.hsv[2].toDouble()
                dh * dh + ds * ds + dv * dv
            }

            ColorSpace.LAB -> {
                val dl = target[0].toDouble() - block.lab[0]
                val da = target[1].toDouble() - block.lab[1]
                val db = target[2].toDouble() - block.lab[2]
                dl * dl + da * da + db * db
            }
        }

        if (dist < minDistance) {
            minDistance = dist
            bestBlock = block
        }
    }

    return bestBlock
}

    private fun assembleAndSaveImage(grid: Array<Array<String>>, blocks: List<BlockData>, outFile: File) {
        val blockMap = blocks.associateBy { it.id }
        // 获取基准方块尺寸（假设所有贴图尺寸一致，默认 16x16）
        val sampleBmp = blocks.firstOrNull()?.bitmap
        val blockW = sampleBmp?.width ?: 16
        val blockH = sampleBmp?.height ?: 16

        val outBitmap = Bitmap.createBitmap(width * blockW, height * blockH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outBitmap)

        for (y in 0 until height) {
            for (x in 0 until width) {
                val bId = grid[y][x]
                if (bId == "air" || bId == emptyBlockId) continue
                
                val tile = blockMap[bId]?.bitmap
                if (tile != null) {
                    canvas.drawBitmap(tile, (x * blockW).toFloat(), (y * blockH).toFloat(), null)
                }
            }
        }

        FileOutputStream(outFile).use { fos ->
            outBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos)
        }
        outBitmap.recycle()
    }

    private fun saveTextData(grid: Array<Array<String>>, outFile: File) {
        FileWriter(outFile).use { writer ->
            writer.write("[[\n")
            for (y in 0 until height) {
                val line = grid[y].joinToString(",") { "\"$it\"" }
                writer.write("[$line]\n")
            }
            writer.write("]]")
        }
    }
    
    private fun generateTextData(grid: Array<Array<String>>): String {
    val lines = mutableListOf<String>()
    lines.add("[[")
    for (y in 0 until height) {
        val line = grid[y].joinToString(",") { "\"$it\"" }
        lines.add("[$line]")
        //lines.add("$[$line]")
    }
    lines.add("]]")
    return lines.joinToString("\n")
}
}