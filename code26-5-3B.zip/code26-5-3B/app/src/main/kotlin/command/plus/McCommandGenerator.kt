package command.plus

import java.io.File
import java.io.FileOutputStream
import java.util.TreeSet

/**
 * 我的世界 Minecraft 盔甲架命令生成器 (多实体增强版)
 */
class McCommandGenerator private constructor(
    private val inputData: String,
    private val scoreboardObj: String,
    private val entityName: String,
    private val charLimit: Int,
    private val startLength: Int, // X
    private val startDepth: Int,   // Y
    private val startWidth: Int,   // Z
    private val mirrorHorizontal: Boolean,
    private val mirrorVertical: Boolean,
    private val innerAxis: Axis,
    private val innerStep: Int,
    private val outerAxis: Axis,
    private val outerStep: Int,
    private val startScoreOffset: Int,
    private val forbiddenScores: Set<Int>,
    private val generationMultiplier: Int, // 新增：生成倍数
    private val saveFile: File?,
    private val callback: (List<String>) -> Unit
) {

    enum class Axis { 长, 深, 宽 }

    private data class RangeResult(
        var selectorPart: String,
        val corrections: MutableList<Int> = mutableListOf()
    )

    fun generate() {
        try {
            var matrix = parseInput(inputData)
            if (matrix.isEmpty()) {
                callback(emptyList())
                return
            }

            matrix = applyMirror(matrix)
            val commands = generateCommands(matrix)

            saveFile?.let { file ->
                try {
                    file.parentFile?.mkdirs()
                    FileOutputStream(file).use { fos ->
                        commands.forEach { line ->
                            fos.write((line + "\n").toByteArray(Charsets.UTF_8))
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            callback(commands)
        } catch (e: Exception) {
            e.printStackTrace()
            callback(emptyList())
        }
    }

    private fun parseInput(data: String): List<List<String>> {
        val matrix = mutableListOf<List<String>>()
        val lines = data.lines()
        val regex = "'([^']*)'|\"([^\"]*)\"".toRegex()

        for (line in lines) {
            var cleanLine = line.trim()
            if (cleanLine.contains(".")) {
                cleanLine = cleanLine.substringAfter(".").trim()
            }
            if (cleanLine.isEmpty()) continue

            val row = regex.findAll(cleanLine).map {
                it.groupValues[1].ifEmpty { it.groupValues[2] }
            }.toList()

            if (row.isNotEmpty()) {
                matrix.add(row)
            }
        }
        return matrix
    }

    private fun applyMirror(matrix: List<List<String>>): List<List<String>> {
        var processed = matrix
        if (mirrorHorizontal) processed = processed.map { it.reversed() }
        if (mirrorVertical) processed = processed.reversed()
        return processed
    }

    private fun getConsecutiveRanges(numbers: List<Int>): List<String> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val ranges = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val x = sorted[i]
            if (x == prev + 1) {
                prev = x
            } else {
                ranges.add(if (start == prev) "$start" else "$start..$prev")
                start = x
                prev = x
            }
        }
        ranges.add(if (start == prev) "$start" else "$start..$prev")
        return ranges
    }

    private fun getSafeRange(start: Int, end: Int, allTimesInChain: Set<Int>): RangeResult {
        var finalStart = start
        var finalEnd = end
        val res = RangeResult(selectorPart = "")

        if (forbiddenScores.contains(start) && !isConsecutiveForbidden(start)) {
            finalStart = start - 1
            if (!allTimesInChain.contains(finalStart)) res.corrections.add(finalStart)
        }

        if (forbiddenScores.contains(end) && !isConsecutiveForbidden(end)) {
            finalEnd = end + 1
            if (!allTimesInChain.contains(finalEnd)) res.corrections.add(finalEnd)
        }

        res.selectorPart = if (finalStart == finalEnd) "$scoreboardObj=!$finalStart" else "$scoreboardObj=!$finalStart..$finalEnd"
        return res
    }

    private fun isConsecutiveForbidden(valNum: Int): Boolean = forbiddenScores.contains(valNum - 1) || forbiddenScores.contains(valNum + 1)

    private fun buildSafeRanges(numbers: List<Int>): List<RangeResult> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val allTimesInChain = sorted.toSet()
        val results = mutableListOf<RangeResult>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur != prev + 1) {
                results.add(getSafeRange(start, prev, allTimesInChain))
                start = cur
            }
            prev = cur
        }
        results.add(getSafeRange(start, prev, allTimesInChain))
        return results
    }

    private fun buildSetblockCommands(blockId: String, scores: List<Int>): List<String> {
        val rangeResults = buildSafeRanges(scores)
        if (rangeResults.isEmpty()) return emptyList()

        val cmds = mutableListOf<String>()
        val currentSelectors = mutableListOf<String>()
        val currentCorrections = TreeSet<Int>()

        // 移除 [name="..."]
        val prefix = "/execute as @e at @s unless entity @s[scores={"
        val suffixStart = "}]"
        val runPart = " run setblock ~ ~ ~ $blockId"

        var currentLen = prefix.length + suffixStart.length + runPart.length + 10

        for (rr in rangeResults) {
            val partLen = rr.selectorPart.length + 1
            var correctionExtraLen = 0
            for (c in rr.corrections) {
                if (!currentCorrections.contains(c)) {
                    correctionExtraLen += (scoreboardObj.length + c.toString().length + 2)
                }
            }
            if (currentCorrections.isEmpty() && rr.corrections.isNotEmpty()) correctionExtraLen += 30

            if (charLimit > 0 && currentLen + partLen + correctionExtraLen > charLimit) {
                flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
                currentSelectors.clear()
                currentCorrections.clear()
                currentLen = prefix.length + suffixStart.length + runPart.length + 10
            }

            currentSelectors.add(rr.selectorPart)
            currentCorrections.addAll(rr.corrections)
            currentLen += (partLen + correctionExtraLen)
        }

        flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
        return cmds
    }

    private fun flushSetblockCommand(out: MutableList<String>, selectors: List<String>, corrections: Set<Int>, blockId: String) {
    if (selectors.isEmpty()) return
    val sb = StringBuilder()
    
    // 修改处：在 @e 后面添加计分板范围限制
    sb.append("/execute as @e[scores={$scoreboardObj=$startScoreOffset..}] at @s unless entity @s[scores={")
        .append(selectors.joinToString(","))
        .append("}]")

    if (corrections.isNotEmpty()) {
        // 修改处：同样的限制
        sb.append(" unless entity @s[scores={")
        var count = 0
        for (c in corrections) {
            sb.append(scoreboardObj).append("=").append(c)
            count++
            if (count < corrections.size) sb.append(",")
        }
        sb.append("}]")
    }
    sb.append(" run setblock ~ ~ ~ ").append(blockId)
    out.add(sb.toString())
}

    private fun generateCommands(matrix: List<List<String>>): List<String> {
    val cmds = mutableListOf<String>()
    val rowLength = matrix.firstOrNull()?.size ?: 0 
    val totalRows = matrix.size
    val totalBlocks = rowLength * totalRows
    
    if (totalBlocks == 0) return emptyList()

    // 确定生成实体数量
    val actualCount = if (totalBlocks % generationMultiplier == totalBlocks) 1 else generationMultiplier
    val names = List(actualCount) { if (it == 0) entityName else "$entityName$it" }
    val unlessNamesPart = names.joinToString(",") { "name=!$it" }

    // ===== 1. 初始化部分 (tickingarea & summon) =====
    cmds.add("### 初始化指令 ###")
    cmds.add("$0,0,0")
    cmds.add("/tickingarea remove_all")
    cmds.add("$")
    cmds.add("$1,0,1")
    // Tickingarea
    val endLength = startLength + (if (innerAxis == Axis.长) (rowLength - 1) * innerStep else 0) + (if (outerAxis == Axis.长) (totalRows - 1) * outerStep else 0)
    val endWidth = startWidth + (if (innerAxis == Axis.宽) (rowLength - 1) * innerStep else 0) + (if (outerAxis == Axis.宽) (totalRows - 1) * outerStep else 0)
    val minX = minOf(startLength, endLength); val maxX = maxOf(startLength, endLength)
    val minZ = minOf(startWidth, endWidth); val maxZ = maxOf(startWidth, endWidth)

    // 优化：使用 160 (10个区块) 为步长，确保单条指令刚好覆盖 100 个区块的上限
    for (sx in minX..maxX step 160) {
        for (sz in minZ..maxZ step 160) {
            val ex = minOf(sx + 159, maxX) // 160个方块的范围是 sx 到 sx+159
            val ez = minOf(sz + 159, maxZ)
            cmds.add("/tickingarea add $sx 0 $sz $ex 0 $ez")
        }
    }
    cmds.add("$")
    cmds.add("$0,0,0")
    cmds.add("/scoreboard objectives add $scoreboardObj dummy")
    cmds.add("$")

    cmds.add("$1,0,1")
    

    // 计算分段步长 (Task 3: 统一算法)
    // ===== 计算分配逻辑 =====
    val avg = totalBlocks / actualCount
    val remainder = totalBlocks % actualCount
    
    // 存储每个实体负责的任务数量
    val taskSizes = IntArray(actualCount) { i ->
        if (i < remainder) avg + 1 else avg
    }

    var currentGlobalPos = 1 // 当前累计的逻辑索引位置
    val killScores = mutableListOf<Int>()

    for (n in 0 until actualCount) {
        val currentName = names[n]
        val posIdx = currentGlobalPos // 当前实体的起始逻辑位置

        // 核心：计算坐标偏移与起始分数
        // 逻辑索引转行列：行号(row)从0开始，列号(col)从0开始
        // 这里的 rowLength 对应你的“行进轴”长度
        val row = (posIdx - 1) / rowLength
        val col = (posIdx - 1) % rowLength
        
        // 物理坐标偏移计算
        val offsetInner = col.toLong() * innerStep
        val offsetOuter = row.toLong() * outerStep
        
        // 计算计分板上的相对分数 (1-based index)
        // 这里的逻辑必须与 setblock 遍历时的 i+1 对应
        val finalScore = posIdx 

        // 计算物理坐标
        val finalCoords = mutableMapOf(
            Axis.长 to startLength.toLong(),
            Axis.深 to startDepth.toLong(),
            Axis.宽 to startWidth.toLong()
        )
        finalCoords[innerAxis] = finalCoords[innerAxis]!! + offsetInner
        finalCoords[outerAxis] = finalCoords[outerAxis]!! + offsetOuter

        // 生成指令
        val initialScore = startScoreOffset + finalScore
        cmds.add("/summon armor_stand ${finalCoords[Axis.长]} ${finalCoords[Axis.深]} ${finalCoords[Axis.宽]} ~ ~ . $currentName")
        cmds.add("/execute as @e[name=\"$currentName\"] run scoreboard players set @s $scoreboardObj $initialScore")

        // 更新下一个实体的起始位置
        currentGlobalPos += taskSizes[n]
        
        // 记录当前实体的“终点线”：当分数达到下一个实体的起点时，旧实体消失
        if (n < actualCount - 1) {
            killScores.add(startScoreOffset + currentGlobalPos)
        }
    }
    // 最后一个实体的终点分数：总数 + 1
    killScores.add(startScoreOffset + totalBlocks + 1)
    cmds.add("$")

    // ===== 2. 循环部分 (Task 1: 换行 TP 移至此处) =====
    cmds.add("")
    cmds.add("### 循环命令链 ###")
    cmds.add("$2,0,0")
    
    // 换行 TP 逻辑：当分数达到 rowEndIndices + 1 时执行
    val rowEndIndices = (1..totalRows - 1).map { it * rowLength }
    val jumpScores = rowEndIndices.map { startScoreOffset + it + 1 }
    
    if (jumpScores.isNotEmpty()) {
        val jumpRanges = getConsecutiveRanges(jumpScores)
        val scoreSelector = jumpRanges.joinToString(",") { "$scoreboardObj=!$it" }
        val tpCoords = arrayOf("~", "~", "~")
        // 换行时：行进轴回归初始绝对值，换行轴相对位移
        when (innerAxis) {
            Axis.长 -> tpCoords[0] = startLength.toString()
            Axis.深 -> tpCoords[1] = startDepth.toString()
            Axis.宽 -> tpCoords[2] = startWidth.toString()
        }
        val idxOuter = when(outerAxis) { Axis.长 -> 0; Axis.深 -> 1; Axis.宽 -> 2 }
        tpCoords[idxOuter] = "~$outerStep"
        
        // 只有当分数在 jumpScores 列表中时，才不触发 unless (即触发 TP)
        cmds.add("/execute as @e[scores={$scoreboardObj=$startScoreOffset..}] at @s unless entity @s[scores={$scoreSelector}] run tp ${tpCoords.joinToString(" ")}")
    }
    cmds.add("$")

    // ===== 3. 连锁部分 (Task 1: 放置方块移至此处) =====
    cmds.add("$1,0,1")
    
    // 放置方块 (全部在连锁中处理)
    val flatBlocks = matrix.flatten()
    val blockMap = mutableMapOf<String, MutableList<Int>>()
    flatBlocks.forEachIndexed { i, blockId ->
        blockMap.getOrPut(blockId) { mutableListOf() }.add(startScoreOffset + i + 1)
    }
    for ((blockId, scores) in blockMap) {
        cmds.addAll(buildSetblockCommands(blockId, scores))
    }

    // 步进 (前进 1 格)
    val stepCoords = arrayOf("~", "~", "~")
    val innerIdx = when(innerAxis) { Axis.长 -> 0; Axis.深 -> 1; Axis.宽 -> 2 }
    stepCoords[innerIdx] = "~$innerStep"
    
    cmds.add("/execute as @e unless entity @s[$unlessNamesPart] at @s run tp ${stepCoords.joinToString(" ")}")
    cmds.add("/execute as @e unless entity @s[$unlessNamesPart] run scoreboard players add @s $scoreboardObj 1")

    // ===== 4. Kill 逻辑 (Task 4: 重新设计的 Kill 分数) =====
    val killScoreRanges = getConsecutiveRanges(killScores)
    val killScoreSelector = killScoreRanges.joinToString(",") { "$scoreboardObj=!$it" }
    
    // 这里的逻辑是：如果分数匹配到了 killScores 列表中的任何一个，则触发 kill
    cmds.add("/execute as @e[scores={$scoreboardObj=$startScoreOffset..}] unless entity @s[scores={$killScoreSelector}] run kill @s")
    cmds.add("$")

    return cmds
}

    class Builder {
        private var saveFile: File? = null
        private var inputData: String = ""
        private var scoreboardObj: String = "n"
        private var entityName: String = "C"
        private var charLimit: Int = 10000
        private var startLength: Int = 0
        private var startDepth: Int = 0
        private var startWidth: Int = 0
        private var mirrorHorizontal: Boolean = false
        private var mirrorVertical: Boolean = false
        private var innerAxis: Axis = Axis.长
        private var innerStep: Int = 1
        private var outerAxis: Axis = Axis.宽
        private var outerStep: Int = 1
        private var startScoreOffset: Int = 0
        private var forbiddenScores: Set<Int> = emptySet()
        private var generationMultiplier: Int = 1 // 默认 1
        private var callback: ((List<String>) -> Unit)? = null

        fun setInputData(data: String) = apply { this.inputData = data }
        fun setScoreboardObj(obj: String) = apply { this.scoreboardObj = obj }
        fun setEntityName(name: String) = apply { this.entityName = name }
        fun setCharLimit(limit: Int) = apply { this.charLimit = limit }
        fun setStartCoords(长: Int, 深: Int, 宽: Int) = apply {
            this.startLength = 长
            this.startDepth = 深
            this.startWidth = 宽
        }
        fun setMirror(horizontal: Boolean, vertical: Boolean) = apply {
            this.mirrorHorizontal = horizontal
            this.mirrorVertical = vertical
        }
        fun setAxisConfig(innerAxis: Axis, innerStep: Int, outerAxis: Axis, outerStep: Int) = apply {
            require(innerAxis != outerAxis) { "内部行进轴和换行轴不能是同一个！" }
            this.innerAxis = innerAxis
            this.innerStep = innerStep
            this.outerAxis = outerAxis
            this.outerStep = outerStep
        }
        fun setStartScoreOffset(offset: Int) = apply { this.startScoreOffset = offset }
        fun setForbiddenScores(values: Set<Int>) = apply { this.forbiddenScores = values }
        fun setGenerationMultiplier(m: Int) = apply { this.generationMultiplier = if (m < 1) 1 else m }
        fun setCallback(callback: (List<String>) -> Unit) = apply { this.callback = callback }
        fun setOutputFile(path: String) = apply {
            this.saveFile = File(path)
        }

        fun setOutputFile(file: File) = apply {
            this.saveFile = file
        }

        fun build(): McCommandGenerator {
            requireNotNull(callback) { "必须设置 Callback" }
            return McCommandGenerator(
                inputData, scoreboardObj, entityName, charLimit, startLength, startDepth, startWidth,
                mirrorHorizontal, mirrorVertical, innerAxis, innerStep, outerAxis, outerStep,
                startScoreOffset, forbiddenScores, generationMultiplier, saveFile, callback!!
            )
        }
    }
}