package command.plus

import java.io.*
import java.nio.charset.StandardCharsets
import java.util.LinkedHashMap



data class BlockInput(
    val x: Int,
    val y: Int,
    val z: Int,
    val id: String,
    val states: Map<String, Any?> = emptyMap(),
    val blockEntityNbt: Map<String, Any?>? = null
)

// 结构化存储解析后的数据
class LoadedStructure(
    val width: Int,
    val height: Int,
    val depth: Int,
    val primaryIndices: IntArray,
    val palette: List<McStructureExporter.BlockStateKey>,
    val blockPositionData: Map<Int, Map<String, Any?>>
)

object McStructureExporter {

    data class PrefixRule(
    val prefix: String,
    val states: Map<String, Any?>
)

    data class BlockStateKey(
        val name: String,
        val states: Map<String, Any?>
    )
    
    private fun applyPrefixEncode(
    blockId: String,
    states: Map<String, Any?>,
    prefixRules: List<PrefixRule>
): String {
    val rule = prefixRules.firstOrNull { rule ->
        rule.states.all { (k, v) -> states[k] == v }
    }
    return if (rule != null) rule.prefix + blockId else blockId
}

private fun applyPrefixDecode(
    rawId: String,
    prefixRules: List<PrefixRule>
): Pair<String, Map<String, Any?>> {
    val rule = prefixRules.firstOrNull { rawId.startsWith(it.prefix) }
    return if (rule != null) {
        rawId.removePrefix(rule.prefix) to rule.states
    } else {
        rawId to emptyMap()
    }
}

    // --- 功能 1: 解析 mcstructure 文件 ---
    fun load(inputFile: File): LoadedStructure {
        val root = FileInputStream(inputFile).use { fis ->
            BufferedInputStream(fis).use { bis ->
                NbtReader(bis).readRoot() as NbtTag.CompoundTag
            }
        }

        val size = (root.value["size"] as NbtTag.ListTag).items.map { (it as NbtTag.IntTag).value }
        val width = size[0]
        val height = size[1]
        val depth = size[2]

        val structure = root.value["structure"] as NbtTag.CompoundTag
        val blockIndices = structure.value["block_indices"] as NbtTag.ListTag
        val primaryIndices = (blockIndices.items[0] as NbtTag.ListTag).items.map { (it as NbtTag.IntTag).value }.toIntArray()

        val paletteData = (structure.value["palette"] as NbtTag.CompoundTag).value["default"] as NbtTag.CompoundTag
        val blockPalette = paletteData.value["block_palette"] as NbtTag.ListTag
        
        val palette = blockPalette.items.map { tag ->
            val t = tag as NbtTag.CompoundTag
            BlockStateKey(
                name = (t.value["name"] as NbtTag.StringTag).value,
                states = nbtToMap(t.value["states"] as NbtTag.CompoundTag)
            )
        }

        val blockPosDataTag = paletteData.value["block_position_data"] as? NbtTag.CompoundTag
        val blockPositionData = mutableMapOf<Int, Map<String, Any?>>()
        blockPosDataTag?.value?.forEach { (k, v) ->
            blockPositionData[k.toInt()] = nbtToMap(v as NbtTag.CompoundTag)
        }

        return LoadedStructure(width, height, depth, primaryIndices, palette, blockPositionData)
    }

    // --- 功能 2: 输入坐标读取方块详细信息 ---
    fun getBlockAt(loaded: LoadedStructure, x: Int, y: Int, z: Int): BlockInput? {
        if (x !in 0 until loaded.width || y !in 0 until loaded.height || z !in 0 until loaded.depth) return null
        
        val idx = indexOf(x, y, z, loaded.width, loaded.height, loaded.depth)
        val paletteIdx = loaded.primaryIndices[idx]
        
        // Bedrock中 -1 通常代表空气或无块（取决于版本），这里视作空
        if (paletteIdx == -1) return null
        
        val state = loaded.palette[paletteIdx]
        val entityData = loaded.blockPositionData[idx]?.get("block_entity_data") as? Map<String, Any?>

        return BlockInput(x, y, z, state.name, state.states, entityData)
    }

    // --- 功能 3: 读取所有方块 ID 并输出标准的三维阵列字符串 [y[z[x]]] ---
    fun exportIdGridString(
    loaded: LoadedStructure,
    prefixRules: List<PrefixRule> = emptyList()
): String {
    val sb = StringBuilder()
    sb.append("[\n")

    for (y in 0 until loaded.height) {
        sb.append("  [")
        val zLayers = mutableListOf<String>()

        for (z in 0 until loaded.depth) {
            val xRow = mutableListOf<String>()
            for (x in 0 until loaded.width) {
                val idx = indexOf(x, y, z, loaded.width, loaded.height, loaded.depth)
                val pIdx = loaded.primaryIndices[idx]

                val rawId = if (pIdx != -1 && pIdx < loaded.palette.size) {
                    loaded.palette[pIdx].name
                } else {
                    "minecraft:air"
                }

                val states = if (pIdx != -1 && pIdx < loaded.palette.size) {
                    loaded.palette[pIdx].states
                } else {
                    emptyMap()
                }

                val idWithPrefix = applyPrefixEncode(rawId, states, prefixRules)
                xRow.add("\"$idWithPrefix\"")
            }
            zLayers.add(xRow.joinToString(", ", prefix = "[", postfix = "]"))
        }

        sb.append(zLayers.joinToString(",\n    "))
        sb.append("]")
        if (y < loaded.height - 1) sb.append(",\n")
    }

    sb.append("\n]")
    return sb.toString()
}
    
// --- 功能 4: 采用与 MapArtGenerator 一致的宽容解析格式恢复 mcstructure ---
    /**
     * @param gridString 导出的类似 [[[ID, ID], [ID, ID]]] 的字符串
     * @param outputFile 目标保存文件
     */
    fun importFromGridString(
    gridString: String,
    outputFile: File,
    prefixRules: List<PrefixRule> = emptyList()
) {
        // 1. 使用与 MapArtGenerator 相同的逻辑解析层级 (Y -> Z -> X)
        val layers = mutableListOf<MutableList<MutableList<String>>>()
        
        var currentDepth = 0
        var currentYList: MutableList<MutableList<String>>? = null
        var currentZList: MutableList<String>? = null
        
        // 正则：匹配 [ , ] 以及引号内的内容
        val regex = Regex("""\[|\]|"[^"]*"|'[^']*'""")
        val tokens = regex.findAll(gridString).map { it.value }.toList()
        
        for (token in tokens) {
            when (token) {
                "[" -> {
                    currentDepth++
                    if (currentDepth == 2) {
                        currentYList = mutableListOf()
                        layers.add(currentYList)
                    } else if (currentDepth == 3) {
                        currentZList = mutableListOf()
                        currentYList?.add(currentZList)
                    }
                }
                "]" -> currentDepth--
                else -> {
                    // 提取方块 ID
                    if (currentDepth >= 3) {
                        val blockId = token.replace("\"", "").replace("'", "")
                        currentZList?.add(blockId)
                    }
                }
            }
        }

        if (layers.isEmpty()) throw IllegalArgumentException("未能在字符串中找到有效的结构层级数据")

        // 2. 转换成 BlockInput 列表
        val blocks = mutableListOf<BlockInput>()
        
        // 结构顺序：layers[y][z][x]
        for (y in layers.indices) {
    val zList = layers[y]
    for (z in zList.indices) {
        val xList = zList[z]
        for (x in xList.indices) {
            val id = xList[x].trim()

            val cleanRawId = if (id.startsWith("minecraft:")) id else "minecraft:$id"
            val (baseId, extraStates) = applyPrefixDecode(cleanRawId, prefixRules)

            if (baseId != "minecraft:air") {
                blocks.add(
                    BlockInput(
                        x = x,
                        y = y,
                        z = z,
                        id = baseId,
                        states = extraStates
                    )
                )
            }
        }
    }
}

        // 3. 调用导出方法
        if (blocks.isEmpty()) {
            // 如果全是空气，创建一个 1x1x1 的空气结构
            export(listOf(BlockInput(0, 0, 0, "minecraft:air")), outputFile)
        } else {
            export(blocks, outputFile)
        }
    }

    // --- 以下是原有的导出逻辑和 NBT 工具 ---

    fun export(blocks: List<BlockInput>, outputFile: File, blockVersion: Int = 17879555) {
        require(blocks.isNotEmpty()) { "blocks 不能为空" }
        val minX = blocks.minOf { it.x }; val minY = blocks.minOf { it.y }; val minZ = blocks.minOf { it.z }
        val maxX = blocks.maxOf { it.x }; val maxY = blocks.maxOf { it.y }; val maxZ = blocks.maxOf { it.z }
        val width = maxX - minX + 1; val height = maxY - minY + 1; val depth = maxZ - minZ + 1

        val paletteMap = LinkedHashMap<BlockStateKey, Int>()
        val volume = width * height * depth
        val primaryIndices = IntArray(volume) { -1 }
        val blockPositionData = LinkedHashMap<String, NbtTag>()

        for (b in blocks) {
            val lx = b.x - minX; val ly = b.y - minY; val lz = b.z - minZ
            val idx = indexOf(lx, ly, lz, width, height, depth)
            val key = BlockStateKey(normalizeBlockId(b.id), b.states)
            primaryIndices[idx] = paletteMap.getOrPut(key) { paletteMap.size }
            
            if (b.blockEntityNbt != null) {
                val nbt = b.blockEntityNbt.toMutableMap()
                nbt["x"] = lx; nbt["y"] = ly; nbt["z"] = lz
                blockPositionData[idx.toString()] = compound("block_entity_data" to nbt)
            }
        }

        val paletteList = paletteMap.keys.map { compound("name" to it.name, "states" to it.states, "version" to blockVersion) }

        val root = compound(
            "format_version" to 1,
            "size" to listOf(width, height, depth),
            "structure_world_origin" to listOf(0, 0, 0),
            "structure" to mapOf(
                "block_indices" to listOf(primaryIndices.toList(), IntArray(volume) { -1 }.toList()),
                "entities" to emptyList<Any>(),
                "palette" to mapOf("default" to mapOf("block_palette" to paletteList, "block_position_data" to blockPositionData))
            )
        )

        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { fos -> BufferedOutputStream(fos).use { out -> NbtWriter(out).writeRoot(root) } }
    }

    private fun normalizeBlockId(raw: String): String = if (':' in raw) raw.lowercase() else "minecraft:${raw.lowercase()}"
    // sx: width(X), sy: height(Y), sz: depth(Z)
private fun indexOf(x: Int, y: Int, z: Int, sx: Int, sy: Int, sz: Int): Int {
    // 基岩版标准索引公式: (x * height * depth) + (y * depth) + z
    return (x * sy + y) * sz + z
}

    private fun nbtToMap(tag: NbtTag.CompoundTag): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        tag.value.forEach { (k, v) -> map[k] = tagToValue(v) }
        return map
    }

    private fun tagToValue(tag: NbtTag): Any? = when (tag) {
        is NbtTag.ByteTag -> tag.value
        is NbtTag.ShortTag -> tag.value
        is NbtTag.IntTag -> tag.value
        is NbtTag.LongTag -> tag.value
        is NbtTag.FloatTag -> tag.value
        is NbtTag.DoubleTag -> tag.value
        is NbtTag.StringTag -> tag.value
        is NbtTag.ByteArrayTag -> tag.value
        is NbtTag.IntArrayTag -> tag.value
        is NbtTag.ListTag -> tag.items.map { tagToValue(it) }
        is NbtTag.CompoundTag -> nbtToMap(tag)
        else -> null
    }

    private fun compound(vararg pairs: Pair<String, Any?>): NbtTag.CompoundTag {
        val map = LinkedHashMap<String, NbtTag>()
        for ((k, v) in pairs) { if (v != null) map[k] = toTag(v) }
        return NbtTag.CompoundTag(map)
    }

    private fun toTag(value: Any?): NbtTag = when (value) {
        is NbtTag -> value
        is Boolean -> NbtTag.ByteTag(if (value) 1 else 0)
        is Byte -> NbtTag.ByteTag(value)
        is Short -> NbtTag.ShortTag(value)
        is Int -> NbtTag.IntTag(value)
        is Long -> NbtTag.LongTag(value)
        is Float -> NbtTag.FloatTag(value)
        is Double -> NbtTag.DoubleTag(value)
        is String -> NbtTag.StringTag(value)
        is ByteArray -> NbtTag.ByteArrayTag(value)
        is IntArray -> NbtTag.IntArrayTag(value)
        is Map<*, *> -> {
            val m = LinkedHashMap<String, NbtTag>()
            value.forEach { (k, v) -> if (k != null && v != null) m[k.toString()] = toTag(v) }
            NbtTag.CompoundTag(m)
        }
        is Iterable<*> -> NbtTag.ListTag(value.map { toTag(it) })
        else -> NbtTag.StringTag(value.toString())
    }

    // --- NBT 定义与读写器 ---

    sealed class NbtTag {
        abstract val id: Byte
        data object End : NbtTag() { override val id: Byte = 0 }
        data class ByteTag(val value: Byte) : NbtTag() { override val id: Byte = 1 }
        data class ShortTag(val value: Short) : NbtTag() { override val id: Byte = 2 }
        data class IntTag(val value: Int) : NbtTag() { override val id: Byte = 3 }
        data class LongTag(val value: Long) : NbtTag() { override val id: Byte = 4 }
        data class FloatTag(val value: Float) : NbtTag() { override val id: Byte = 5 }
        data class DoubleTag(val value: Double) : NbtTag() { override val id: Byte = 6 }
        data class ByteArrayTag(val value: ByteArray) : NbtTag() { override val id: Byte = 7 }
        data class StringTag(val value: String) : NbtTag() { override val id: Byte = 8 }
        data class ListTag(val items: List<NbtTag>) : NbtTag() { override val id: Byte = 9 }
        data class CompoundTag(val value: LinkedHashMap<String, NbtTag>) : NbtTag() { override val id: Byte = 10 }
        data class IntArrayTag(val value: IntArray) : NbtTag() { override val id: Byte = 11 }
    }

    private class NbtReader(private val input: InputStream) {
        fun readRoot(): NbtTag {
            val type = input.read()
            if (type == -1 || type == 0) return NbtTag.End
            readString() // 抛弃根节点名称
            return readPayload(type.toByte())
        }

        private fun readPayload(type: Byte): NbtTag = when (type) {
            1.toByte() -> NbtTag.ByteTag(input.read().toByte())
            2.toByte() -> NbtTag.ShortTag(readShortLE())
            3.toByte() -> NbtTag.IntTag(readIntLE())
            4.toByte() -> NbtTag.LongTag(readLongLE())
            5.toByte() -> NbtTag.FloatTag(Float.fromBits(readIntLE()))
            6.toByte() -> NbtTag.DoubleTag(Double.fromBits(readLongLE()))
            7.toByte() -> NbtTag.ByteArrayTag(ByteArray(readIntLE()).also { input.read(it) })
            8.toByte() -> NbtTag.StringTag(readString())
            9.toByte() -> {
                val subType = input.read().toByte()
                val size = readIntLE()
                NbtTag.ListTag(List(size) { readPayload(subType) })
            }
            10.toByte() -> {
                val map = LinkedHashMap<String, NbtTag>()
                while (true) {
                    val subType = input.read().toByte()
                    if (subType == 0.toByte()) break
                    val name = readString()
                    map[name] = readPayload(subType)
                }
                NbtTag.CompoundTag(map)
            }
            11.toByte() -> NbtTag.IntArrayTag(IntArray(readIntLE()) { readIntLE() })
            else -> throw IOException("Unknown NBT Tag: $type")
        }

        private fun readString(): String {
            val len = readShortLE().toInt() and 0xFFFF
            val bytes = ByteArray(len)
            input.read(bytes)
            return String(bytes, StandardCharsets.UTF_8)
        }

        private fun readShortLE() = (input.read() or (input.read() shl 8)).toShort()
        private fun readIntLE() = input.read() or (input.read() shl 8) or (input.read() shl 16) or (input.read() shl 24)
        private fun readLongLE(): Long {
            val l = readIntLE().toLong() and 0xFFFFFFFFL
            val h = readIntLE().toLong() and 0xFFFFFFFFL
            return l or (h shl 32)
        }
    }

    private class NbtWriter(private val out: OutputStream) {
        fun writeRoot(root: NbtTag.CompoundTag) {
            out.write(root.id.toInt()); writeString(""); writePayload(root)
        }
        private fun writePayload(tag: NbtTag) {
            when (tag) {
                is NbtTag.ByteTag -> out.write(tag.value.toInt())
                is NbtTag.ShortTag -> writeShortLE(tag.value.toInt())
                is NbtTag.IntTag -> writeIntLE(tag.value)
                is NbtTag.LongTag -> writeLongLE(tag.value)
                is NbtTag.FloatTag -> writeIntLE(tag.value.toBits())
                is NbtTag.DoubleTag -> writeLongLE(tag.value.toBits())
                is NbtTag.ByteArrayTag -> { writeIntLE(tag.value.size); out.write(tag.value) }
                is NbtTag.StringTag -> writeString(tag.value)
                is NbtTag.ListTag -> {
                    val type = tag.items.firstOrNull()?.id?.toInt() ?: 0
                    out.write(type); writeIntLE(tag.items.size)
                    tag.items.forEach { writePayload(it) }
                }
                is NbtTag.CompoundTag -> {
                    tag.value.forEach { (k, v) -> out.write(v.id.toInt()); writeString(k); writePayload(v) }
                    out.write(0)
                }
                is NbtTag.IntArrayTag -> { writeIntLE(tag.value.size); tag.value.forEach { writeIntLE(it) } }
                else -> {}
            }
        }
        private fun writeString(s: String) {
            val b = s.toByteArray(StandardCharsets.UTF_8); writeShortLE(b.size); out.write(b)
        }
        private fun writeShortLE(v: Int) { out.write(v); out.write(v shr 8) }
        private fun writeIntLE(v: Int) { out.write(v); out.write(v shr 8); out.write(v shr 16); out.write(v shr 24) }
        private fun writeLongLE(v: Long) { writeIntLE(v.toInt()); writeIntLE((v shr 32).toInt()) }
    }
}