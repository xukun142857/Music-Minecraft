package command.plus

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable // 确保只保留这一个
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions // 修正路径
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import java.io.File
import java.io.InputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StructureGeneratorScreen(
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var isGenerating by remember { mutableStateOf(false) }
    
    val prefs = remember { context.getSharedPreferences("StructureGeneratorPrefs", Context.MODE_PRIVATE) }
    
    var showResetDialog by remember { mutableStateOf(false) }

    // 注意：请确保你定义了 rememberPreference 这个自定义的 delegate 扩展函数
    var configMode by rememberPreference("config_mode", "COMMAND", prefs)
    var outputPath by rememberPreference("output_path", "/sdcard/Download", prefs)
    var outputType by rememberPreference("output_type", "内部存储 (应用私有)", prefs)

    var cmdFilePath by rememberPreference("cmd_file_path", "", prefs)
    var maxHeight by rememberPreference("max_height", 32, prefs)
    var zSpacing by rememberPreference("z_spacing", 2, prefs)
    var isExportAsPack by rememberPreference("isExportAsPack", false, prefs)

    var gridFilePath by rememberPreference("grid_file_path", "", prefs)
    var rulesJson by rememberPreference("rules_json", "up_:up,down_:down,north_:north,south_:south,west_:west,east_:east", prefs)
    
    val resetAll = {
        prefs.edit().clear().apply()
        // 恢复默认值
        configMode = "COMMAND"
        outputPath = "/sdcard/Download"
        outputType = "内部存储 (应用私有)"
        cmdFilePath = ""
        maxHeight = 32
        zSpacing = 2
        isExportAsPack = false
        gridFilePath = ""
        rulesJson = "top_:up,bottom_:down"
        Toast.makeText(context, "配置已重置", Toast.LENGTH_SHORT).show()
    }
    
    /**
 * 执行 MCPack 包装逻辑
 * @param file 生成好的 .mcstructure 文件
 * @param shouldPack 是否启用包装的布尔开关
 */
fun handleFinalOutput(file: File, shouldPack: Boolean) {
    if (shouldPack) {
        val packGenerator = MCPackGenerator(file, context.resources.openRawResource(R.drawable.noteblock))
        // 使用 cacheDir 作为临时构建目录，避免污染用户文件夹
        val packFile = packGenerator.generate(context.cacheDir)
        
        if (packFile != null && packFile.exists()) {
            Toast.makeText(context, "📦 已自动包装为 .mcpack", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "❌ MCPack 包装失败", Toast.LENGTH_SHORT).show()
        }
    } else {
        // 不包装，仅保留原 mcstructure 文件
        Toast.makeText(context, "🎉 结构生成成功！", Toast.LENGTH_SHORT).show()
    }
}

    val startGeneration = {
    isGenerating = true
    
    try {
        val dir = context.getExternalFilesDir(null)?.path ?: context.filesDir.path
        
        if (configMode == "COMMAND") {
            // 提取文件对象以供后续处理
            val outputFile = File(
                if (outputType.contains("外部")) outputPath else "$dir/Structure",
                File(cmdFilePath).nameWithoutExtension + ".mcstructure"
            )
            
            val params = BuildParams(
                content = File(cmdFilePath).readText(),
                outputFile = outputFile,
                maxHeight = maxHeight,
                zSpacing = zSpacing
            )
            
            CommandStructureBuilder.build(params) { result ->
                when (result) {
                    is BuildResult.Success -> {
                        // 在成功回调中处理
                        handleFinalOutput(outputFile, isExportAsPack)
                        isGenerating = false
                    }
                    is BuildResult.Error -> {
                        isGenerating = false
                        Toast.makeText(context, "❌ 错误: ${result.throwable.message}", Toast.LENGTH_LONG).show()
                    }
                    else -> {}
                }
            }
        } else {
            // 文本阵列模式
            val outputFile = File(
                if (outputType.contains("外部")) outputPath else "$dir/Structure",
                File(gridFilePath).nameWithoutExtension + ".mcstructure"
            )
            
            val ruleList = rulesJson.split(",").filter { it.contains(":") }.map {
                val parts = it.split(":")
                McStructureExporter.PrefixRule(parts[0], mapOf("facing" to parts[1]))
            }
            
            McStructureExporter.importFromGridString(
                File(gridFilePath).readText(),
                outputFile,
                ruleList
            )

            // 执行处理逻辑
            handleFinalOutput(outputFile, isExportAsPack)
            
            isGenerating = false
            
        }
    } catch (e: Exception) {
        isGenerating = false
        Toast.makeText(context, "❌ 运行失败: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("生成结构文件") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                onClick = { startGeneration() },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp),
                enabled = !isGenerating
            ) {
                if (isGenerating) CircularProgressIndicator(modifier = Modifier.size(24.dp))
                else Text("立即开始生成")
            }

            InputConfigCard(
                mode = configMode,
                onModeChange = { configMode = it },
                cmdPath = cmdFilePath,
                onCmdPathChange = { cmdFilePath = it },
                maxHeight = maxHeight,
                onMaxHeightChange = { maxHeight = it }, // 修复点：确保这里接收 Int
                zSpacing = zSpacing,
                onZSpacingChange = { zSpacing = it },   // 修复点：确保这里接收 Int
                gridFilePath = gridFilePath,
                onGridPathChange = { gridFilePath = it },
                rulesString = rulesJson,
                onRulesChange = { rulesJson = it }
            )

            OutputLocationCarda(
                outputType = outputType,
                outputPath = outputPath,
                onTypeChange = { outputType = it },
                onPathChange = { outputPath = it },
                isExportAsPack = isExportAsPack,
                onisExportAsPackChange = { isExportAsPack = it },
            )
            
OutlinedButton(
                onClick = { showResetDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("重置所有配置")
            }
        }
    }
    
    // --- 新增：重置确认对话框 ---
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("重置所有设置？") },
            text = { Text("这将清除所有已保存的路径、映射规则和参数配置，恢复到初始状态。") },
            confirmButton = {
                TextButton(
                    onClick = {
                        resetAll()
                        showResetDialog = false
                    }
                ) {
                    Text("确定重置", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
    

    
    
}

@Composable
fun InputConfigCard(
    mode: String, onModeChange: (String) -> Unit,
    cmdPath: String, onCmdPathChange: (String) -> Unit,
    maxHeight: Int, onMaxHeightChange: (Int) -> Unit,
    zSpacing: Int, onZSpacingChange: (Int) -> Unit,
    gridFilePath: String, onGridPathChange: (String) -> Unit,
    rulesString: String, onRulesChange: (String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("输入配置", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            // 模式选择
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = mode == "COMMAND", onClick = { onModeChange("COMMAND") })
                Text("导入命令文件", modifier = Modifier.clickable { onModeChange("COMMAND") })
                Spacer(Modifier.width(16.dp))
                RadioButton(selected = mode == "GRID", onClick = { onModeChange("GRID") })
                Text("导入文本阵列", modifier = Modifier.clickable { onModeChange("GRID") })
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            // 区域1：命令文件配置
            AnimatedVisibility(visible = mode == "COMMAND") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cmdPath, onValueChange = onCmdPathChange, label = { Text("命令文件路径 (.txt)") }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = maxHeight.toString(),
                            onValueChange = { onMaxHeightChange(it.toIntOrNull() ?: 0) },
                            label = { Text("命令方块换列高度 (默认为32)") },
                            modifier = Modifier.weight(1f),
                            //keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                        OutlinedTextField(
                            value = zSpacing.toString(),
                            onValueChange = { onZSpacingChange(it.toIntOrNull() ?: 0) },
                            label = { Text("命令方块组别间隔数 (默认为2)") },
                            modifier = Modifier.weight(1f),
                            //keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }
            }

            // 区域2：文本阵列配置
            AnimatedVisibility(visible = mode == "GRID") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = gridFilePath, onValueChange = onGridPathChange, label = { Text("文本阵列路径 (.txt)") }, modifier = Modifier.fillMaxWidth())
                    
                    Text("规则映射 (Prefix → Facing)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    
                    // 解析规则字符串并显示 UI
                    val rules = rulesString.split(",").filter { it.isNotEmpty() }
                    rules.forEachIndexed { index, rule ->
                        val parts = rule.split(":")
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedTextField(value = parts.getOrNull(0) ?: "", onValueChange = {}, label = {Text("前缀")}, modifier = Modifier.weight(1f), readOnly = true)
                            Icon(Icons.Default.ArrowForward, contentDescription = null)
                            OutlinedTextField(value = parts.getOrNull(1) ?: "", onValueChange = {}, label = {Text("朝向")}, modifier = Modifier.weight(1f), readOnly = true)
                            IconButton(onClick = {
                                val newList = rules.toMutableList().apply { removeAt(index) }
                                onRulesChange(newList.joinToString(","))
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                            }
                        }
                    }

                    // 添加新规则的简单输入行
                    var newPrefix by remember { mutableStateOf("") }
                    var newFace by remember { mutableStateOf("") }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextField(value = newPrefix, onValueChange = {newPrefix = it}, placeholder = {Text("top_")}, modifier = Modifier.weight(1f))
                        TextField(value = newFace, onValueChange = {newFace = it}, placeholder = {Text("up")}, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            if(newPrefix.isNotBlank()){
                                onRulesChange(if(rulesString.isEmpty()) "$newPrefix:$newFace" else "$rulesString,$newPrefix:$newFace")
                                newPrefix = ""; newFace = ""
                            }
                        }) {
                            Icon(Icons.Default.AddCircle, contentDescription = "Add", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

// 确保文件中只有一个 OutputLocationCard 定义！
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutputLocationCarda(
    outputType: String, 
    outputPath: String, 
    onTypeChange: (String) -> Unit, 
    onPathChange: (String) -> Unit,
    isExportAsPack: Boolean, onisExportAsPackChange: (Boolean) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    val options = listOf("内部存储 (应用私有)", "外部存储 (公共目录)")

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("输出设置", fontWeight = FontWeight.Bold)
            
            ExposedDropdownMenuBox(
                expanded = expanded, 
                onExpandedChange = { expanded = it }
            ) {
                OutlinedTextField(
                    value = outputType, 
                    onValueChange = {}, 
                    readOnly = true,
                    label = { Text("输出位置类型") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.fillMaxWidth().menuAnchor()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { selectionOption ->
                        DropdownMenuItem(
                            text = { Text(selectionOption) },
                            onClick = { 
                                onTypeChange(selectionOption)
                                expanded = false 
                            }
                        )
                    }
                }
            }
            
            if (outputType.contains("外部存储")) {
                OutlinedTextField(
                    value = outputPath, 
                    onValueChange = onPathChange,
                    label = { Text("输出目录绝对路径") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("是否包装为mcpack", style = MaterialTheme.typography.titleMedium)
                        Switch(checked = isExportAsPack, onCheckedChange = onisExportAsPackChange)
                    }
        }
    }
}

