package command.plus

import java.io.File
import java.io.FileOutputStream
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.io.InputStream

/**
 * MCPack 生成器
 * @param sourceFile 生成好的 .mcstructure 源文件
 * @param author 作者名称
 */
class MCPackGenerator(
    private val sourceFile: File,
    private val iconStream: InputStream? = null,
    private val author: String = "KotlinGenerator"
) {
    private val structureName = sourceFile.nameWithoutExtension
    private val uuidHeader = UUID.randomUUID().toString()
    private val uuidModule = UUID.randomUUID().toString()
    
    // 在 Android 中，建议将临时构建目录放在 cacheDir 下
    fun generate(cacheDir: File): File? {
        val buildDir = File(cacheDir, "temp_pack_${System.currentTimeMillis()}")
        val outputFile = File(sourceFile.parentFile, "$structureName.mcpack")

        try {
            // 1. 清理并创建目录结构
            if (buildDir.exists()) buildDir.deleteRecursively()
            val structuresDir = File(buildDir, "structures").apply { mkdirs() }
            val functionsDir = File(buildDir, "functions").apply { mkdirs() }

            // 2. 移动 mcstructure 文件
            if (sourceFile.exists()) {
                sourceFile.copyTo(File(structuresDir, "$structureName.mcstructure"), overwrite = true)
            } else {
                return null
            }

            // 3. 生成 .mcfunction 文件
            val functionFile = File(functionsDir, "load.mcfunction")
            functionFile.writeText("structure load \"$structureName\" ~ ~2 ~")

            // 4. 生成 manifest.json
            val manifestJson = """
            {
                "format_version": 2,
                "header": {
                    "description": "Pack for §a§l$structureName",
                    "name": "$structureName",
                    "uuid": "$uuidHeader",
                    "version": [1, 0, 0],
                    "min_engine_version": [1, 20, 0]
                },
                "modules": [
                    {
                        "description": "Functions and Structures",
                        "type": "data",
                        "uuid": "$uuidModule",
                        "version": [1, 0, 0]
                    }
                ]
            }
            """.trimIndent()
            File(buildDir, "manifest.json").writeText(manifestJson)
            
            // 4.5 处理 pack_icon.png
iconStream?.use { input ->
    val iconFile = File(buildDir, "pack_icon.png")
    iconFile.outputStream().use { output ->
        input.copyTo(output)
    }
}

            // 5. 压缩为 .mcpack
            zipPack(buildDir, outputFile)

            // 6. 关键步骤：删除原始 mcstructure 文件和临时构建目录
            sourceFile.delete()
            buildDir.deleteRecursively()

            return outputFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun zipPack(sourceDir: File, outputFile: File) {
        ZipOutputStream(FileOutputStream(outputFile)).use { zip ->
            sourceDir.walkTopDown().forEach { file ->
                if (!file.isDirectory) {
                    val entryName = file.relativeTo(sourceDir).path.replace("\\", "/")
                    zip.putNextEntry(ZipEntry(entryName))
                    file.inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
        }
    }
}