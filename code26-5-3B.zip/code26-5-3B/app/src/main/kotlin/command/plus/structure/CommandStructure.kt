package command.plus

import java.io.File


data class BuildParams(
    val content: String,
    val outputFile: File,
    val maxHeight: Int = 50,
    val zSpacing: Int = 2
)

sealed class BuildResult {
    data class Progress(val percent: Int, val message: String) : BuildResult()
    object Success : BuildResult()
    data class Error(val throwable: Throwable) : BuildResult()
}

object CommandStructureBuilder {

    data class BlockConfig(
        val type: Int,        // A: 0脉冲, 1连锁, 2循环
        val conditional: Int, // B: 0无条件, 1有条件
        val redstone: Int,    // C: 0需红石, 1始终开启
        val commands: List<String>
    )

    /**
     * 执行构建任务
     * @param params 输入参数
     * @param onUpdate 回调函数，用于接收进度、错误和完成状态
     */
    fun build(params: BuildParams, onUpdate: (BuildResult) -> Unit) {
        try {
            onUpdate(BuildResult.Progress(0, "正在解析指令文件..."))
            val allConfigs = parseInstructionFile(params.content)
            
            if (allConfigs.isEmpty()) {
                onUpdate(BuildResult.Error(Exception("未在输入内容中找到有效的指令配置 (\$A,B,C)")))
                return
            }

            onUpdate(BuildResult.Progress(20, "正在规划序列逻辑..."))
            val sequences = mutableListOf<MutableList<BlockConfig>>()
            for (config in allConfigs) {
                if (config.type == 0 || config.type == 2 || sequences.isEmpty()) {
                    sequences.add(mutableListOf(config))
                } else {
                    sequences.last().add(config)
                }
            }

            val blocks = mutableListOf<BlockInput>()
            var currentZ = 0
            
            // 逐序列进行布局，并实时计算进度
            sequences.forEachIndexed { index, sequence ->
                val progress = 20 + (index.toFloat() / sequences.size * 60).toInt()
                onUpdate(BuildResult.Progress(progress, "正在布局序列 ${index + 1}/${sequences.size}..."))
                
                blocks.addAll(layoutSequence(sequence, currentZ, params.maxHeight))
                currentZ += params.zSpacing
            }

            onUpdate(BuildResult.Progress(90, "正在导出 .mcstructure 文件..."))
            
            // 假设 McStructureExporter.export 可能抛出 IO 异常
            McStructureExporter.export(blocks, params.outputFile)

            onUpdate(BuildResult.Progress(100, "构建完成！"))
            onUpdate(BuildResult.Success)

        } catch (e: Exception) {
            onUpdate(BuildResult.Error(e))
        }
    }

    private fun layoutSequence(sequence: List<BlockConfig>, z: Int, maxHeight: Int): List<BlockInput> {
        val result = mutableListOf<BlockInput>()
        
        val taskList = sequence.flatMap { config ->
            config.commands.map { cmd -> 
                Triple(cmd, config, config == sequence.first()) 
            }
        }

        var curX = 0
        var curY = 0
        var movingUp = true

        for (i in taskList.indices) {
            val (command, config, _) = taskList[i]
            val isLast = i == taskList.size - 1

            var facing = if (movingUp) 1 else 0 
            val nextY = if (movingUp) curY + 1 else curY - 1

            // 检查边界逻辑
            val needTurn = !isLast && (nextY >= maxHeight || nextY < 0)
            
            if (needTurn) {
                facing = 5 // 向 +X 转向
            }

            val blockId = when (config.type) {
                0 -> "minecraft:command_block"
                2 -> "minecraft:repeating_command_block"
                else -> "minecraft:chain_command_block"
            }

            val states = mapOf(
                "facing_direction" to facing,
                "conditional_bit" to config.conditional
            )

            val nbt = mapOf(
                "id" to "CommandBlock",
                "Command" to command.removePrefix("/"),
                "auto" to config.redstone.toByte(),
                "conditionMet" to 0.toByte(),
                "TrackOutput" to 1.toByte()
            )

            result.add(BlockInput(curX, curY, z, blockId, states, nbt))

            if (needTurn) {
                curX++
                movingUp = !movingUp
            } else {
                curY = nextY
            }
        }
        return result
    }

    private fun parseInstructionFile(content: String): List<BlockConfig> {
        val configs = mutableListOf<BlockConfig>()
        val blockRegex = Regex("""\$(\d),(\d),(\d)\s+([\s\S]*?)(?=\$|$)""")
        blockRegex.findAll(content).forEach { match ->
            val (a, b, c) = match.destructured
            val cmdText = match.groupValues[4]
            val commands = cmdText.lines().map { it.trim() }.filter { it.startsWith("/") }
            if (commands.isNotEmpty()) {
                configs.add(BlockConfig(a.toInt(), b.toInt(), c.toInt(), commands))
            }
        }
        return configs
    }
}