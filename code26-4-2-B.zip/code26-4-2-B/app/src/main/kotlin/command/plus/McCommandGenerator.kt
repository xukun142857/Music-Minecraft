package command.plus

import java.io.File
import java.io.FileOutputStream
import java.util.TreeSet

/**
 * 我的世界 Minecraft 盔甲架命令生成器 (多实体增强版)
 */
class McCommandGenerator private constructor(
    private val inputData: String,
    private val scoreboardObj: String,
    private val entityName: String,
    private val charLimit: Int,
    private val startLength: Int, // X
    private val startDepth: Int,   // Y
    private val startWidth: Int,   // Z
    private val mirrorHorizontal: Boolean,
    private val mirrorVertical: Boolean,
    private val innerAxis: Axis,
    private val innerStep: Int,
    private val outerAxis: Axis,
    private val outerStep: Int,
    private val startScoreOffset: Int,
    private val forbiddenScores: Set<Int>,
    private val generationMultiplier: Int, // 新增：生成倍数
    private val saveFile: File?,
    private val callback: (List<String>) -> Unit
) {

    enum class Axis { 长, 深, 宽 }

    private data class RangeResult(
        var selectorPart: String,
        val corrections: MutableList<Int> = mutableListOf()
    )

    fun generate() {
        try {
            var matrix = parseInput(inputData)
            if (matrix.isEmpty()) {
                callback(emptyList())
                return
            }

            matrix = applyMirror(matrix)
            val commands = generateCommands(matrix)

            saveFile?.let { file ->
                try {
                    file.parentFile?.mkdirs()
                    FileOutputStream(file).use { fos ->
                        commands.forEach { line ->
                            fos.write((line + "\n").toByteArray(Charsets.UTF_8))
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            callback(commands)
        } catch (e: Exception) {
            e.printStackTrace()
            callback(emptyList())
        }
    }

    private fun parseInput(data: String): List<List<String>> {
        val matrix = mutableListOf<List<String>>()
        val lines = data.lines()
        val regex = "'([^']*)'|\"([^\"]*)\"".toRegex()

        for (line in lines) {
            var cleanLine = line.trim()
            if (cleanLine.contains(".")) {
                cleanLine = cleanLine.substringAfter(".").trim()
            }
            if (cleanLine.isEmpty()) continue

            val row = regex.findAll(cleanLine).map {
                it.groupValues[1].ifEmpty { it.groupValues[2] }
            }.toList()

            if (row.isNotEmpty()) {
                matrix.add(row)
            }
        }
        return matrix
    }

    private fun applyMirror(matrix: List<List<String>>): List<List<String>> {
        var processed = matrix
        if (mirrorHorizontal) processed = processed.map { it.reversed() }
        if (mirrorVertical) processed = processed.reversed()
        return processed
    }

    private fun getConsecutiveRanges(numbers: List<Int>): List<String> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val ranges = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val x = sorted[i]
            if (x == prev + 1) {
                prev = x
            } else {
                ranges.add(if (start == prev) "$start" else "$start..$prev")
                start = x
                prev = x
            }
        }
        ranges.add(if (start == prev) "$start" else "$start..$prev")
        return ranges
    }

    private fun getSafeRange(start: Int, end: Int, allTimesInChain: Set<Int>): RangeResult {
        var finalStart = start
        var finalEnd = end
        val res = RangeResult(selectorPart = "")

        if (forbiddenScores.contains(start) && !isConsecutiveForbidden(start)) {
            finalStart = start - 1
            if (!allTimesInChain.contains(finalStart)) res.corrections.add(finalStart)
        }

        if (forbiddenScores.contains(end) && !isConsecutiveForbidden(end)) {
            finalEnd = end + 1
            if (!allTimesInChain.contains(finalEnd)) res.corrections.add(finalEnd)
        }

        res.selectorPart = if (finalStart == finalEnd) "$scoreboardObj=!$finalStart" else "$scoreboardObj=!$finalStart..$finalEnd"
        return res
    }

    private fun isConsecutiveForbidden(valNum: Int): Boolean = forbiddenScores.contains(valNum - 1) || forbiddenScores.contains(valNum + 1)

    private fun buildSafeRanges(numbers: List<Int>): List<RangeResult> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val allTimesInChain = sorted.toSet()
        val results = mutableListOf<RangeResult>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur != prev + 1) {
                results.add(getSafeRange(start, prev, allTimesInChain))
                start = cur
            }
            prev = cur
        }
        results.add(getSafeRange(start, prev, allTimesInChain))
        return results
    }

    private fun buildSetblockCommands(blockId: String, scores: List<Int>): List<String> {
        val rangeResults = buildSafeRanges(scores)
        if (rangeResults.isEmpty()) return emptyList()

        val cmds = mutableListOf<String>()
        val currentSelectors = mutableListOf<String>()
        val currentCorrections = TreeSet<Int>()

        // 移除 [name="..."]
        val prefix = "/execute as @e at @s unless entity @s[scores={"
        val suffixStart = "}]"
        val runPart = " run setblock ~ ~ ~ $blockId"

        var currentLen = prefix.length + suffixStart.length + runPart.length + 10

        for (rr in rangeResults) {
            val partLen = rr.selectorPart.length + 1
            var correctionExtraLen = 0
            for (c in rr.corrections) {
                if (!currentCorrections.contains(c)) {
                    correctionExtraLen += (scoreboardObj.length + c.toString().length + 2)
                }
            }
            if (currentCorrections.isEmpty() && rr.corrections.isNotEmpty()) correctionExtraLen += 30

            if (charLimit > 0 && currentLen + partLen + correctionExtraLen > charLimit) {
                flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
                currentSelectors.clear()
                currentCorrections.clear()
                currentLen = prefix.length + suffixStart.length + runPart.length + 10
            }

            currentSelectors.add(rr.selectorPart)
            currentCorrections.addAll(rr.corrections)
            currentLen += (partLen + correctionExtraLen)
        }

        flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
        return cmds
    }

    private fun flushSetblockCommand(out: MutableList<String>, selectors: List<String>, corrections: Set<Int>, blockId: String) {
        if (selectors.isEmpty()) return
        val sb = StringBuilder()
        // 移除 [name="..."]
        sb.append("/execute as @e at @s unless entity @s[scores={")
            .append(selectors.joinToString(","))
            .append("}]")

        if (corrections.isNotEmpty()) {
            sb.append(" unless entity @s[scores={")
            var count = 0
            for (c in corrections) {
                sb.append(scoreboardObj).append("=").append(c)
                count++
                if (count < corrections.size) sb.append(",")
            }
            sb.append("}]")
        }
        sb.append(" run setblock ~ ~ ~ ").append(blockId)
        out.add(sb.toString())
    }

    private fun generateCommands(matrix: List<List<String>>): List<String> {
    val cmds = mutableListOf<String>()
    val rowLength = matrix.firstOrNull()?.size ?: 0 // "长"
    val totalRows = matrix.size // "宽"
    val totalBlocks = rowLength * totalRows
    
    if (totalBlocks == 0) return emptyList()

    // 确定实际生成的实体数量
    val actualCount = if (totalBlocks % generationMultiplier == totalBlocks) 1 else generationMultiplier
    val names = List(actualCount) { if (it == 0) entityName else "$entityName$it" }
    val unlessNamesPart = names.joinToString(",") { "name=!$it" }

    // ===== 初始化指令 =====
    cmds.add("### 初始化指令 ###")
    cmds.add("$0,0,0")
    cmds.add("/scoreboard objectives add $scoreboardObj dummy")
    cmds.add("$")

    cmds.add("$1,0,1")
    
    // 计算整个扫描阵列的覆盖范围
    var endLength = startLength
    var endWidth = startWidth
    
    val innerTotalMove = innerStep * (rowLength - 1)
    val outerTotalMove = outerStep * (totalRows - 1)
    
    // 根据轴配置计算最终点的坐标偏移
    if (innerAxis == Axis.长) endLength += innerTotalMove
    if (outerAxis == Axis.长) endLength += outerTotalMove
    if (innerAxis == Axis.宽) endWidth += innerTotalMove
    if (outerAxis == Axis.宽) endWidth += outerTotalMove
    
    val minX = minOf(startLength, endLength)
    val maxX = maxOf(startLength, endLength)
    val minZ = minOf(startWidth, endWidth)
    val maxZ = maxOf(startWidth, endWidth)
    
    // 每 256 格划分为一个常加载区（基岩版建议值）
    for (sx in minX..maxX step 256) {
        val ex = minOf(sx + 255, maxX)
        for (sz in minZ..maxZ step 256) {
            val ez = minOf(sz + 255, maxZ)
            cmds.add("/tickingarea add $sx 0 $sz $ex 0 $ez")
        }
    }
    
    val remainder = totalBlocks % generationMultiplier
    
    for (n in 0 until actualCount) {
        val currentName = names[n]
        
        if (n == 0) {
            // 第一个实体：始终在起始点
            cmds.add("/summon armor_stand $startLength $startDepth $startWidth ~ ~ . $currentName")
            cmds.add("/execute as @e[name=\"$currentName\"] run scoreboard players set @s $scoreboardObj ${startScoreOffset + 1}")
        } else {
            // 计算当前实体的逻辑索引 (posIdx)
            val posIdx: Int = if (remainder != 0 && n == actualCount - 1) {
                // 最后一个实体的特殊逻辑索引
                totalBlocks - remainder + 1
            } else {
                // 中间实体的逻辑索引
                val stepSize = if (remainder == 0) totalBlocks / generationMultiplier 
                               else (totalBlocks - remainder) / generationMultiplier
                stepSize * n + 1
            }

            // --- 坐标与分数核心算法 ---
            val modVal = posIdx % rowLength
            val divVal = posIdx / rowLength // Kotlin 整数除法默认向下取整

            val (offsetInner, offsetOuter, finalScore) = if (modVal == 0) {
                // 情况：(posIdx / rowLength) 的余数为 0
                Triple(
                    (posIdx / rowLength - 1) * innerStep,
                    divVal * outerStep,
                    (posIdx / rowLength) + divVal * rowLength
                )
            } else {
                // 情况：正常有余数
                Triple(
                    (modVal - 1) * innerStep,
                    divVal * outerStep,
                    modVal + divVal * rowLength
                )
            }

            // 计算最终绝对物理坐标 (转为 Long 以确保输出不带小数点)
            val finalCoords = mutableMapOf(Axis.长 to startLength.toLong(), Axis.深 to startDepth.toLong(), Axis.宽 to startWidth.toLong())
            
            // 将偏移应用到对应的轴
            finalCoords[innerAxis] = finalCoords[innerAxis]!! + offsetInner
            finalCoords[outerAxis] = finalCoords[outerAxis]!! + offsetOuter
            
            // 生成指令 (使用 .toLong() 确保无小数点)
            cmds.add("/summon armor_stand ${finalCoords[Axis.长]} ${finalCoords[Axis.深]} ${finalCoords[Axis.宽]} ~ ~ . $currentName")
            cmds.add("/execute as @e[name=\"$currentName\"] run scoreboard players set @s $scoreboardObj ${startScoreOffset + finalScore}")
        }
    }
    cmds.add("$")
    cmds.add("")

    // ===== 循环命令链 =====
    cmds.add("### 循环命令链 ###")
    cmds.add("$2,0,0")
    
    // 获取第一个 setblock 命令并放入循环链
    val flatBlocks = matrix.flatten()
    val blockMap = mutableMapOf<String, MutableList<Int>>()
    flatBlocks.forEachIndexed { i, blockId ->
        blockMap.getOrPut(blockId) { mutableListOf() }.add(startScoreOffset + i + 1)
    }
    val firstBlockCommands = if (blockMap.isNotEmpty()) {
        val firstEntry = blockMap.entries.first()
        buildSetblockCommands(firstEntry.key, firstEntry.value)
    } else emptyList()
    if (firstBlockCommands.isNotEmpty()) {
        cmds.add(firstBlockCommands.first())
    }
    cmds.add("$")

    // ===== 步进与加分部分 =====
    cmds.add("$1,0,1")
    // 换行逻辑 (保持原逻辑，针对所有实体)
    val rowEndIndices = mutableListOf<Int>()
    var acc = 0
    matrix.forEach { acc += it.size; rowEndIndices.add(acc) }

    val jumpScores = rowEndIndices.dropLast(1).map { startScoreOffset + it + 1}
    if (jumpScores.isNotEmpty()) {
        val jumpRanges = getConsecutiveRanges(jumpScores)
        val scoreSelector = jumpRanges.joinToString(",") { "$scoreboardObj=!$it" }
        val tpCoords = arrayOf("~", "~", "~")
        when (innerAxis) {
            Axis.长 -> tpCoords[0] = startLength.toString()
            Axis.深 -> tpCoords[1] = startDepth.toString()
            Axis.宽 -> tpCoords[2] = startWidth.toString()
        }
        val idxOuter = when(outerAxis) { Axis.长 -> 0; Axis.深 -> 1; Axis.宽 -> 2 }
        tpCoords[idxOuter] = "~$outerStep"
        cmds.add("/execute as @e at @s unless entity @s[scores={$scoreSelector}] run tp ${tpCoords.joinToString(" ")}")
    }

    // 放置方块 (排除第一个方块，因为它已经在循环链中)
    var isFirstBlock = true
    for ((blockId, scores) in blockMap) {
        if (isFirstBlock) {
            isFirstBlock = false
            continue // 跳过第一个方块
        }
        cmds.addAll(buildSetblockCommands(blockId, scores))
    }

    // 步进与加分：使用 unless entity @s[name=!...]
    val stepCoords = arrayOf("~", "~", "~")
    val innerIdx = when(innerAxis) { Axis.长 -> 0; Axis.深 -> 1; Axis.宽 -> 2 }
    stepCoords[innerIdx] = "~$innerStep"
    
    cmds.add("/execute as @e unless entity @s[$unlessNamesPart] at @s run tp ${stepCoords.joinToString(" ")}")
    cmds.add("/execute as @e unless entity @s[$unlessNamesPart] run scoreboard players add @s $scoreboardObj 1")

    // ===== Kill 指令移到最后 =====
    // 收集所有实体的第一个分值
    val killScores = mutableListOf<Int>()
    for (n in 0 until actualCount) {
        val firstScore: Int = if (n == 0) {
            startScoreOffset + 1 // 第一个实体从 1 开始
        } else {
            val posIdx: Int = if (remainder != 0 && n == actualCount - 1) {
                totalBlocks - remainder + 1
            } else {
                val stepSize = if (remainder == 0) totalBlocks / generationMultiplier 
                               else (totalBlocks - remainder) / generationMultiplier
                stepSize * n + 1
            }
            
            val modVal = posIdx % rowLength
            val divVal = posIdx / rowLength
            
            val finalScore = if (modVal == 0) {
                (posIdx / rowLength) + divVal * rowLength
            } else {
                modVal + divVal * rowLength
            }
            startScoreOffset + finalScore
        }
        killScores.add(firstScore)
    }

    // 生成 Kill 指令
    val killScoreRanges = getConsecutiveRanges(killScores)
    val killScoreSelector = killScoreRanges.joinToString(",") { "$scoreboardObj=!$it" }
    cmds.add("/execute as @e unless entity @s[scores={$killScoreSelector}] run kill @s")
    cmds.add("$")

    return cmds
}

    class Builder {
        private var saveFile: File? = null
        private var inputData: String = ""
        private var scoreboardObj: String = "n"
        private var entityName: String = "C"
        private var charLimit: Int = 10000
        private var startLength: Int = 0
        private var startDepth: Int = 0
        private var startWidth: Int = 0
        private var mirrorHorizontal: Boolean = false
        private var mirrorVertical: Boolean = false
        private var innerAxis: Axis = Axis.长
        private var innerStep: Int = 1
        private var outerAxis: Axis = Axis.宽
        private var outerStep: Int = 1
        private var startScoreOffset: Int = 0
        private var forbiddenScores: Set<Int> = emptySet()
        private var generationMultiplier: Int = 1 // 默认 1
        private var callback: ((List<String>) -> Unit)? = null

        fun setInputData(data: String) = apply { this.inputData = data }
        fun setScoreboardObj(obj: String) = apply { this.scoreboardObj = obj }
        fun setEntityName(name: String) = apply { this.entityName = name }
        fun setCharLimit(limit: Int) = apply { this.charLimit = limit }
        fun setStartCoords(长: Int, 深: Int, 宽: Int) = apply {
            this.startLength = 长
            this.startDepth = 深
            this.startWidth = 宽
        }
        fun setMirror(horizontal: Boolean, vertical: Boolean) = apply {
            this.mirrorHorizontal = horizontal
            this.mirrorVertical = vertical
        }
        fun setAxisConfig(innerAxis: Axis, innerStep: Int, outerAxis: Axis, outerStep: Int) = apply {
            require(innerAxis != outerAxis) { "内部行进轴和换行轴不能是同一个！" }
            this.innerAxis = innerAxis
            this.innerStep = innerStep
            this.outerAxis = outerAxis
            this.outerStep = outerStep
        }
        fun setStartScoreOffset(offset: Int) = apply { this.startScoreOffset = offset }
        fun setForbiddenScores(values: Set<Int>) = apply { this.forbiddenScores = values }
        fun setGenerationMultiplier(m: Int) = apply { this.generationMultiplier = if (m < 1) 1 else m }
        fun setCallback(callback: (List<String>) -> Unit) = apply { this.callback = callback }
        fun setOutputFile(path: String) = apply {
            this.saveFile = File(path)
        }

        fun setOutputFile(file: File) = apply {
            this.saveFile = file
        }

        fun build(): McCommandGenerator {
            requireNotNull(callback) { "必须设置 Callback" }
            return McCommandGenerator(
                inputData, scoreboardObj, entityName, charLimit, startLength, startDepth, startWidth,
                mirrorHorizontal, mirrorVertical, innerAxis, innerStep, outerAxis, outerStep,
                startScoreOffset, forbiddenScores, generationMultiplier, saveFile, callback!!
            )
        }
    }
}