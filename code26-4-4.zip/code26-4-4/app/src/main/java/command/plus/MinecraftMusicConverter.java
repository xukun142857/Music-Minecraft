package command.plus;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.io.File;
import java.nio.file.Files;
import java.util.regex.Pattern;

/**
 * MinecraftMusicConverter
 *
 * 将你给出的 Python 脚本逻辑转换为 Java（Android friendly）实现。
 * 使用 Builder 配置，输入为一段字符串（每行一个 note）。
 */
public class MinecraftMusicConverter {

    // ---------- 配置项 ----------
    private final int MODE;
    private final String SCOREBOARD_NAME;
    private final int START_OFFSET;
    private final boolean ENABLE_STACKING;
    private final int MAX_CHARS; // 0 表示无限制
    private final String inputString;

    private MinecraftMusicConverter(Builder b) {
        this.MODE = b.MODE;
        this.SCOREBOARD_NAME = b.SCOREBOARD_NAME;
        this.START_OFFSET = b.START_OFFSET;
        this.ENABLE_STACKING = b.ENABLE_STACKING;
        this.MAX_CHARS = b.MAX_CHARS;
        this.inputString = b.inputString;
    }

    public static class Builder {
        private int MODE = 0;
        private String SCOREBOARD_NAME = "t";
        private int START_OFFSET = 0;
        private boolean ENABLE_STACKING = true;
        private int MAX_CHARS = 3000;
        private String inputString = "";

        public Builder setMode(int mode) { this.MODE = mode; return this; }
        public Builder setScoreboardName(String name) { this.SCOREBOARD_NAME = name; return this; }
        public Builder setStartOffset(int offset) { this.START_OFFSET = offset; return this; }
        public Builder setEnableStacking(boolean v) { this.ENABLE_STACKING = v; return this; }
        public Builder setMaxChars(int chars) { this.MAX_CHARS = chars; return this; }
        public Builder setInputString(String s) { this.inputString = s; return this; }

        public MinecraftMusicConverter build() { return new MinecraftMusicConverter(this); }
    }

    // ---------- Note 数据类 ----------
    private static class Note {
        int time;
        String inst;
        String pitch;
        String volume; // could be "1" or "e.volume" or numeric string

        Note(int time, String inst, String pitch, String volume) {
            this.time = time;
            this.inst = inst;
            this.pitch = pitch;
            this.volume = volume;
        }
    }

    // ---------- 解析输入字符串 ----------
    private List<Note> parseInputString(String input) {
        List<Note> notes = new ArrayList<>();
        if (input == null || input.trim().isEmpty()) return notes;

        // 支持三或者四个字段：time inst pitch [volume]
        Pattern pattern = Pattern.compile("^\\s*(\\d+)\\s+([A-Za-z0-9_.]+)\\s+([A-Za-z0-9_.]+)(?:\\s+([A-Za-z0-9_.]+))?\\s*$");
        String[] lines = input.split("\\r?\\n");
        for (String line : lines) {
            Matcher m = pattern.matcher(line);
            if (m.matches()) {
                int t = Integer.parseInt(m.group(1));
                String inst = m.group(2);
                String pitch = m.group(4);
                String vol = (m.group(3) != null) ? m.group(3) : "1"; // 默认 volume 为 1
                notes.add(new Note(t, inst, pitch, vol));
            }
        }
        // 按时间排序
        notes.sort(Comparator.comparingInt(n -> n.time));
        return notes;
    }

    // ---------- 将时间列表转换为排除片段 (e.g. t=!10 或 t=!20..30) ----------
    private List<String> getExclusionRanges(List<Integer> times) {
        List<String> ranges = new ArrayList<>();
        if (times == null || times.isEmpty()) return ranges;

        // 去重并排序
        TreeSet<Integer> ts = new TreeSet<>(times);
        List<Integer> sorted = new ArrayList<>(ts);
        int start = sorted.get(0);
        int prev = start;
        for (int i = 1; i < sorted.size(); i++) {
            int cur = sorted.get(i);
            if (cur == prev + 1) {
                prev = cur;
            } else {
                if (start == prev) {
                    ranges.add(SCOREBOARD_NAME + "=!" + start);
                } else {
                    ranges.add(SCOREBOARD_NAME + "=!" + start + ".." + prev);
                }
                start = cur;
                prev = cur;
            }
        }
        // 最后一段
        if (start == prev) {
            ranges.add(SCOREBOARD_NAME + "=!" + start);
        } else {
            ranges.add(SCOREBOARD_NAME + "=!" + start + ".." + prev);
        }
        return ranges;
    }

    // ---------- 写入一组 selector 片段为一个或多个指令（处理字符上限） ----------
    private void writeCommandBlock(StringBuilder out, List<Integer> times, String inst, String pitch, String volume) {
        List<String> selectorParts = getExclusionRanges(times);
        if (selectorParts.isEmpty()) return;

        String prefix = "/execute as @a[scores={"+SCOREBOARD_NAME+"=!" + (START_OFFSET - 1) + "}] at @s unless entity @s[scores={";
        String suffix = "}] run playsound " + inst + " @s ~ ~ ~ " + volume + " " + pitch;

        int baseLen = prefix.length() + suffix.length() + 1; // +1 for newline
        List<String> currentParts = new ArrayList<>();
        int currentLen = baseLen;

        for (String part : selectorParts) {
            // 每个 part 写成 "t=!10" 等形式，之间用逗号分开
            int partLen = part.length() + 1; // 逗号
            if (MAX_CHARS > 0 && (currentLen + partLen > MAX_CHARS)) {
                // flush
                if (!currentParts.isEmpty()) {
                    String fullSelector = String.join(",", currentParts);
                    out.append(prefix).append(fullSelector).append(suffix).append("\n");
                }
                currentParts.clear();
                currentParts.add(part);
                currentLen = baseLen + part.length();
            } else {
                currentParts.add(part);
                currentLen += partLen;
            }
        }
        if (!currentParts.isEmpty()) {
            String fullSelector = String.join(",", currentParts);
            out.append(prefix).append(fullSelector).append(suffix).append("\n");
        }
    }

    // ---------- 生成模式1（相对延迟） ----------
    private String generateMode1(List<Note> notes) {
        StringBuilder out = new StringBuilder();
        if (notes == null || notes.isEmpty()) return out.toString();

        int prevTime = 0;
        int count = 0;
        for (Note n : notes) {
            int delay = Math.max(0, n.time - prevTime);
            String cmd = delay + " /playsound note." + n.inst + " @a ~ ~ ~ " + n.volume + " " + n.pitch + "\n";

            // 根据要求插入 $ 标记：
            // 在第一条指令的上方生成 $0,0,0，下方生成 $
            // 在第二条指令上面生成 $1,0,1
            // 在最后一条指令下面生成 $
            if (count == 0) {
                out.append("$0,0,0\n");    // 上方
                out.append(cmd);
                out.append("$\n");        // 第一条下方
            } else if (count == 1) {
                out.append("$1,0,1\n");   // 第二条上方
                out.append(cmd);
            } else {
                out.append(cmd);
            }

            prevTime = n.time;
            count++;
        }
        // 最后一条指令下面生成 $
        out.append("$\n");
        return out.toString();
    }

    // ---------- 生成模式2（计分板控制） ----------
    private String generateMode2(List<Note> notes) {
        StringBuilder out = new StringBuilder();
        if (notes == null || notes.isEmpty()) return out.toString();

        // 应用偏移量
        List<Note> processed = new ArrayList<>();
        for (Note n : notes) {
            processed.add(new Note(n.time + START_OFFSET, n.inst, n.pitch, n.volume));
        }
        int lastTime = processed.get(processed.size() - 1).time;

        // 组织数据：按 (inst, pitch, volume) 分组（支持相同 inst+pitch 但不同 volume 的情况）
        // 使用 LinkedHashMap 保持插入顺序（尽量与原输入顺序对应）
        Map<String, List<Integer>> organized = new LinkedHashMap<>();
        List<String> keyOrder = new ArrayList<>();

        for (Note n : processed) {
            String key = n.inst + "||" + n.pitch + "||" + n.volume;
            if (!organized.containsKey(key)) {
                organized.put(key, new ArrayList<>());
                keyOrder.add(key);
            }
            organized.get(key).add(n.time);
        }

        // --- 头部 ---
        // 在初始化的命令上面和下面分别加上 $0,0,0 与 $
        out.append("$0,0,0\n");
        out.append("=== 初始化 ===\n");
        out.append("/scoreboard players set @a ").append(SCOREBOARD_NAME).append(" ").append(START_OFFSET - 1).append("\n");
        out.append("$\n\n");

        // 循环命令链（并需在其第一条指令上方/下方加入 $2,0,0 与 $）
        out.append("$2,0,0\n");
        out.append("=== 循环命令链 ===\n");
        out.append("/execute as @a[scores={").append(SCOREBOARD_NAME).append("=").append(START_OFFSET - 1).append("..}] run scoreboard players add @s ").append(SCOREBOARD_NAME).append(" 1\n");
        out.append("$\n\n");

        // --- 核心：按乐器种类遍历 ---
        boolean firstInstrumentChainWritten = false;
        for (String key : keyOrder) {
            // parse key
            String[] parts = key.split("\\|\\|", -1);
            String inst = parts[0];
            String pitch = parts[1];
            String volume = parts[2];

            List<Integer> timeList = organized.get(key);
            if (timeList == null || timeList.isEmpty()) continue;

            // 层化处理：把相同时间的叠加分到不同层
            List<List<Integer>> layers = new ArrayList<>();
            // 输入已按时间递增（因为原始 notes 已排序），若不是，先排序
            Collections.sort(timeList);
            for (Integer t : timeList) {
                boolean placed = false;
                for (List<Integer> layer : layers) {
                    if (!layer.get(layer.size() - 1).equals(t)) {
                        layer.add(t);
                        placed = true;
                        break;
                    }
                }
                if (!placed) {
                    List<Integer> newLayer = new ArrayList<>();
                    newLayer.add(t);
                    layers.add(newLayer);
                }
            }
            if (layers.isEmpty()) continue;

            // 如果不启用叠加，只保留第一层
            if (!ENABLE_STACKING) {
                List<List<Integer>> tmp = new ArrayList<>();
                tmp.add(layers.get(0));
                layers = tmp;
            }

            // 在第一个乐器指令链的上面加上 $1,0,1 （仅一次）
            if (!firstInstrumentChainWritten) {
                out.append("$1,0,1\n");
                firstInstrumentChainWritten = true;
            }

            if (layers.size() > 1) {
                out.append("\n# --- ").append(inst).append(" ").append(pitch).append(" (包含重叠) ---\n");
            }

            for (List<Integer> layerTimes : layers) {
                writeCommandBlock(out, layerTimes, inst, pitch, volume);
            }
        }

        // --- 尾部 ---
        out.append("\n/execute as @a[scores={").append(SCOREBOARD_NAME).append("=").append(lastTime).append("}] run scoreboard players reset @s ").append(SCOREBOARD_NAME).append("\n");
        // 在尾部重置下面加上 $
        out.append("$\n");

        return out.toString();
    }

    // ---------- 主转换方法（返回 String） ----------
    public String convertToString() {
        List<Note> notes = parseInputString(this.inputString);
        if (MODE == 1) {
            return generateMode1(notes);
        } else if (MODE == 0) {
            return generateMode2(notes);
        } else {
            return "错误: MODE 配置错误";
        }
    }

    // ---------- 写入到文件（可选） ----------
    public boolean convertToFile(File outputPath) {
        String result = convertToString();
        try (BufferedWriter bw = Files.newBufferedWriter(outputPath.toPath())) {
            bw.write(result);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

}