package command.plus

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.ui.unit.round
import androidx.compose.runtime.snapshots.SnapshotStateList
import android.app.ActivityOptions

import android.util.Log
import java.io.File
import java.io.IOException

import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.appcompat.app.AppCompatActivity
// ---------- 数据模型 ----------
data class FeatureItem(
    val id: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val route: String
)

private const val TAG = "AssetUtils"



// ---------- Activity ----------
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val noteDir = File(getExternalFilesDir(null), "note")
        val scriptDir = File(getExternalFilesDir(null), "script")
        val pngDir = File(getExternalFilesDir(null), "blockpng")

        //if (!noteDir.exists()) {
            copyAssetsFolder(this, "note", noteDir)
        //}
        if (!scriptDir.exists()) {
            copyAssetsFolder(this, "script", scriptDir)
        }
        if (!pngDir.exists()) {
            copyAssetsFolder(this, "blockpng", pngDir)
        }

        setContent {
            MaterialTheme {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = "featureSelection"
                ) {
                    composable("featureSelection") {
                        val defaultFeatures = listOf(
                            FeatureItem("1", "自动操作", Icons.Default.Person, Color(0xFF42A5F5), "scriptCommand"),
                            FeatureItem("2", "指令音符盒", Icons.Default.Analytics, Color(0xFF66BB6A), "musicCommand"),
                            FeatureItem("3", "图片转换", Icons.Default.Analytics, Color(0xFFAB47BC), "ImageTo"),
                            FeatureItem("4", "设置", Icons.Default.Build, Color(0xFFEF5350), "settings"),
                            //FeatureItem("5", "示例5", Icons.Default.Star, Color(0xFFEF5350), "ex5"),
                        )

                        FeatureSelectionScreen(
                            defaultFeatures = defaultFeatures,
                            onNavigate = { route ->
                                when (route) {
                                    "scriptCommand",
                                    "musicCommand",
                                    "settings",
                                    "ImageTo" -> {
                                        navController.navigate(route) {
    launchSingleTop = true

    // 关键 ↓↓↓
    restoreState = true

    popUpTo(navController.graph.startDestinationId) {
        saveState = true
    }
}
                                    }
                                }
                            }
                        )
                    }

                    composable("scriptCommand") {
                        ScriptCommandScreen(
                            onBack = {
    // 只有当前路由不是 startDestination 时才 pop
    if (navController.currentBackStackEntry?.destination?.route != "featureSelection") {
        navController.popBackStack()
    }
}
                        )
                    }

                    composable("musicCommand") {
                        musicCommand(
                            onBack = {
    // 只有当前路由不是 startDestination 时才 pop
    if (navController.currentBackStackEntry?.destination?.route != "featureSelection") {
        navController.popBackStack()
    }
}
                        )
                    }
                    
                    composable("ImageTo") {
                        ImageConversionScreen(
                            onBack = {
    // 只有当前路由不是 startDestination 时才 pop
    if (navController.currentBackStackEntry?.destination?.route != "featureSelection") {
        navController.popBackStack()
    }
}
                        )
                    }

                   composable("settings") {
                        SettingsScreen(
                            onBack = {
    // 只有当前路由不是 startDestination 时才 pop
    if (navController.currentBackStackEntry?.destination?.route != "featureSelection") {
        navController.popBackStack()
    }
}
                        )
                    }
                }
            }
        }
    }
    /**
     * 递归地拷贝 assets 下的 folder 到 targetDir（外部/内部文件目录下的实际文件夹）
     *
     * @param context 上下文
     * @param assetFolder assets 中的相对路径（例如 "note" 或 "script"）
     * @param targetDir 目标文件夹 File（会自动创建）
     */
    fun copyAssetsFolder(context: Context, assetFolder: String, targetDir: File) {
        try {
            if (!targetDir.exists()) {
                if (!targetDir.mkdirs()) {
                    Log.e(TAG, "Failed to create target directory: ${targetDir.absolutePath}")
                    return
                }
            }

            val files = context.assets.list(assetFolder) ?: return

            for (name in files) {
                val assetPath = if (assetFolder.isEmpty()) name else "$assetFolder/$name"
                val outFile = File(targetDir, name)

                val subFiles = context.assets.list(assetPath) ?: emptyArray()

                if (subFiles.isNotEmpty()) {
                    // 是文件夹，递归
                    copyAssetsFolder(context, assetPath, outFile)
                } else {
                    // 是文件，拷贝
                    copyFile(context, assetPath, outFile)
                }
            }
        } catch (e: IOException) {
            Log.e(TAG, "IOException while copying assets from: $assetFolder", e)
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error while copying assets from: $assetFolder", e)
        }
    }

    /**
     * 从 assets 打开 assetPath 并写入到 outFile
     */
    private fun copyFile(context: Context, assetPath: String, outFile: File) {
        try {
            // 确保父目录存在
            outFile.parentFile?.let {
                if (!it.exists()) it.mkdirs()
            }

            context.assets.open(assetPath).use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output, DEFAULT_BUFFER_SIZE)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy asset file: $assetPath -> ${outFile.absolutePath}", e)
        }
    }
    
    
// ---------- 主界面 ----------
@Composable
fun FeatureSelectionScreen(defaultFeatures: List<FeatureItem>, onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("feature_prefs", Context.MODE_PRIVATE) }
    
    // 自定义 Saver：保护未保存的排序列表，使其在深浅色模式切换或屏幕旋转时存活
    val itemsSaver = listSaver<SnapshotStateList<FeatureItem>, String>(
        save = { list -> list.map { it.id } },
        restore = { savedIds ->
            val restoredList = defaultFeatures.sortedBy { item ->
                val index = savedIds.indexOf(item.id)
                if (index != -1) index else Int.MAX_VALUE
            }
            mutableStateListOf(*restoredList.toTypedArray())
        }
    )

    // 使用 rememberSaveable 初始化 items，优先取内存暂存，其次取 SP 缓存，最后用默认
    val items = rememberSaveable(saver = itemsSaver) {
        val savedStr = prefs.getString("feature_order", null)
        val initialList = if (savedStr != null) {
            val orderList = savedStr.split(",")
            defaultFeatures.sortedBy {
                val index = orderList.indexOf(it.id)
                if (index != -1) index else Int.MAX_VALUE
            }
        } else {
            defaultFeatures
        }
        mutableStateListOf(*initialList.toTypedArray())
    }

    // 使用 rememberSaveable 保护编辑模式状态
    var isEditMode by rememberSaveable { mutableStateOf(false) }

    val spanCount = remember(prefs) { prefs.getInt("span_count", 2) }
    val gridState = rememberLazyGridState()
    val density = LocalDensity.current
    
    LaunchedEffect(Unit) {
    val shouldEdit = prefs.getBoolean("trigger_edit_mode", false)
    if (shouldEdit) {
        isEditMode = true
        // 消耗掉这个状态，防止下次打开还是编辑模式
        prefs.edit().putBoolean("trigger_edit_mode", false).apply()
    }
}

    // 拖拽相关状态（不需要存活于配置更改，因为旋转时拖拽自然中断）
    var draggingItem by remember { mutableStateOf<FeatureItem?>(null) }
    var pointerOffset by remember { mutableStateOf(Offset.Zero) }
    var dragItemOffset by remember { mutableStateOf(Offset.Zero) }
    var draggedItemSize by remember { mutableStateOf(IntSize.Zero) }

    Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
        // --- 动态顶部栏 ---
        AnimatedContent(
            targetState = isEditMode,
            label = "topBarAnimation"
        ) { editing ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .height(48.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (editing) {
                    TextButton(onClick = {
                        items.clear()
                        items.addAll(defaultFeatures)
                    }) {
                        Text("重置默认", color = MaterialTheme.colorScheme.error)
                    }
                    Text(
                        text = "调整位置",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(onClick = {
                        // 保存到 SharedPreferences
                        prefs.edit().putString("feature_order", items.joinToString(",") { it.id }).apply()
                        isEditMode = false // 保存并退出
                    }) {
                        Text("确认")
                    }
                } else {
                    Text(
                        text = "功能选择",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                 
                }
            }
        }

        // --- 主体拖拽区域 ---
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(isEditMode) {
                    if (isEditMode) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { offset ->
                                val itemInfo = gridState.layoutInfo.visibleItemsInfo.find {
                                    IntRect(it.offset, it.size).contains(offset.round())
                                }
                                if (itemInfo != null && itemInfo.index in items.indices) {
                                    draggingItem = items[itemInfo.index]
                                    pointerOffset = offset
                                    draggedItemSize = itemInfo.size
                                    dragItemOffset = Offset(
                                        itemInfo.offset.x.toFloat(),
                                        itemInfo.offset.y.toFloat()
                                    )
                                }
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                pointerOffset += dragAmount
                                dragItemOffset += dragAmount

                                val targetItemInfo = gridState.layoutInfo.visibleItemsInfo.find {
                                    it.key != draggingItem?.id &&
                                            IntRect(it.offset, it.size).contains(pointerOffset.round())
                                }

                                if (targetItemInfo != null && draggingItem != null) {
                                    val fromIndex = items.indexOf(draggingItem)
                                    val toIndex = targetItemInfo.index

                                    if (fromIndex != -1 && toIndex != -1 && fromIndex != toIndex) {
                                        items.add(toIndex, items.removeAt(fromIndex))
                                    }
                                }

                                val scrollThreshold = with(density) { 60.dp.toPx() }
                                val viewportHeight = gridState.layoutInfo.viewportSize.height
                                if (pointerOffset.y < scrollThreshold) {
                                    coroutineScope.launch { gridState.scrollBy(-20f) }
                                } else if (pointerOffset.y > viewportHeight - scrollThreshold) {
                                    coroutineScope.launch { gridState.scrollBy(20f) }
                                }
                            },
                            onDragEnd = { draggingItem = null },
                            onDragCancel = { draggingItem = null }
                        )
                    }
                }
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(spanCount),
                state = gridState,
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                itemsIndexed(items, key = { _, it -> it.id }) { index, item ->
                    val isDragging = draggingItem?.id == item.id
                    
                    // 【抖动核心逻辑】：为每个块生成独立的动画时间和起始偏差，确保各抖各的
                    val infiniteTransition = rememberInfiniteTransition(label = "shake")
                    val durationX = remember { (90..130).random() }
                    val durationY = remember { (90..130).random() }
                    val startOffsetX = remember { (0..100).random() }
                    val startOffsetY = remember { (0..100).random() }

                    val translateX by infiniteTransition.animateFloat(
                        initialValue = -0.5f,
                        targetValue = 0.5f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationX, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse,
                            initialStartOffset = StartOffset(startOffsetX)
                        ),
                        label = "shake_x"
                    )
                    
                    val translateY by infiniteTransition.animateFloat(
                        initialValue = -0.5f,
                        targetValue = 0.5f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(durationY, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse,
                            initialStartOffset = StartOffset(startOffsetY)
                        ),
                        label = "shake_y"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1.25f)
                            .then(if (isDragging) Modifier.alpha(0f) else Modifier.alpha(1f))
                            .animateItem() 
                            .graphicsLayer {
                                // 仅在编辑模式、且非拖拽时，应用平移抖动（不旋转）
                                if (isEditMode && !isDragging) {
                                    translationX = translateX.dp.toPx()
                                    translationY = translateY.dp.toPx()
                                }
                            }
                    ) {
                        AnimatedFeatureCardContent(
                            item = item,
                            index = index,
                            isEditMode = isEditMode,
                            onClick = { 
                                if (!isEditMode) onNavigate(item.route) 
                            },
                            scale = 1f
                        )
                    }
                }
            }

            // --- 浮动预览副本 ---
            draggingItem?.let { item ->
                val widthDp = with(density) { draggedItemSize.width.toDp() }
                val heightDp = with(density) { draggedItemSize.height.toDp() }

                Box(
                    modifier = Modifier
                        .size(widthDp, heightDp)
                        .offset { IntOffset(dragItemOffset.x.roundToInt(), dragItemOffset.y.roundToInt()) }
                        .zIndex(10f)
                        .graphicsLayer {
                            scaleX = 1.05f
                            scaleY = 1.05f
                            shadowElevation = 16.dp.toPx()
                            alpha = 0.95f
                        }
                ) {
                    AnimatedFeatureCardContent(
                        item = item,
                        index = 0,
                        isEditMode = isEditMode,
                        onClick = {},
                        scale = 1f
                    )
                }
            }
        }
    }
}

// ---------- 单个卡片的视觉内容 ----------
@Composable
fun AnimatedFeatureCardContent(
    item: FeatureItem,
    index: Int,
    isEditMode: Boolean,
    onClick: () -> Unit,
    scale: Float
) {
    var visible by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        delay(index * 50L) // 顺滑出场
        visible = true
    }
    
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(300)) + scaleIn(initialScale = 0.85f, animationSpec = tween(300))
    ) {
        Card(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer(scaleX = scale, scaleY = scale)
                .clip(RoundedCornerShape(16.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = if (isEditMode) null else ripple(bounded = true),
                    onClick = onClick
                ),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isEditMode) 0.dp else 2.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
            )
        ) {
            Box(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(64.dp)
                        .align(Alignment.BottomEnd)
                        .offset(x = 12.dp, y = 12.dp)
                        .alpha(0.45f),
                    tint = item.color
                )
                Text(
                    text = item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.Center),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        }
    }
}



}