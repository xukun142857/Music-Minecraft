package command.plus

import java.io.File
import java.io.FileOutputStream
import android.widget.Toast
import android.os.Handler
import android.os.Looper
/**
 * 我的世界 Minecraft 盔甲架命令生成器
 */
class McCommandGenerator private constructor(
    private val inputData: String,
    private val scoreboardObj: String,
    private val entityName: String,
    private val charLimit: Int,
    private val startLength: Int, // X
    private val startDepth: Int,  // Y
    private val startWidth: Int,  // Z
    private val mirrorHorizontal: Boolean,
    private val mirrorVertical: Boolean,
    private val innerAxis: Axis,
    private val innerStep: Int,
    private val outerAxis: Axis,
    private val outerStep: Int,
    private val saveFile: File?,
    private val callback: (List<String>) -> Unit
) {

    // 坐标轴枚举
    enum class Axis { 长, 深, 宽 }

    fun generate() {
        try {
            var matrix = parseInput(inputData)
            if (matrix.isEmpty()) {
                callback(emptyList())
                return
            }
            matrix = applyMirror(matrix)
            val commands = generateCommands(matrix)
            // --- 新增：自动保存文件逻辑 ---
        saveFile?.let { file ->
            try {
                // 如果父目录不存在则创建
                file.parentFile?.mkdirs()
                
                FileOutputStream(file).use { fos ->
                    commands.forEach { line ->
                        fos.write((line + "\n").toByteArray(Charsets.UTF_8))
                    }
                }
                println("文件已成功保存至: ${file.absolutePath}")
                
            } catch (e: Exception) {
                e.printStackTrace()
               
                // 这里可以根据需要通过回调通知 UI 写入失败
            }
        }
            callback(commands)
        } catch (e: Exception) {
            e.printStackTrace()
            callback(emptyList()) // 或者通过 callback 传回一个错误信息
        }
    }

    private fun parseInput(data: String): List<List<String>> {
        val matrix = mutableListOf<List<String>>()
        val lines = data.lines()
        
        // 简单提取单引号或双引号内的方块 ID
        val regex = "'([^']*)'|\"([^\"]*)\"".toRegex()
        
        for (line in lines) {
            var cleanLine = line.trim()
            if (cleanLine.contains(".")) {
                cleanLine = cleanLine.substringAfter(".").trim()
            }
            if (cleanLine.isEmpty()) continue
            
            val row = regex.findAll(cleanLine).map { 
                it.groupValues[1].ifEmpty { it.groupValues[2] } 
            }.toList()
            
            if (row.isNotEmpty()) {
                matrix.add(row)
            }
        }
        return matrix
    }

    private fun applyMirror(matrix: List<List<String>>): List<List<String>> {
        var processed = matrix
        if (mirrorHorizontal) {
            processed = processed.map { it.reversed() }
        }
        if (mirrorVertical) {
            processed = processed.reversed()
        }
        return processed
    }

    private fun getConsecutiveRanges(numbers: List<Int>): List<String> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val ranges = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val x = sorted[i]
            if (x == prev + 1) {
                prev = x
            } else {
                ranges.add(if (start == prev) "$start" else "$start..$prev")
                start = x
                prev = x
            }
        }
        ranges.add(if (start == prev) "$start" else "$start..$prev")
        return ranges
    }

    private fun generateCommands(matrix: List<List<String>>): List<String> {
        val cmds = mutableListOf<String>()

        val flatBlocks = mutableListOf<String>()
        val rowEndIndices = mutableListOf<Int>()
        var currentCount = 0

        for (row in matrix) {
            currentCount += row.size
            rowEndIndices.add(currentCount)
            flatBlocks.addAll(row)
        }
        val totalBlocks = flatBlocks.size

        // --- 初始化指令生成 ---
        
        cmds.add("### 初始化指令 ###")
        
        cmds.add("$0,0,0")
        cmds.add("/scoreboard objectives add $scoreboardObj dummy")
        cmds.add("$")
        cmds.add("$1,0,1")
        

        // 1. Tickingarea 分区逻辑 (根据最大支持的 256 区块，即 256x256 物理方块大小切分)
        val rowCount = matrix.size
        val colCount = matrix.maxOfOrNull { it.size } ?: 0
        
        var endLength = startLength
        var endWidth = startWidth
        
        val innerTotalMove = innerStep * (colCount - 1)
        val outerTotalMove = outerStep * (rowCount - 1)
        
        if (innerAxis == Axis.长) endLength += innerTotalMove
        if (outerAxis == Axis.长) endLength += outerTotalMove
        if (innerAxis == Axis.宽) endWidth += innerTotalMove
        if (outerAxis == Axis.宽) endWidth += outerTotalMove
        
        val minX = minOf(startLength, endLength)
        val maxX = maxOf(startLength, endLength)
        val minZ = minOf(startWidth, endWidth)
        val maxZ = maxOf(startWidth, endWidth)
        
        // 分块添加常加载区域
        for (sx in minX..maxX step 256) {
            val ex = minOf(sx + 255, maxX)
            for (sz in minZ..maxZ step 256) {
                val ez = minOf(sz + 255, maxZ)
                cmds.add("/tickingarea add $sx 0 $sz $ex 0 $ez")
            }
        }

        
        cmds.add("/summon armor_stand $startLength $startDepth $startWidth . $entityName")
        cmds.add("/execute as @e[name=\"$entityName\"] run scoreboard players set @s $scoreboardObj 1")
        cmds.add("$") // 初始化指令结束
        
        cmds.add("")

        // --- 循环指令链生成 ---
        cmds.add("### 循环命令链 ###")
        cmds.add("$2,0,0")
        cmds.add("/kill @e[name=\"$entityName\",scores={$scoreboardObj=${totalBlocks + 1}}]")
        cmds.add("$")
        cmds.add("$1,0,1")

        // 换行逻辑
        val jumpScores = rowEndIndices.dropLast(1).map { it + 1 }
        if (jumpScores.isNotEmpty()) {
            val jumpRanges = getConsecutiveRanges(jumpScores)
            val scoreSelector = jumpRanges.joinToString(",") { "$scoreboardObj=!$it" }
            
            val xyzMap = mapOf(Axis.长 to 0, Axis.深 to 1, Axis.宽 to 2)
            val tpCoords = arrayOf("~", "~", "~")
            
            // Inner 回到绝对坐标起始点
            when (innerAxis) {
                Axis.长 -> tpCoords[0] = startLength.toString()
                Axis.深 -> tpCoords[1] = startDepth.toString()
                Axis.宽 -> tpCoords[2] = startWidth.toString()
            }
            
            // Outer 相对位移
            val idxOuter = xyzMap[outerAxis]!!
            tpCoords[idxOuter] = "~$outerStep"
            
            val tpStr = tpCoords.joinToString(" ")
            cmds.add("/execute as @e[name=\"$entityName\"] at @s unless entity @s[scores={$scoreSelector}] run tp $tpStr")
        }

        // 放置方块 (Setblock)
        val blockMap = mutableMapOf<String, MutableList<Int>>()
        flatBlocks.forEachIndexed { i, blockId ->
            blockMap.getOrPut(blockId) { mutableListOf() }.add(i + 1)
        }

        for ((blockId, indices) in blockMap) {
            val ranges = getConsecutiveRanges(indices)
            val baseCmdStart = "/execute as @e[name=\"$entityName\"] at @s unless entity @s["
            val baseCmdEnd = "] run setblock ~ ~ ~ $blockId"
            
            var currentScoreParts = mutableListOf<String>()
            
            for (r in ranges) {
                val part = "$scoreboardObj=!$r"
                val testStr = (currentScoreParts + part).joinToString(",")
                val fullCmd = "${baseCmdStart}scores={$testStr}$baseCmdEnd"
                
                if (charLimit > 0 && fullCmd.length > charLimit && currentScoreParts.isNotEmpty()) {
                    cmds.add("${baseCmdStart}scores={${currentScoreParts.joinToString(",")}}$baseCmdEnd")
                    currentScoreParts = mutableListOf()
                }
                currentScoreParts.add(part)
            }
            
            if (currentScoreParts.isNotEmpty()) {
                cmds.add("${baseCmdStart}scores={${currentScoreParts.joinToString(",")}}$baseCmdEnd")
            }
        }

        // 步进 (TP Inner + Add Score)
        val xyzMap = mapOf(Axis.长 to 0, Axis.深 to 1, Axis.宽 to 2)
        val stepCoords = arrayOf("~", "~", "~")
        stepCoords[xyzMap[innerAxis]!!] = "~$innerStep"
        val stepTpStr = stepCoords.joinToString(" ")

        cmds.add("/execute as @e[name=\"$entityName\"] at @s run tp $stepTpStr")
        cmds.add("/execute as @e[name=\"$entityName\"] run scoreboard players add @s $scoreboardObj 1")
        cmds.add("$") // 循环指令结束

        return cmds
    }

    // Builder 设计模式实现
    class Builder {
        private var saveFile: File? = null
        private var inputData: String = ""
        private var scoreboardObj: String = "n"
        private var entityName: String = "C"
        private var charLimit: Int = 10000
        private var startLength: Int = 0
        private var startDepth: Int = 0
        private var startWidth: Int = 0
        private var mirrorHorizontal: Boolean = false
        private var mirrorVertical: Boolean = false
        
        private var innerAxis: Axis = Axis.长
        private var innerStep: Int = 1
        private var outerAxis: Axis = Axis.宽
        private var outerStep: Int = 1
        
        private var callback: ((List<String>) -> Unit)? = null

        fun setInputData(data: String) = apply { this.inputData = data }
        fun setScoreboardObj(obj: String) = apply { this.scoreboardObj = obj }
        fun setEntityName(name: String) = apply { this.entityName = name }
        fun setCharLimit(limit: Int) = apply { this.charLimit = limit }
        
        fun setStartCoords(长: Int, 深: Int, 宽: Int) = apply {
            this.startLength = 长
            this.startDepth = 深
            this.startWidth = 宽
        }

        fun setMirror(horizontal: Boolean, vertical: Boolean) = apply {
            this.mirrorHorizontal = horizontal
            this.mirrorVertical = vertical
        }

        // 传入需要移动的两个轴以及步数，不动的轴会自动算出
        fun setAxisConfig(innerAxis: Axis, innerStep: Int, outerAxis: Axis, outerStep: Int) = apply {
            require(innerAxis != outerAxis) { "内部行进轴和换行轴不能是同一个！" }
            this.innerAxis = innerAxis
            this.innerStep = innerStep
            this.outerAxis = outerAxis
            this.outerStep = outerStep
        }

        fun setCallback(callback: (List<String>) -> Unit) = apply {
            this.callback = callback
        }
        
        /**
         * 设置输出文件路径
         * @param path 完整的文件路径，例如 "/storage/emulated/0/Download/out.txt"
         */
        fun setOutputFile(path: String) = apply {
            this.saveFile = File(path)
        }

        /**
         * 也可以直接传入 File 对象
         */
        fun setOutputFile(file: File) = apply {
            this.saveFile = file
        }

        fun build(): McCommandGenerator {
            requireNotNull(callback) { "必须设置 Callback" }
            return McCommandGenerator(
                inputData, scoreboardObj, entityName, charLimit,
                startLength, startDepth, startWidth,
                mirrorHorizontal, mirrorVertical,
                innerAxis, innerStep, outerAxis, outerStep,saveFile,
                callback!!
            )
        }
    }
}