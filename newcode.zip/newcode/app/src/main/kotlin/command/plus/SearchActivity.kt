package command.plus

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.DisposableEffect

import androidx.compose.material.icons.filled.ArrowBack
// --- 数据模型 ---
data class SIEntry(val id: String = UUID.randomUUID().toString(), var key: String, var value: Int)
data class ISEntry(val id: String = UUID.randomUUID().toString(), var key: Int, var value: String)

@Composable
fun musicCommand(onBack: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        SearchScreen(onBack = onBack)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sp = remember { context.getSharedPreferences("search_prefs", Context.MODE_PRIVATE) }
    var showResetDialog by remember { mutableStateOf(false) }

    // --- 状态管理 ---
    var input1 by remember { mutableStateOf(sp.getString("input1", "input.mid") ?: "input.mid") }
    var outType by remember { mutableStateOf(sp.getInt("outType", 0)) }
    var mode by remember { mutableStateOf(sp.getInt("mode", 0)) }
    var extPath by remember { mutableStateOf(sp.getString("extPath", "output") ?: "output") }
    var stackEnabled by remember { mutableStateOf(sp.getBoolean("stack", true)) }
    var params by remember {
        mutableStateOf(List(8) { i -> sp.getString("p${i + 1}", getDefaultParam(i)) ?: getDefaultParam(i) })
    }
    var siList by remember {
    mutableStateOf(
        loadSIMap(sp).ifEmpty { defaultSIMap() }
    )
}
    var isList by remember { mutableStateOf(loadISMap(sp)) }

    // --- 核心优化：实时自动保存 ---
    // 监听所有状态变量，一旦改变就执行保存逻辑
    LaunchedEffect(input1, outType, mode, extPath, stackEnabled, params, siList, isList) {
        // 这里的逻辑会在状态改变后稍作等待，防止输入过快导致的频繁写入
        delay(300) 
        sp.edit().apply {
            putString("input1", input1)
            putInt("outType", outType)
            putInt("mode", mode)
            putString("extPath", extPath)
            putBoolean("stack", stackEnabled)
            params.forEachIndexed { i, value -> putString("p${i + 1}", value) }
            
            val siArray = JSONArray().apply { siList.forEach { put(JSONObject().put("k", it.key).put("v", it.value)) } }
            val isArray = JSONArray().apply { isList.forEach { put(JSONObject().put("k", it.key).put("v", it.value)) } }
            putString("map_si", siArray.toString())
            putString("map_is", isArray.toString())
            apply()
        }
    }

    // 播放器状态
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(0) }
    var totalDuration by remember { mutableStateOf(0) }
    var wavName by remember { mutableStateOf("本地 WAV") }
    var isUserSeeking by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }

    // 保存设置的函数
    val saveAllPrefs = {
        sp.edit().apply {
            putString("input1", input1)
            putInt("outType", outType)
            putInt("mode", mode)
            putString("extPath", extPath)
            putBoolean("stack", stackEnabled)
            params.forEachIndexed { i, value -> putString("p${i + 1}", value) }
            
            val siArray = JSONArray().apply { siList.forEach { put(JSONObject().put("k", it.key).put("v", it.value)) } }
            val isArray = JSONArray().apply { isList.forEach { put(JSONObject().put("k", it.key).put("v", it.value)) } }
            putString("map_si", siArray.toString())
            putString("map_is", isArray.toString())
            apply()
        }
    }

    // 恢复默认的函数
    val restoreDefaults = {
        input1 = "input.mid"
        params = List(8) { i -> getDefaultParam(i) }
        siList = defaultSIMap()
        isList = defaultISMap()
        saveAllPrefs()
        Toast.makeText(context, "已恢复默认设置", Toast.LENGTH_SHORT).show()
    }

    // --- 播放器进度更新循环 ---
    LaunchedEffect(isPlaying, isUserSeeking) {
        while (isPlaying && !isUserSeeking) {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    currentPosition = it.currentPosition
                }
            }
            delay(500)
        }
    }

    // 资源释放
    DisposableEffect(Unit) {
        onDispose { mediaPlayer?.release() }
    }
    
    val lifecycleOwner = LocalLifecycleOwner.current

// 监听生命周期：进入后台时暂停
DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
        if (event == Lifecycle.Event.ON_PAUSE) {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                    isPlaying = false
                }
            }
        }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
        lifecycleOwner.lifecycle.removeObserver(observer)
    }
}

    // --- 文件选取器 ---
    val pickWavLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            coroutineScope.launch(Dispatchers.IO) {
                val name = queryName(context, it) ?: "temp.wav"
                if (!name.endsWith(".wav", true)) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "仅限 WAV 文件", Toast.LENGTH_SHORT).show() }
                    return@launch
                }
                val targetDir = File(context.getExternalFilesDir(null), "note")
                targetDir.mkdirs()
                val targetFile = File(targetDir, name)
                try {
                    context.contentResolver.openInputStream(it)?.use { input ->
                        FileOutputStream(targetFile).use { output -> input.copyTo(output) }
                    }
                    withContext(Dispatchers.Main) { Toast.makeText(context, "导入成功", Toast.LENGTH_SHORT).show() }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "导入失败: ${e.message}", Toast.LENGTH_SHORT).show() }
                }
            }
        }
    }

    Scaffold(
    topBar = {
        // 使用 Column 将标题栏和下方的返回条组合在一起
        Column {
            TopAppBar(
                title = { Text("指令音符盒") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
            
            // 标题栏下方的自定义小长条
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant, // 设置长条背景色
                modifier = Modifier
                .fillMaxWidth()
                .height(35.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onBack() }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                    // 如果长条里还需要文字，可以加在这里
                    Text("返回主页", style = MaterialTheme.typography.labelMedium)
                    // Text("返回", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 生成按钮
            Button(
                onClick = {
                    saveAllPrefs()
                    isGenerating = true
                    // 在协程中执行生成任务
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val inputMidi = File(input1)
                            val outFolder = if (outType == 1) File(extPath) else File(context.getExternalFilesDir(null), "MusicOutput")
                            outFolder.mkdirs()

                            // 注意：这里假设你的 McMusicConverter 可以在协程中同步或通过回调运行
                            // 为了将其适配进协程，我们用回调试配
                            val converter = McMusicConverter.Builder()
                                .setMidiFile(inputMidi)
                                .setSampleFolder(File(context.getExternalFilesDir(null), "note"))
                                .setOutputWav(File(outFolder, "${inputMidi.nameWithoutExtension}.wav"))
                                .setOutputTxt(File(outFolder, "${inputMidi.nameWithoutExtension}.txt"))
                                .setMcTick(params[0].toDoubleOrNull() ?: 0.05)
                                .setMaxSimulNotes(params[1].toIntOrNull() ?: 5)
                                .setVolumeMode(mode)
                                .setInstBases(siList.associate { it.key to it.value })
                                .setSfxMapping(isList.associate { it.key to it.value })
                                .setEnableStacking(stackEnabled)
                                .build()

                            converter.convertAndRender(object : McMusicConverter.Callback {
                                override fun onProgress(msg: String?, p: Int) {}
                                override fun onComplete(wav: File, txt: File) {
                                    coroutineScope.launch(Dispatchers.Main) {
                                        isGenerating = false
                                        wavName = wav.name
                                        
                                        isPlaying = false
                                        currentPosition = 0
                                        totalDuration = 0                                   
                                        mediaPlayer?.stop()
                                        
                                        // 初始化播放器
                                        mediaPlayer?.release()
                                        mediaPlayer = MediaPlayer().apply {
                                            setDataSource(wav.absolutePath)
                                            setOnPreparedListener { mp ->
                                                totalDuration = mp.duration
                                            }
                                            setOnCompletionListener {
                                                isPlaying = false
                                                currentPosition = 0
                                            }
                                            prepareAsync()
                                        }
                                        Toast.makeText(context, "生成成功", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                override fun onError(e: Exception) {
                                    coroutineScope.launch(Dispatchers.Main) {
                                        isGenerating = false
                                        Toast.makeText(context, "失败: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                isGenerating = false
                                Toast.makeText(context, "错误: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isGenerating
            ) {
                Text(if (isGenerating) "正在生成..." else "生成", fontSize = 16.sp)
            }

            // 试听卡片
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher), // 替换为你的 ic_launcher
                            contentDescription = "Album Art",
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).background(Color.LightGray)
                        )
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                            Text("Wav音频试听", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(wavName, fontSize = 14.sp, color = Color.Gray)
                        }
                        FilledIconButton(
                            onClick = {
                                mediaPlayer?.let {
                                    if (it.isPlaying) {
                                        it.pause()
                                        isPlaying = false
                                    } else {
                                        it.start()
                                        isPlaying = true
                                    }
                                }
                            },
                            enabled = mediaPlayer != null
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                                ),
                                contentDescription = "Play/Pause"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(currentPosition), fontSize = 12.sp)
                        Slider(
                            value = if (totalDuration > 0) currentPosition.toFloat() else 0f,
                            onValueChange = {
                                isUserSeeking = true
                                currentPosition = it.toInt()
                            },
                            onValueChangeFinished = {
                                isUserSeeking = false
                                mediaPlayer?.seekTo(currentPosition)
                            },
                            valueRange = 0f..(totalDuration.toFloat().takeIf { it > 0f } ?: 1f),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        Text(formatTime(totalDuration), fontSize = 12.sp)
                    }
                }
            }

            // 文件输入位置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("文件输入位置", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = input1,
                        onValueChange = { input1 = it },
                        label = { Text("midi文件路径") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedCard(onClick = { pickWavLauncher.launch(arrayOf("audio/*")) }) {
                        Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("添加或覆盖wav音效", fontSize = 12.sp, color = Color.Gray)
                            Text("(也可直接在 /Android/data/command.plus/files/note/ 下修改)", fontSize = 10.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { pickWavLauncher.launch(arrayOf("audio/*")) }) {
                                Text("选择音频文件")
                            }
                        }
                    }
                }
            }

            // 文件输出位置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("文件输出位置", style = MaterialTheme.typography.titleMedium)
                    SimpleDropdown(
                        label = "输出类型",
                        items = listOf("内部路径", "外部路径"),
                        selectedIndex = outType,
                        onItemSelected = { outType = it }
                    )
                    if (outType == 1) {
                        OutlinedTextField(
                            value = extPath,
                            onValueChange = { extPath = it },
                            label = { Text("外部路径 (请输入一个输出的目录)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 参数配置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("参数配置", style = MaterialTheme.typography.titleMedium)
                    
                    val paramLabels = listOf(
                        "游戏中一刻代表多少秒 (默认0.05)", "同刻最大连续量 (默认5)", 
                        "精度位数 (默认4)", "音调系数 (默认1,推荐0.5)", 
                        "音乐简化等级 (默认0,不超过5)"
                    )
                    
                    paramLabels.forEachIndexed { index, label ->
                        OutlinedTextField(
                            value = params[index],
                            onValueChange = { newText -> 
                                params = params.toMutableList().apply { this[index] = newText }
                            },
                            label = { Text(label) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    SimpleDropdown(
                        label = "音量模式",
                        items = listOf("模拟音量", "固定音量"),
                        selectedIndex = mode,
                        onItemSelected = { mode = it }
                    )
                }
            }

            // 指令配置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("指令配置", style = MaterialTheme.typography.titleMedium)
                    
                    val cmdLabels = listOf("计分板名称 (默认t)", "单条字符上限 (默认10000)", "音乐相对起始点 (默认0)")
                    cmdLabels.forEachIndexed { i, label ->
                        val actualIndex = i + 5
                        OutlinedTextField(
                            value = params[actualIndex],
                            onValueChange = { newText ->
                                params = params.toMutableList().apply { this[actualIndex] = newText }
                            },
                            label = { Text(label) },
                            keyboardOptions = if (i == 0) KeyboardOptions.Default else KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("是否保留同刻重复音", style = MaterialTheme.typography.titleMedium)
                        Switch(checked = stackEnabled, onCheckedChange = { stackEnabled = it })
                    }
                }
            }

            // Map 配置
            // 注意：这些组件的 onValueChange 会触发上面的 LaunchedEffect 自动保存

            // --- 动态列表部分：乐器及其音高 ---
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("乐器及其音高", style = MaterialTheme.typography.titleMedium)
                    
                    // 使用 animateItem() 需要在 LazyColumn 中指定 key
                    LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                        items(siList, key = { it.id }) { item ->
                            Box(modifier = Modifier.animateItem()) { // 列表项过渡动画
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = item.key,
                                        onValueChange = { newK -> 
                                            siList = siList.map { if (it.id == item.id) it.copy(key = newK) else it } 
                                        },
                                        label = { Text("乐器") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    OutlinedTextField(
                                        value = item.value.toString(),
                                        onValueChange = { newV -> 
                                            val vInt = newV.toIntOrNull() ?: 0
                                            siList = siList.map { if (it.id == item.id) it.copy(value = vInt) else it } 
                                        },
                                        label = { Text("音高") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(80.dp)
                                    )
                                    IconButton(onClick = { 
                                        siList = siList.filter { it.id != item.id } 
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                    Button(onClick = { 
                        // 添加新项时会自动触发 animateItem() 的进入动画
                        siList = siList + SIEntry(key = "new_inst", value = 0) 
                    }) {
                        Text("添加乐器映射")
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    // --- 动态列表部分：事件值及其乐器 ---
                    Text("事件值及其乐器", style = MaterialTheme.typography.titleMedium)
                    LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                        items(isList, key = { it.id }) { item ->
                            Box(modifier = Modifier.animateItem()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = item.key.toString(),
                                        onValueChange = { newK -> 
                                            val kInt = newK.toIntOrNull() ?: 0
                                            isList = isList.map { if (it.id == item.id) it.copy(key = kInt) else it } 
                                        },
                                        label = { Text("ID") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.width(100.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    OutlinedTextField(
                                        value = item.value,
                                        onValueChange = { newV -> 
                                            isList = isList.map { if (it.id == item.id) it.copy(value = newV) else it } 
                                        },
                                        label = { Text("乐器名称") },
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { isList = isList.filter { it.id != item.id } }) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                    Button(onClick = { 
                        isList = isList + ISEntry(key = 0, value = "instrument") 
                    }) {
                        Text("添加事件映射")
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = {
                            showResetDialog = true
                            // 点击后状态改变，LaunchedEffect 会自动保存
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("重置所有配置")
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
    
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("重置所有设置？") },
            text = { Text("这将重置所有文本框及映射。") },
            confirmButton = {
                TextButton(
                    onClick = {
                        input1 = "input.mid"
                            params = List(8) { i -> getDefaultParam(i) }
                            siList = defaultSIMap()
                            isList = defaultISMap()
                            stackEnabled = true
                            outType = 0
                            mode = 0
                            extPath = "output" // 调用上面写好的函数
                        showResetDialog = false
                    }
                ) {
                    Text("确定重置", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("取消")
                }
            }
        )
    }
}

// --- 辅助组件与函数 ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleDropdown(label: String, items: List<String>, selectedIndex: Int, onItemSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = items.getOrElse(selectedIndex) { "" },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            items.forEachIndexed { index, text ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onItemSelected(index)
                        expanded = false
                    }
                )
            }
        }
    }
}

private fun getDefaultParam(i: Int) = when(i) {
    0 -> "0.05"; 1 -> "5"; 2 -> "4"; 3 -> "1"; 4 -> "0"; 5 -> "t"; 6 -> "10000"; 7 -> "0"; else -> ""
}

private fun loadSIMap(sp: android.content.SharedPreferences): List<SIEntry> {
    val json = sp.getString("map_si", null) ?: return emptyList()
    val list = mutableListOf<SIEntry>()
    try {
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(SIEntry(key = obj.getString("k"), value = obj.getInt("v")))
        }
    } catch (e: Exception) { e.printStackTrace() }
    return list
}

private fun loadISMap(sp: android.content.SharedPreferences): List<ISEntry> {
    val json = sp.getString("map_is", null) ?: return emptyList()
    val list = mutableListOf<ISEntry>()
    try {
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(ISEntry(key = obj.getInt("k"), value = obj.getString("v")))
        }
    } catch (e: Exception) { e.printStackTrace() }
    return list
}

private fun queryName(context: Context, uri: Uri): String? {
    return context.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}

private fun formatTime(ms: Int): String {
    val s = ms / 1000
    return String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60)
}

private fun defaultSIMap(): List<SIEntry> {
    return listOf(
        SIEntry(key = "harp", value = 54),
        SIEntry(key = "bass", value = 30),
        SIEntry(key = "pling", value = 78),
        SIEntry(key = "bell", value = 78),
        SIEntry(key = "flute", value = 66),
        SIEntry(key = "guitar", value = 42),
        SIEntry(key = "chime", value = 78),
        SIEntry(key = "xylophone", value = 78),
        SIEntry(key = "iron_xylophone", value = 54),
        SIEntry(key = "cow_bell", value = 66),
        SIEntry(key = "didgeridoo", value = 30),
        SIEntry(key = "bit", value = 54),
        SIEntry(key = "banjo", value = 54),
        SIEntry(key = "bd", value = 0),
        SIEntry(key = "snare", value = 0)
    )
}

private fun defaultISMap(): List<ISEntry> {
    return listOf(
        ISEntry(key = 122, value = "seashore"),
        ISEntry(key = 127, value = "gunshot")
    )
}