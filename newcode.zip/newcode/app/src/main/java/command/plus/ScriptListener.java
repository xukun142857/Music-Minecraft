package command.plus;

import java.util.Map;

public interface ScriptListener {
    void onScriptEnd(String scriptId, Map<String,Object> finalVars);
    void onInputFieldNotFound(String scriptId, String attemptedText);
    void onScriptStopped(String scriptId);
    void onScriptError(String scriptId, Exception e);
    /**
     * 当变量提供器返回 null（变量不存在或为 null）时回调
     */
    void onVariableError(String scriptId, String varName);
    void onNextItem();
}