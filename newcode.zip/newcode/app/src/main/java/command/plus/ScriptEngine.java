package command.plus;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 完整 ScriptEngine（包含 VariableProvider 支持与变量为空回调）。
 *
 * 使用：
 *   ScriptEngine engine = new ScriptEngine();
 *   engine.setVariableProvider(myProvider);
 *   engine.runScriptAsync(...);
 */
public class ScriptEngine {
private DataManager dataManager;
ScriptListener plistener;
    // ---------------- VariableProvider ----------------
   
public interface VariableProvider {
        /**
         * @param name 变量名（不带 $）
         * @return 值（可为 Boolean/String/Number 等），如果不存在请返回 null
         */
        Object getVariable(String name);
    }

    // ---------------- 外部接口 ----------------
    public interface ActionExecutor {
        void exeAction(int x, int y, int x1, int y1, long timeMs);
    }

    public interface TextSetter {
        /**
         * @return true 成功，false 未找到或失败
         */
        boolean setText(String text);
    }

    // ---------------- 命令接口与异常 ----------------
    public interface Command {
        void execute(ExecutionContext ctx, String rawArgs) throws RestartException, StopException, VariableMissingException;
    }

    public static class RestartException extends Exception { public RestartException(){ super("restart"); } }
    public static class StopException extends Exception { public StopException(){ super("stop"); } }
    public static class VariableMissingException extends Exception {
    public VariableMissingException(String varName){ super("variable missing: " + varName); }
    }

    // ---------------- ExecutionContext ----------------
    public static class ExecutionContext {
        private final Map<String,Object> vars;
        private final ActionExecutor actionExecutor;
        private final TextSetter textSetter;
        private final ScriptListener listener;
        private final String scriptId;
        private final AtomicBoolean stopped = new AtomicBoolean(false);
        private final VariableProvider variableProvider;

        public ExecutionContext(Map<String,Object> vars,
                                ActionExecutor actionExecutor,
                                TextSetter textSetter,
                                ScriptListener listener,
                                String scriptId,
                                VariableProvider variableProvider) {
            this.vars = vars;
            this.actionExecutor = actionExecutor;
            this.textSetter = textSetter;
            this.listener = listener;
            this.scriptId = scriptId;
            this.variableProvider = variableProvider;
        }

        public Map<String,Object> getVars(){ return vars; }
        public ActionExecutor getActionExecutor(){ return actionExecutor; }
        public TextSetter getTextSetter(){ return textSetter; }
        public ScriptListener getListener(){ return listener; }
        public String getScriptId(){ return scriptId; }
        public boolean isStopped(){ return stopped.get(); }
        public void stop(){ stopped.set(true); }

        /**
         * 解析变量：优先脚本内 vars（存在键但值为 null 也算错误），否则调用 variableProvider（若为 null 则视为未找到）
         * 如果最终没有值：会通知 listener.onVariableError 并抛 VariableMissingException。
         */
        public Object resolveVar(String name) throws VariableMissingException {
            if (name == null) throw new VariableMissingException("null");
            // strip leading $
            if (name.startsWith("$")) name = name.substring(1);
            if (vars.containsKey(name)) {
                Object v = vars.get(name);
                if (v == null) {
                    if (listener != null) listener.onVariableError(scriptId, name);
                    throw new VariableMissingException(name);
                }
                return v;
            }
            if (variableProvider != null) {
                Object v = variableProvider.getVariable(name);
                if (v == null) {
                    if (listener != null) listener.onVariableError(scriptId, name);
                    throw new VariableMissingException(name);
                }
                return v;
            }
            // not found
            if (listener != null) listener.onVariableError(scriptId, name);
            throw new VariableMissingException(name);
        }
    }

    // ---------------- fields ----------------
    private VariableProvider variableProvider = null;
    private final Map<String, Command> commandRegistry = new HashMap<>();
    private final Pattern commandNamePattern = Pattern.compile("^\\.([a-zA-Z0-9_]+)(\\(|\\s|$)");
    private final Pattern parenArgsPattern = Pattern.compile("^\\.([a-zA-Z0-9_]+)\\s*\\((.*)\\)\\s*$", Pattern.DOTALL);

    public ScriptEngine() {
        registerBuiltinCommands();
    }

    public void setVariableProvider(VariableProvider provider){
        this.variableProvider = provider;
    }

    public VariableProvider getVariableProvider(){ return variableProvider; }

    public void registerCommand(String name, Command cmd){
        commandRegistry.put(name.toLowerCase(Locale.ROOT), cmd);
    }

    // ---------------- builtins ----------------
    private void registerBuiltinCommands(){
        // exeAction(x,y,x1,y1,time)
        registerCommand("exeAction", (ctx, rawArgs) -> {
            String[] parts = splitArgs(rawArgs);
            if (parts.length < 5) return;
            try {
                int x = Integer.parseInt(parts[0].trim());
                int y = Integer.parseInt(parts[1].trim());
                int x1 = Integer.parseInt(parts[2].trim());
                int y1 = Integer.parseInt(parts[3].trim());
                long time = Long.parseLong(parts[4].trim());
                if (ctx.getActionExecutor() != null) ctx.getActionExecutor().exeAction(x,y,x1,y1,time);
            } catch (NumberFormatException ignore){}
        });

        // sleep(ms)
        registerCommand("sleep", (ctx, rawArgs) -> {
            String s = rawArgs == null ? "" : rawArgs.trim();
            if (s.isEmpty()) return;
            try {
                long ms = Long.parseLong(s);
                long waited = 0;
                long chunk = 100;
                while (waited < ms) {
                    if (ctx.isStopped()) throw new StopException();
                    long to = Math.min(chunk, ms - waited);
                    try { Thread.sleep(to); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); throw new StopException(); }
                    waited += to;
                }
            } catch (NumberFormatException ignore){}
        });

        // setText(expr)
        registerCommand("setText", (ctx, rawArgs) -> {
            String text;
            try {
                text = ConcatExprEvaluator.evaluate(rawArgs, ctx);
            } catch (VariableMissingException vme) {
                throw vme;
            }
            if (ctx.isStopped()) throw new StopException();
            boolean ok = false;
            try {
                if (ctx.getTextSetter() != null) ok = ctx.getTextSetter().setText(text);
            } catch (Exception e) {
                if (ctx.getListener() != null) ctx.getListener().onScriptError(ctx.getScriptId(), e);
                ok = false;
            }
            if (!ok && ctx.getListener() != null) {
                ctx.getListener().onInputFieldNotFound(ctx.getScriptId(), text);
            }
        });

        // setVar(name, expr)
        registerCommand("setVar", (ctx, rawArgs) -> {
            String[] parts = splitArgs(rawArgs);
            if (parts.length < 2) return;
            String name = parts[0].trim();
            if (name.startsWith("$")) name = name.substring(1);
            int comma = rawArgs.indexOf(',');
            if (comma < 0) return;
            String expr = rawArgs.substring(comma+1);
            String val;
            try {
                val = ConcatExprEvaluator.evaluate(expr, ctx);
            } catch (VariableMissingException vme) { throw vme; }
            String low = val.trim().toLowerCase(Locale.ROOT);
            if ("true".equals(low)) ctx.getVars().put(name, Boolean.TRUE);
            else if ("false".equals(low)) ctx.getVars().put(name, Boolean.FALSE);
            else ctx.getVars().put(name, val);
        });

        // reStart
        registerCommand("reStart", (ctx, rawArgs) -> {
            // signal restart by throwing RestartException
            throw new RestartException();
        });
        
        // nextItem
        registerCommand("nextItem", (ctx, rawArgs) -> {
            
            if (plistener != null) plistener.onNextItem();
        });
    }

    // ---------------- global run tracking ----------------
    private static final Map<String, Thread> runningThreads = new ConcurrentHashMap<>();
    private static final Map<String, ExecutionContext> runningContexts = new ConcurrentHashMap<>();

    public static void stopAllScripts(){
        for (Map.Entry<String, ExecutionContext> e : runningContexts.entrySet()){
            ExecutionContext ctx = e.getValue();
            if (ctx != null) ctx.stop();
        }
        for (Map.Entry<String, Thread> t : runningThreads.entrySet()){
            Thread th = t.getValue();
            if (th != null && th.isAlive()) th.interrupt();
        }
    }

    // ---------------- ScriptHandle & runScriptAsync ----------------
    public static class ScriptHandle {
        private final String scriptId;
        private final Thread thread;
        private final ExecutionContext ctx;
        public ScriptHandle(String scriptId, Thread thread, ExecutionContext ctx){
            this.scriptId = scriptId; this.thread = thread; this.ctx = ctx;
        }
        public String getScriptId(){ return scriptId; }
        public void stop(){
            if (ctx != null) ctx.stop();
            if (thread != null) thread.interrupt();
        }
    }

    public ScriptHandle runScriptAsync(String scriptId,
                                       List<String> lines,
                                       Map<String,Object> initialVars,
                                       ActionExecutor actionExecutor,
                                       TextSetter textSetter,
                                       ScriptListener listener) {
                                       plistener = listener;
        String id = (scriptId == null || scriptId.isEmpty()) ? UUID.randomUUID().toString() : scriptId;
        Map<String,Object> vars = initialVars == null ? new HashMap<>() : new HashMap<>(initialVars);
        ExecutionContext ctx = new ExecutionContext(vars, actionExecutor, textSetter, listener, id, this.variableProvider);

        Runnable task = () -> {
            runningContexts.put(id, ctx);
            runningThreads.put(id, Thread.currentThread());
            try {
                runScriptInternal(lines, ctx);
                if (!ctx.isStopped()){
                    if (listener != null) listener.onScriptEnd(id, new HashMap<>(ctx.getVars()));
                } else {
                    if (listener != null) listener.onScriptStopped(id);
                }
            } catch (VariableMissingException vme) {
                // VariableMissingException already notified inside resolveVar; ensure script stopped callback
                if (listener != null) listener.onScriptStopped(id);
            } catch (StopException se) {
                if (listener != null) listener.onScriptStopped(id);
            } catch (RestartException re) {
                // RestartException should not bubble here because runScriptInternal handles it,
                // but in case, treat as normal end.
                if (listener != null) listener.onScriptEnd(id, new HashMap<>(ctx.getVars()));
            } catch (Exception e) {
                if (listener != null) listener.onScriptError(id, e);
            } finally {
                runningContexts.remove(id);
                runningThreads.remove(id);
            }
        };

        Thread th = new Thread(task, "ScriptEngine-" + id);
        th.start();
        return new ScriptHandle(id, th, ctx);
    }

    // ---------------- core execution ----------------
    private void runScriptInternal(List<String> lines, ExecutionContext ctx) throws RestartException, StopException, VariableMissingException {
        if (lines == null) return;
        IfMap ifMap = buildIfMap(lines);

        int iterationGuard = 0;
        outer:
        while (true) {
            iterationGuard++;
            if (iterationGuard > 1000000) break;
            Deque<IfFrame> frameStack = new ArrayDeque<>();
            int i = 0;
            while (i < lines.size()) {
                if (ctx.isStopped()) throw new StopException();
                String raw = lines.get(i);
                if (raw == null) { i++; continue; }
                String line = raw.trim();
                if (!line.startsWith(".")) { i++; continue; }

                String cmdName = parseCommandName(line);
                if (cmdName == null) { i++; continue; }
                String cmdLower = cmdName.toLowerCase(Locale.ROOT);

                boolean executionEnabled = frameStack.isEmpty() ? true : frameStack.peek().executing;

                if ("if".equals(cmdLower) || line.startsWith(".if(")) {
                    if (!ifMap.ifToEnd.containsKey(i)) { i++; continue; }
                    String cond = extractParenContent(line);
                    boolean condValue = false;
                    try {
                        BoolExprParser parser = new BoolExprParser(cond, ctx);
                        condValue = parser.parseExpr();
                    } catch (VariableMissingException vme) {
                        // already notified by resolveVar
                        throw vme;
                    } catch (Exception e) {
                        condValue = false;
                    }
                    boolean newExec = executionEnabled && condValue;
                    frameStack.push(new IfFrame(newExec, executionEnabled, condValue));
                    i++;
                    continue;
                } else if ("else".equals(cmdLower) || line.startsWith(".else")) {
                    if (!ifMap.elseToIf.containsKey(i)) { i++; continue; }
                    if (!frameStack.isEmpty()) {
                        IfFrame top = frameStack.peek();
                        boolean parentActive = top.parentActive;
                        boolean condValue = top.conditionResult;
                        top.executing = parentActive && (!condValue);
                        i++;
                        continue;
                    } else { i++; continue; }
                } else if ("end".equals(cmdLower) || line.startsWith(".end")) {
                    if (!frameStack.isEmpty()) { frameStack.pop(); i++; continue; }
                    else { i++; continue; }
                } else {
                    if (!executionEnabled) { i++; continue; }

                    String args = "";
                    Matcher m = parenArgsPattern.matcher(line);
                    if (m.matches()) args = m.group(2).trim();
                    else {
                        int spaceIdx = line.indexOf(' ');
                        if (spaceIdx >= 0) args = line.substring(spaceIdx + 1).trim();
                    }

                    Command cmd = commandRegistry.get(cmdLower);
                    if (cmd != null) {
                        try {
                            cmd.execute(ctx, args);
                        } catch (VariableMissingException vme) {
                            throw vme;
                        } catch (RestartException re) {
                            i = 0; continue outer;
                        } catch (StopException se) {
                            throw se;
                        } catch (Exception ex) {
                            if (ctx.getListener() != null) ctx.getListener().onScriptError(ctx.getScriptId(), ex);
                        }
                        if (ctx.isStopped()) throw new StopException();
                    } else {
                        // backward compatibility: exeAction with 6th param = delay
                        if ("exeaction".equals(cmdLower)) {
                            String[] parts = splitArgs(args);
                            if (parts.length >= 6) {
                                try {
                                    int x = Integer.parseInt(parts[0].trim());
                                    int y = Integer.parseInt(parts[1].trim());
                                    int x1 = Integer.parseInt(parts[2].trim());
                                    int y1 = Integer.parseInt(parts[3].trim());
                                    long time = Long.parseLong(parts[4].trim());
                                    long delay = Long.parseLong(parts[5].trim());
                                    Command exe = commandRegistry.get("exeaction");
                                    if (exe != null) exe.execute(ctx, String.format("%d,%d,%d,%d,%d", x,y,x1,y1,time));
                                    Command sleepCmd = commandRegistry.get("sleep");
                                    if (sleepCmd != null) sleepCmd.execute(ctx, String.valueOf(delay));
                                } catch (NumberFormatException nfe){}
                            }
                        }
                    }
                    i++;
                }
            } // while lines
            break;
        } // outer
    }

    // ---------------- helpers: parsing, ifmap, tokenizers ----------------
    private static String[] splitArgs(String rawArgs) {
        if (rawArgs == null) return new String[0];
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < rawArgs.length(); i++) {
            char c = rawArgs.charAt(i);
            if (c == '"' ) { inQuotes = !inQuotes; cur.append(c); }
            else if (c == ',' && !inQuotes) { out.add(cur.toString().trim()); cur.setLength(0); }
            else cur.append(c);
        }
        if (cur.length() > 0) out.add(cur.toString().trim());
        return out.toArray(new String[0]);
    }

    private static class IfMap { Map<Integer,Integer> ifToEnd = new HashMap<>(); Map<Integer,Integer> ifToElse = new HashMap<>(); Map<Integer,Integer> elseToIf = new HashMap<>(); }
    private IfMap buildIfMap(List<String> lines){
        IfMap m = new IfMap();
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < lines.size(); i++){
            String raw = lines.get(i).trim();
            if (!raw.startsWith(".")) continue;
            String cmd = parseCommandNameStatic(raw);
            if (cmd == null) continue;
            cmd = cmd.toLowerCase(Locale.ROOT);
            if ("if".equals(cmd) || cmd.startsWith("if(")) stack.push(i);
            else if ("else".equals(cmd) || cmd.startsWith("else(")) { if (!stack.isEmpty()){ int ifIdx = stack.peek(); m.ifToElse.put(ifIdx, i); m.elseToIf.put(i, ifIdx);} }
            else if ("end".equals(cmd) || cmd.startsWith("end(")) { if (!stack.isEmpty()){ int ifIdx = stack.pop(); m.ifToEnd.put(ifIdx, i); } }
        }
        Map<Integer,Integer> clean = new HashMap<>();
        for (Map.Entry<Integer,Integer> e : m.ifToElse.entrySet()){
            int ifIdx = e.getKey(); int elseIdx = e.getValue();
            if (m.ifToEnd.containsKey(ifIdx)){ clean.put(ifIdx, elseIdx); m.elseToIf.put(elseIdx, ifIdx); }
        }
        m.ifToElse = clean;
        return m;
    }

    private String parseCommandName(String rawLine){
        Matcher m = commandNamePattern.matcher(rawLine);
        if (m.find()) return m.group(1);
        return null;
    }
    private static String parseCommandNameStatic(String rawLine){
        Matcher m = Pattern.compile("^\\.([a-zA-Z0-9_]+)(\\(|\\s|$)").matcher(rawLine);
        if (m.find()) return m.group(1);
        return null;
    }

    private static String extractParenContent(String line){
        int open = line.indexOf('(');
        int close = line.lastIndexOf(')');
        if (open >=0 && close > open) return line.substring(open+1, close).trim();
        return "";
    }

    private static class IfFrame { boolean executing; boolean parentActive; boolean conditionResult; IfFrame(boolean executing, boolean parentActive, boolean conditionResult){ this.executing = executing; this.parentActive = parentActive; this.conditionResult = conditionResult; } }

    // ---------------- BoolExprParser & ConcatExprEvaluator (use ExecutionContext.resolveVar) ----------------
 private static class BoolExprParser {
    private final List<Token> tokens;
    private int pos = 0;
    private final ExecutionContext ctx;

    // 1. 扩展 Token 类型
    private enum TokType { 
        AND, OR, LPAREN, RPAREN, IDENT, TRUE, FALSE, 
        EQ, NE, LT, GT, LTE, GTE, // 新增比较符
        NUMBER, STRING,           // 新增数据类型
        END 
    }

    private static class Token { 
        TokType type; String text; 
        Token(TokType t, String tx){ type = t; text = tx; } 
    }

    public BoolExprParser(String expr, ExecutionContext ctx) throws VariableMissingException {
        this.tokens = tokenize(expr);
        this.ctx = ctx;
    }

    private List<Token> tokenize(String s) {
        List<Token> out = new ArrayList<>();
        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (Character.isWhitespace(c)) { i++; continue; }
            if (c == '(') { out.add(new Token(TokType.LPAREN, "(")); i++; continue; }
            if (c == ')') { out.add(new Token(TokType.RPAREN, ")")); i++; continue; }
            
            // 识别操作符
            if (s.startsWith("&&", i)) { out.add(new Token(TokType.AND, "&&")); i+=2; continue; }
            if (s.startsWith("||", i)) { out.add(new Token(TokType.OR, "||")); i+=2; continue; }
            if (s.startsWith("==", i)) { out.add(new Token(TokType.EQ, "==")); i+=2; continue; }
            if (s.startsWith("!=", i)) { out.add(new Token(TokType.NE, "!=")); i+=2; continue; }
            if (s.startsWith("<=", i)) { out.add(new Token(TokType.LTE, "<=")); i+=2; continue; }
            if (s.startsWith(">=", i)) { out.add(new Token(TokType.GTE, ">=")); i+=2; continue; }
            if (c == '<') { out.add(new Token(TokType.LT, "<")); i++; continue; }
            if (c == '>') { out.add(new Token(TokType.GT, ">")); i++; continue; }

            // 2. 识别字符串字面量 "text"
            if (c == '"') {
                int j = i + 1;
                StringBuilder sb = new StringBuilder();
                while (j < s.length() && s.charAt(j) != '"') {
                    if (s.charAt(j) == '\\' && j+1 < s.length()) { sb.append(s.charAt(j+1)); j+=2; }
                    else { sb.append(s.charAt(j)); j++; }
                }
                out.add(new Token(TokType.STRING, sb.toString()));
                i = j + 1;
                continue;
            }

            // 3. 识别数字字面量
            if (Character.isDigit(c) || (c == '-' && i+1 < s.length() && Character.isDigit(s.charAt(i+1)))) {
                int j = i + 1;
                while (j < s.length() && (Character.isDigit(s.charAt(j)) || s.charAt(j) == '.')) j++;
                out.add(new Token(TokType.NUMBER, s.substring(i, j)));
                i = j;
                continue;
            }

            // 识别变量/布尔值
            if (c == '$' || Character.isLetter(c)) {
                int j = i;
                while (j < s.length() && (Character.isLetterOrDigit(s.charAt(j)) || s.charAt(j) == '_' || s.charAt(j) == '$')) j++;
                String word = s.substring(i, j);
                String lw = word.toLowerCase(Locale.ROOT);
                if ("true".equals(lw)) out.add(new Token(TokType.TRUE, "true"));
                else if ("false".equals(lw)) out.add(new Token(TokType.FALSE, "false"));
                else out.add(new Token(TokType.IDENT, word));
                i = j;
                continue;
            }
            i++;
        }
        out.add(new Token(TokType.END, ""));
        return out;
    }

    private Token peek(){ return tokens.get(pos); }
    private Token consume(){ return tokens.get(pos++); }

    public boolean parseExpr() throws VariableMissingException {
        return parseOr();
    }

    private boolean parseOr() throws VariableMissingException {
        boolean v = parseAnd();
        while (peek().type == TokType.OR) { consume(); v = v || parseAnd(); }
        return v;
    }

    private boolean parseAnd() throws VariableMissingException {
        boolean v = parseComparison();
        while (peek().type == TokType.AND) { consume(); v = v && parseComparison(); }
        return v;
    }

    // 4. 新增比较运算层 (==, !=, <, >, <=, >=)
    private boolean parseComparison() throws VariableMissingException {
        Object left = evaluateValue();
        TokType op = peek().type;
        if (op == TokType.EQ || op == TokType.NE || op == TokType.LT || op == TokType.GT || op == TokType.LTE || op == TokType.GTE) {
            consume();
            Object right = evaluateValue();
            return compare(left, right, op);
        }
        // 如果只是单值（如 .if($isAdmin)），则按布尔逻辑处理
        return toBoolean(left);
    }

    // 5. 获取具体数值 (变量、数字、字符串或布尔)
    private Object evaluateValue() throws VariableMissingException {
        Token t = peek();
        if (t.type == TokType.LPAREN) {
            consume();
            boolean res = parseExpr();
            if (peek().type == TokType.RPAREN) consume();
            return res;
        }
        consume();
        switch (t.type) {
            case TRUE: return true;
            case FALSE: return false;
            case NUMBER: return Double.parseDouble(t.text);
            case STRING: return t.text;
            case IDENT:
                String key = t.text.startsWith("$") ? t.text.substring(1) : t.text;
                return ctx.resolveVar(key);
            default: return null;
        }
    }

    // 6. 通用比较逻辑
    private boolean compare(Object left, Object right, TokType op) {
        if (left == null || right == null) {
            if (op == TokType.EQ) return left == right;
            if (op == TokType.NE) return left != right;
            return false;
        }

        // 如果是数字比较
        if (left instanceof Number || right instanceof Number) {
            double l = Double.parseDouble(String.valueOf(left));
            double r = Double.parseDouble(String.valueOf(right));
            switch (op) {
                case EQ: return l == r;
                case NE: return l != r;
                case LT: return l < r;
                case GT: return l > r;
                case LTE: return l <= r;
                case GTE: return l >= r;
            }
        }

        // 默认字符串/其他比较
        String s1 = String.valueOf(left);
        String s2 = String.valueOf(right);
        int cmp = s1.compareTo(s2);
        switch (op) {
            case EQ: return s1.equals(s2);
            case NE: return !s1.equals(s2);
            case LT: return cmp < 0;
            case GT: return cmp > 0;
            case LTE: return cmp <= 0;
            case GTE: return cmp >= 0;
        }
        return false;
    }

    private boolean toBoolean(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        if (v instanceof String) return "true".equalsIgnoreCase((String) v);
        if (v instanceof Number) return ((Number) v).doubleValue() != 0;
        return v != null;
    }
}

    private static class ConcatExprEvaluator {
        // 支持 "literal" + $Var + unquoted tokens
        public static String evaluate(String expr, ExecutionContext ctx) throws VariableMissingException {
            if (expr == null) return "";
            List<String> parts = new ArrayList<>();
            int i = 0;
            while (i < expr.length()) {
                char c = expr.charAt(i);
                if (Character.isWhitespace(c)) { i++; continue; }
                if (c == '+') { i++; continue; }
                if (c == '"') {
                    StringBuilder sb = new StringBuilder();
                    i++;
                    while (i < expr.length()) {
                        char cc = expr.charAt(i);
                        if (cc == '\\' && i + 1 < expr.length()) { char nx = expr.charAt(i+1); sb.append(nx); i += 2; }
                        else if (cc == '"') { i++; break; }
                        else { sb.append(cc); i++; }
                    }
                    parts.add(sb.toString());
                } else if (c == '$' || Character.isLetter(c)) {
                    int j = i;
                    while (j < expr.length() && (Character.isLetterOrDigit(expr.charAt(j)) || expr.charAt(j) == '_' || expr.charAt(j) == '$')) j++;
                    String id = expr.substring(i, j);
                    String key = id.startsWith("$") ? id.substring(1) : id;
                    Object vv = ctx.resolveVar(key); // throws if missing
                    parts.add(vv == null ? "" : String.valueOf(vv));
                    i = j;
                } else {
                    int j = i;
                    while (j < expr.length()) {
                        char cc = expr.charAt(j);
                        if (cc == '+') break;
                        j++;
                    }
                    String lit = expr.substring(i, j).trim();
                    if (!lit.isEmpty()) parts.add(lit);
                    i = j;
                }
            }
            StringBuilder out = new StringBuilder();
            for (String p : parts) out.append(p == null ? "" : p);
            return out.toString();
        }
    }
}