package command.plus

import android.net.Uri
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
// 其他需要的导入...
import java.io.File

data class ConfigInfo(
    val prefsName: String,
    val displayName: String
)

class ConfigViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application
    val configFiles = listOf(
    ConfigInfo("music_prefs", "指令音符盒配置"),
    ConfigInfo("ImageConvertPrefs", "图片转换配置"),
    ConfigInfo("StructureGeneratorPrefs", "结构生成器配置")
)

    // 导出逻辑
    fun exportConfig(uri: Uri, fileName: String) {
    viewModelScope.launch(Dispatchers.IO) {
        try {
            val sourceFile = File(
                context.applicationInfo.dataDir,
                "shared_prefs/$fileName.xml"
            )

            context.contentResolver.openOutputStream(uri)?.use { output ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

    // 导入逻辑
    fun importConfig(uri: Uri, targetName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val targetFile = File(
                context.applicationInfo.dataDir,
                "shared_prefs/$targetName.xml"
            )
                context.contentResolver.openInputStream(uri)?.use { input ->
                    targetFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
                // 导入后建议杀死进程或重新加载 SP
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}