package command.plus;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.IOException;
import java.util.Map;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.schedulers.Schedulers;

import androidx.datastore.preferences.core.MutablePreferences;
import androidx.datastore.preferences.core.Preferences;

import io.reactivex.rxjava3.core.Single;
// 在 DataStoreManager.java 和 SearchFragment.java 中添加：
import androidx.datastore.preferences.core.PreferencesKeys;
// 或者使用具体的方法

// 在 SearchFragment.java 中添加：
import java.util.concurrent.Executors;
import android.os.Handler;
import android.os.Looper;
import android.content.pm.PackageManager;
import java.util.Locale;
import android.content.ContentResolver;
import android.database.Cursor;
import android.provider.OpenableColumns;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.materialswitch.MaterialSwitch;
import android.widget.FrameLayout;
public class SearchFragment extends Fragment {

    View view;
    private Button btnGenerate, btnRestoreDefaults, etInputnote;
    private EditText etInput1, etExternalPath;
    private Spinner spinnerOutputType, spinnerMode;
    private EditText etParam1, etParam2, etParam3, etParam4, etParam5, etParam6, etParam7, etParam8;
    private RecyclerView rvMapSI, rvMapIS;
    private MapStringIntAdapter adapterSI;
    private MapIntStringAdapter adapterIS;
    private MaterialSwitch switch1;
    private FrameLayout containerExternalPathh;

    private ActivityResultLauncher<String[]> openDocLauncher;

    private static final int REQ_PERMISSION = 1001;

    // DataStore manager (replace SharedPreferences)
    private DataStoreManager dsMgr;
    
    
    private ImageButton btnPlay;
    private SeekBar seekBar;
    private TextView tvCurrent, tvTotal, tvWav;

    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    private boolean isUserSeeking = false;

    private final Runnable updateRunnable = new Runnable() {
        @Override
        public void run() {
            if (mediaPlayer != null && !isUserSeeking) {
                try {
                    int pos = mediaPlayer.getCurrentPosition();
                    seekBar.setProgress(pos);
                    tvCurrent.setText(formatTime(pos));
                } catch (Exception e) {
                    // 忽略或日志
                }
            }
            // 如果正在播放则继续更新
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                handler.postDelayed(this, 500);
            }
        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_search, container, false);
        dsMgr = DataStoreManager.get(requireContext());
        btnPlay = view.findViewById(R.id.btnPlay);
        seekBar = view.findViewById(R.id.seekBar);
        tvCurrent = view.findViewById(R.id.tvCurrent);
        tvTotal = view.findViewById(R.id.tvTotal);
        tvWav = view.findViewById(R.id.tvSubtitle);

        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        if (getActivity() instanceof androidx.appcompat.app.AppCompatActivity) {
((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
((AppCompatActivity) getActivity()).getSupportActionBar()
        .setTitle("指令音符盒");
        }

        openDocLauncher = registerForActivityResult(
                new ActivityResultContracts.OpenDocument(),
                new ActivityResultCallback<Uri>() {
                    @Override
                    public void onActivityResult(Uri uri) {
                        if (uri == null) {
                            Toast.makeText(getActivity(), "用户取消选择", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        handlePickedUri(uri);
                    }
                }
        );

        bindViews();
        setupSpinners();
        setupRecyclerViews();
        // load prefs asynchronously
        loadPrefs();
        setupListeners();
        
        
        
        seekBar.setOnSeekBarChangeListener(seekListener);

        // Play/Pause 按钮行为
        btnPlay.setOnClickListener(v -> {
            if (mediaPlayer == null) return;
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.pause();
                btnPlay.setImageResource(android.R.drawable.ic_media_play);
                handler.removeCallbacks(updateRunnable);
            } else {
                mediaPlayer.start();
                btnPlay.setImageResource(android.R.drawable.ic_media_pause);
                handler.post(updateRunnable);
            }
        });
    

        return view;
    }
    
    // SeekBar 监听器（定义为 field 避免重复注册）
    private final SeekBar.OnSeekBarChangeListener seekListener = new SeekBar.OnSeekBarChangeListener() {
        @Override public void onStartTrackingTouch(SeekBar sb) {
            isUserSeeking = true;
        }
        @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
            if (fromUser) {
                tvCurrent.setText(formatTime(progress));
            }
        }
        @Override public void onStopTrackingTouch(SeekBar sb) {
            if (mediaPlayer != null) {
                mediaPlayer.seekTo(sb.getProgress());
            }
            isUserSeeking = false;
            if (mediaPlayer != null && mediaPlayer.isPlaying()) {
                handler.post(updateRunnable);
            }
        }
    };
    
    // ------------- 初始化（文件路径方式） -------------
    public void initMediaPlayerFromPath(String path) {
        // 先释放旧的播放器（如果有）
        releaseMediaPlayer();

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setDataSource(path);
            // 异步 prepare，避免阻塞 UI 线程
            mediaPlayer.setOnPreparedListener(mp -> {
                commonSetupAfterCreate();
                // 如需自动播放可以在此处调用：
                // mp.start();
                // btnPlay.setImageResource(android.R.drawable.ic_media_pause);
                // handler.post(updateRunnable);
            });
            mediaPlayer.prepareAsync();
        } catch (IOException e) {
            e.printStackTrace();
            releaseMediaPlayer();
            btnPlay.setEnabled(false);
        }
    }

    // 创建完成后公共设置（重用）
    private void commonSetupAfterCreate() {
        // 移除旧的更新回调，避免重复
        handler.removeCallbacks(updateRunnable);

        // 初始化进度条与总时长
        int duration = mediaPlayer.getDuration();
        seekBar.setMax(duration);
        seekBar.setProgress(0);
        tvTotal.setText(formatTime(duration));
        tvCurrent.setText(formatTime(0));
        btnPlay.setEnabled(true);
        btnPlay.setImageResource(android.R.drawable.ic_media_play);

        // 播放完成回调
        mediaPlayer.setOnCompletionListener(mp -> {
            handler.removeCallbacks(updateRunnable);
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
            seekBar.setProgress(0);
            tvCurrent.setText(formatTime(0));
        });
    }

    // 彻底释放 MediaPlayer，并清理回调、重置 UI
    private void releaseMediaPlayer() {
        // 移除更新回调，避免 handler 继续 post 导致与新播放器冲突
        handler.removeCallbacks(updateRunnable);

        if (mediaPlayer != null) {
            try {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.stop();
                }
            } catch (IllegalStateException ignored) { }
            try {
                mediaPlayer.reset();
            } catch (IllegalStateException ignored) { }
            try {
                mediaPlayer.release();
            } catch (IllegalStateException ignored) { }
            mediaPlayer = null;
        }

        // 重置 UI（防止上一播放器残留状态）
        getActivity().runOnUiThread(() -> {
            try {
                seekBar.setProgress(0);
                seekBar.setMax(0);
            } catch (Exception ignored) {}
            tvCurrent.setText(formatTime(0));
            tvTotal.setText(formatTime(0));
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
            btnPlay.setEnabled(false); // 等新媒体就绪后再启用
        });
    }
    
    // 把毫秒格式化为 mm:ss（支持小时也可拓展）
    private String formatTime(int ms) {
        int totalSeconds = ms / 1000;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        releaseMediaPlayer();
    }

    private void bindViews(){
        btnGenerate = view.findViewById(R.id.btnGenerate);
        btnRestoreDefaults = view.findViewById(R.id.btnRestoreDefaults);
        etInput1 = view.findViewById(R.id.etInput1);
        etInputnote = view.findViewById(R.id.btnPick);
        etExternalPath = view.findViewById(R.id.etExternalPath);
        spinnerOutputType = view.findViewById(R.id.spinnerOutputType);
        spinnerMode = view.findViewById(R.id.spinnerMode);
        switch1 = view.findViewById(R.id.m3_switch);
        etParam1 = view.findViewById(R.id.etParam1);
        etParam2 = view.findViewById(R.id.etParam2);
        etParam3 = view.findViewById(R.id.etParam3);
        etParam4 = view.findViewById(R.id.etParam4);
        etParam5 = view.findViewById(R.id.etParam5);
        etParam6 = view.findViewById(R.id.etParam6);
        etParam7 = view.findViewById(R.id.etParam7);
        etParam8 = view.findViewById(R.id.etParam8);
        rvMapSI = view.findViewById(R.id.rvMapStringInt);
        rvMapIS = view.findViewById(R.id.rvMapIntString);
        containerExternalPathh = view.findViewById(R.id.containerExternalPath);
    }

    private void setupSpinners(){
        ArrayAdapter<String> outAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, new String[]{"内部", "外部路径"});
        outAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerOutputType.setAdapter(outAdapter);
        spinnerOutputType.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (position == 1) { // 外部
                    containerExternalPathh.setVisibility(View.VISIBLE);
                } else {
                    containerExternalPathh.setVisibility(View.GONE);
                }
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        ArrayAdapter<String> modeAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, new String[]{"模拟音量", "固定音量"});
        modeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMode.setAdapter(modeAdapter);
    }

    private void setupRecyclerViews(){
        adapterSI = new MapStringIntAdapter(getActivity(), new ArrayList<MapStringIntAdapter.Entry>());
        rvMapSI.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvMapSI.setAdapter(adapterSI);

        adapterIS = new MapIntStringAdapter(getActivity(), new ArrayList<MapIntStringAdapter.Entry>());
        rvMapIS.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvMapIS.setAdapter(adapterIS);

        view.findViewById(R.id.btnAddMapSI).setOnClickListener(v -> { adapterSI.addItem(new MapStringIntAdapter.Entry("key", 0)); savePrefs(); });
        view.findViewById(R.id.btnAddMapIS).setOnClickListener(v -> { adapterIS.addItem(new MapIntStringAdapter.Entry(0, "val")); savePrefs(); });
    }

    private void setupListeners(){
        btnGenerate.setOnClickListener(v -> {
            savePrefs();
            btnGenerate.setEnabled(false);
            
            Executors.newSingleThreadExecutor().execute(() -> {
            try {
                    File inputmidi = new File(getInput1());
File sampleDir = new File(getActivity().getExternalFilesDir(null), "note");
File folder;
            if (getOutputType() == 0) {
                folder = new File(getActivity().getExternalFilesDir(null), "MusicOutput");
            } else {
                folder = new File(getExternalOutputPath());
            }
            folder.mkdirs();
            File outWav = new File(folder, getFileNameWithoutExtension(inputmidi) + ".wav");
File outTxt = new File(folder, getFileNameWithoutExtension(inputmidi) + ".txt");
McMusicConverter converter = new McMusicConverter.Builder()
    .setMidiFile(inputmidi)
    .setSampleFolder(sampleDir)
    .setOutputWav(outWav)
    .setOutputTxt(outTxt)
    .setMcTick(getParam1())
    .setMaxSimulNotes(getParam2())
    .setPitchPrecision(getParam3())
    .setGlobalPitchFactor(getParam4())
    .setVolumeMode(getMode())
    .setSimplificationLevel(getParam5())
    .setSfxMapping(getMapIntStringAsList())
    .setInstBases(getMapStringIntAsList())
    .setScoreboardName(getParam6())
    .setStartOffset(getParam8())
    .setEnableStacking(getIsEn())
    .setMaxChars(getParam7())
    .build();

converter.convertAndRender(new McMusicConverter.Callback() {
    @Override
    public void onProgress(String message, int percent) {
    getActivity().runOnUiThread(() -> {
        //Toast.makeText(getActivity(), "Progress: " + message + " (" + percent + "%)", Toast.LENGTH_SHORT).show();
    });
        //Toast.makeText(getActivity(), "Progress: " + message + " (" + percent + "%)", Toast.LENGTH_SHORT).show();
        //Log.d("MyApp", "Progress: " + message + " (" + percent + "%)");
    }
    @Override
    public void onComplete(File wavFile, File txtFile) {
        getActivity().runOnUiThread(() -> {
        btnGenerate.setEnabled(true);
        Toast.makeText(getActivity(), "Done. Wav: " + wavFile + " Txt: " + txtFile, Toast.LENGTH_SHORT).show();
        initMediaPlayerFromPath(wavFile.getAbsolutePath());
        tvWav.setText(wavFile.getName());
    });
        
        //Log.d("MyApp", "Done. Wav: " + wavFile + " Txt: " + txtFile);
    }
    @Override
    public void onError(Exception e) {
    getActivity().runOnUiThread(() -> {
        btnGenerate.setEnabled(true);
        Toast.makeText(getActivity(), "Error converting" + e, Toast.LENGTH_SHORT).show();
    });
        
        //Log.e("MyApp", "Error converting", e);
    }
});          
            } catch (Exception e) {
                e.printStackTrace();
                new Handler(Looper.getMainLooper()).post(() -> 
                    Toast.makeText(getActivity(), "错误: " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            }
        });
        
            // TODO: 调用生成逻辑
        });

        etInputnote.setOnClickListener(v -> {
            String[] types = new String[]{"audio/*"};
            openDocLauncher.launch(types);
        });

        btnRestoreDefaults.setOnClickListener(v -> {
            restoreDefaults();
            savePrefs();
        });

        adapterSI.setOnDataChanged(() -> savePrefs());
        adapterIS.setOnDataChanged(() -> savePrefs());
    }

    @Override
    public void onPause() {
        super.onPause();
        // 不再需要单独保存（已经有自动保存点），但为了保险再次保存
        savePrefs();
        // 暂停播放（可按需调整）
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            btnPlay.setImageResource(android.R.drawable.ic_media_play);
            handler.removeCallbacks(updateRunnable);
        }
    }

    // 保存：把你原来要保存的字段一次性写入 DataStore（事务）
    private void savePrefs(){
        final String input1 = etInput1.getText().toString();
        final int outputType = spinnerOutputType.getSelectedItemPosition();
        final int mode = spinnerMode.getSelectedItemPosition();
        final String externalPath = etExternalPath.getText().toString();
        final boolean isEn = switch1.isSelected();
        final String p1 = etParam1.getText().toString();
        final String p2 = etParam2.getText().toString();
        final String p3 = etParam3.getText().toString();
        final String p4 = etParam4.getText().toString();
        final String p5 = etParam5.getText().toString();
        final String p6 = etParam6.getText().toString();
        final String p7 = etParam7.getText().toString();
        final String p8 = etParam8.getText().toString();

        // maps -> json strings (和原来行为一致)
        JSONArray arrSI = new JSONArray();
        try {
            for (MapStringIntAdapter.Entry it : adapterSI.getItems()){
                JSONObject o = new JSONObject();
                o.put("k", it.key);
                o.put("v", it.value);
                arrSI.put(o);
            }
        } catch (Exception ex){ ex.printStackTrace(); }

        JSONArray arrIS = new JSONArray();
        try {
            for (MapIntStringAdapter.Entry it : adapterIS.getItems()){
                JSONObject o = new JSONObject();
                o.put("k", it.key);
                o.put("v", it.value);
                arrIS.put(o);
            }
        } catch (Exception ex){ ex.printStackTrace(); }

        // 一次性写入所有字段（事务）
        dsMgr.writeAll(prefsIn -> {
            MutablePreferences m = prefsIn.toMutablePreferences();
            // 使用 string keys 保持简单（也可用 PreferencesKeys.intKey）
            m.set(PreferencesKeys.stringKey("input1"), input1);
            m.set(PreferencesKeys.intKey("outputType"), outputType);
            m.set(PreferencesKeys.intKey("mode"), mode);
            m.set(PreferencesKeys.stringKey("externalPath"), externalPath);
            m.set(PreferencesKeys.booleanKey("isEn"), isEn);
            m.set(PreferencesKeys.stringKey("param1"), p1);
            m.set(PreferencesKeys.stringKey("param2"), p2);
            m.set(PreferencesKeys.stringKey("param3"), p3);
            m.set(PreferencesKeys.stringKey("param4"), p4);
            m.set(PreferencesKeys.stringKey("param5"), p5);
            m.set(PreferencesKeys.stringKey("param6"), p6);
            m.set(PreferencesKeys.stringKey("param7"), p7);
            m.set(PreferencesKeys.stringKey("param8"), p8);
            m.set(PreferencesKeys.stringKey("map_si"), arrSI.toString());
            m.set(PreferencesKeys.stringKey("map_is"), arrIS.toString());
            return m;
        })
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(ignored -> {
            // saved
        }, throwable -> {
            throwable.printStackTrace();
        });
    }

    // 加载：异步读取一次性快照，然后在主线程更新 UI
    private void loadPrefs(){
        dsMgr.readOnce()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(prefs -> {
                // 获取值，若 null 使用默认
                String in1 = prefs.get(PreferencesKeys.stringKey("input1"));
                if (in1 == null) in1 = "input.mid";
                etInput1.setText(in1);

                Integer outType = prefs.get(PreferencesKeys.intKey("outputType"));
                spinnerOutputType.setSelection(outType == null ? 0 : outType);

                Integer mode = prefs.get(PreferencesKeys.intKey("mode"));
                spinnerMode.setSelection(mode == null ? 0 : mode);
                
                switch1.setChecked(prefs.get(PreferencesKeys.booleanKey("isEn")) == null ? true : prefs.get(PreferencesKeys.booleanKey("isEn")));

                etExternalPath.setText(prefs.get(PreferencesKeys.stringKey("externalPath")) == null ? "output" : prefs.get(PreferencesKeys.stringKey("externalPath")));
                etParam1.setText(prefs.get(PreferencesKeys.stringKey("param1")) == null ? "0.05" : prefs.get(PreferencesKeys.stringKey("param1")));
                etParam2.setText(prefs.get(PreferencesKeys.stringKey("param2")) == null ? "5" : prefs.get(PreferencesKeys.stringKey("param2")));
                etParam3.setText(prefs.get(PreferencesKeys.stringKey("param3")) == null ? "4" : prefs.get(PreferencesKeys.stringKey("param3")));
                etParam4.setText(prefs.get(PreferencesKeys.stringKey("param4")) == null ? "1" : prefs.get(PreferencesKeys.stringKey("param4")));
                etParam5.setText(prefs.get(PreferencesKeys.stringKey("param5")) == null ? "0" : prefs.get(PreferencesKeys.stringKey("param5")));
                etParam6.setText(prefs.get(PreferencesKeys.stringKey("param6")) == null ? "t" : prefs.get(PreferencesKeys.stringKey("param6")));
                etParam7.setText(prefs.get(PreferencesKeys.stringKey("param7")) == null ? "10000" : prefs.get(PreferencesKeys.stringKey("param7")));
                etParam8.setText(prefs.get(PreferencesKeys.stringKey("param8")) == null ? "0" : prefs.get(PreferencesKeys.stringKey("param8")));

                // maps
                adapterSI.clear();
                String si = prefs.get(PreferencesKeys.stringKey("map_si"));
                if (si != null) {
                    try {
                        JSONArray a = new JSONArray(si);
                        for (int i=0;i<a.length();i++){
                            JSONObject o = a.getJSONObject(i);
                            adapterSI.addItem(new MapStringIntAdapter.Entry(o.optString("k"), o.optInt("v")));
                        }
                    } catch (JSONException ex){ ex.printStackTrace(); }
                }
                if (adapterSI.getItemCount() == 0) {
                    // defaults
                    // ... (和原来一样)
                    adapterSI.addItem(new MapStringIntAdapter.Entry("harp", 54));
                    adapterSI.addItem(new MapStringIntAdapter.Entry("bass", 30));
        adapterSI.addItem(new MapStringIntAdapter.Entry("pling", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bell", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("flute", 66));
        adapterSI.addItem(new MapStringIntAdapter.Entry("guitar", 42));
        adapterSI.addItem(new MapStringIntAdapter.Entry("chime", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("xylophone", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("iron_xylophone", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("cow_bell", 66));
        adapterSI.addItem(new MapStringIntAdapter.Entry("didgeridoo", 30));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bit", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("banjo", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bd", 0));
        adapterSI.addItem(new MapStringIntAdapter.Entry("snare", 0));
                }

                adapterIS.clear();
                String is = prefs.get(PreferencesKeys.stringKey("map_is"));
                if (is != null){
                    try {
                        JSONArray a = new JSONArray(is);
                        for (int i=0;i<a.length();i++){
                            JSONObject o = a.getJSONObject(i);
                            adapterIS.addItem(new MapIntStringAdapter.Entry(o.optInt("k"), o.optString("v")));
                        }
                    } catch (JSONException ex){ ex.printStackTrace(); }
                }
                if (adapterIS.getItemCount() == 0) {
                    adapterIS.addItem(new MapIntStringAdapter.Entry(122, "seashore"));
                    adapterIS.addItem(new MapIntStringAdapter.Entry(127, "gunshot"));
                }

            }, throwable -> {
                // 读取失败（首次运行或文件损坏等）
                throwable.printStackTrace();
                // 回退到默认设置
                restoreDefaults();
            });
    }

    private void restoreDefaults(){
        etInput1.setText("input.mid");
        spinnerOutputType.setSelection(0);
        spinnerMode.setSelection(0);
        etExternalPath.setText("output");
        switch1.setSelected(true);
        etParam1.setText("0.05");
        etParam2.setText("5");
        etParam3.setText("4");
        etParam4.setText("1");
        etParam5.setText("0");
        etParam6.setText("t");
        etParam7.setText("10000");
        etParam8.setText("0");
        spinnerMode.setSelection(0);
        File noteDir = new File(requireActivity().getExternalFilesDir(null), "note");
        MainActivity.deleteDir(noteDir);
        MainActivity.copyAssetsFolder(
                getActivity(),
                "note",
                noteDir
        );

        adapterSI.clear();
        adapterSI.addItem(new MapStringIntAdapter.Entry("harp", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bass", 30));
        adapterSI.addItem(new MapStringIntAdapter.Entry("pling", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bell", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("flute", 66));
        adapterSI.addItem(new MapStringIntAdapter.Entry("guitar", 42));
        adapterSI.addItem(new MapStringIntAdapter.Entry("chime", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("xylophone", 78));
        adapterSI.addItem(new MapStringIntAdapter.Entry("iron_xylophone", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("cow_bell", 66));
        adapterSI.addItem(new MapStringIntAdapter.Entry("didgeridoo", 30));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bit", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("banjo", 54));
        adapterSI.addItem(new MapStringIntAdapter.Entry("bd", 0));
        adapterSI.addItem(new MapStringIntAdapter.Entry("snare", 0));
        adapterIS.clear();
        adapterIS.addItem(new MapIntStringAdapter.Entry(122, "seashore"));
        adapterIS.addItem(new MapIntStringAdapter.Entry(127, "gunshot"));

        // 立即保存默认值
        savePrefs();
    }

    // 其余方法（文件处理、queryFileName、copyUriToFile、getFileNameWithoutExtension）保持不变
    // ...（省略，直接复制你原来的实现）
    public String getInput1(){ return etInput1.getText().toString(); }
    public int getOutputType() { return spinnerOutputType.getSelectedItemPosition(); }
    public int getMode() { return spinnerMode.getSelectedItemPosition(); }
    public String getExternalOutputPath(){ return etExternalPath.getText().toString(); }
    public boolean getIsEn() { return switch1.isChecked(); }
    public double getParam1(){ try { return Double.parseDouble(etParam1.getText().toString()); } catch(Exception e){ return 0.0; } }
    public int getParam2(){ try { return Integer.parseInt(etParam2.getText().toString()); } catch(Exception e){ return 0; } }
    public int getParam3(){ try { return Integer.parseInt(etParam3.getText().toString()); } catch(Exception e){ return 0; } }
    public double getParam4(){ try { return Double.parseDouble(etParam4.getText().toString()); } catch(Exception e){ return 0.0; } }
    public int getParam5(){ try { return Integer.parseInt(etParam5.getText().toString()); } catch(Exception e){ return 0; } }
    public String getParam6(){ try { return etParam6.getText().toString(); } catch(Exception e){ return "t"; } }
    public int getParam7(){ try { return Integer.parseInt(etParam7.getText().toString()); } catch(Exception e){ return 0; } }
    public int getParam8(){ try { return Integer.parseInt(etParam8.getText().toString()); } catch(Exception e){ return 0; } }
    public Map<Integer,String> getMapIntStringAsList(){
        Map<Integer, String> out = new HashMap<>();
        for (MapIntStringAdapter.Entry it : adapterIS.getItems()){
            out.put(it.key, it.value);
        }
        return out;
    }
    public Map<String, Integer> getMapStringIntAsList(){
        Map<String, Integer> out = new HashMap<>();
        for (MapStringIntAdapter.Entry it : adapterSI.getItems()){
            out.put(it.key, it.value);
        }
        return out;
    }

    
    // 传入note


    // 处理权限回调
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQ_PERMISSION) {
            boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (ok) {
                Toast.makeText(getActivity(), "权限已授予，请再次点击选择按钮", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getActivity(), "需要读取权限才能选择文件", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    // 当用户选择完文件后的处理：校验后缀、复制到目标目录
    private void handlePickedUri(Uri uri) {
        try {
            String fileName = queryFileName(uri);
            if (fileName == null) fileName = "unknown.wav";

            Toast.makeText(getActivity(), "已选: " + fileName, Toast.LENGTH_SHORT).show();

            // 强制校验后缀 .wav（更保险）
            if (!fileName.toLowerCase(Locale.ROOT).endsWith(".wav")) {
                Toast.makeText(getActivity(), "请只选择 .wav 文件", Toast.LENGTH_SHORT).show();
                return;
            }

            // 目标目录：Android/data/<pkg>/files/note  => getExternalFilesDir("note")
            File destDir = new File(getActivity().getExternalFilesDir(null), "note");
            if (!destDir.exists()) {
                boolean ok = destDir.mkdirs();
                if (!ok) {
                    Toast.makeText(getActivity(), "无法创建目标目录", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            File destFile = new File(destDir, fileName);

            // 复制数据
            boolean copied = copyUriToFile(uri, destFile);
            if (copied) {
                Toast.makeText(getActivity(), "文件已传入 note 目录", Toast.LENGTH_SHORT).show();

                // 尝试保留 Uri 权限（如果来自 SAF）
                try {
                    final int takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
                    getActivity().getContentResolver().takePersistableUriPermission(uri, takeFlags);
                } catch (Exception ignored) {}
            } else {
                Toast.makeText(getActivity(), "失败，请检查存储权限与空间", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getActivity(), "处理文件时出错", Toast.LENGTH_SHORT).show();
        }
    }

    // 从 ContentResolver 查询显示名
    private String queryFileName(Uri uri) {
        String name = null;
        ContentResolver cr = getActivity().getContentResolver();
        Cursor cursor = null;
        try {
            cursor = cr.query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return name;
    }

    // 复制 Uri 到目标文件（使用流）
    private boolean copyUriToFile(Uri uri, File outFile) {
        try (InputStream in = getActivity().getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(outFile)) {
            if (in == null) return false;
            byte[] buffer = new byte[8192];
            int len;
            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
            out.flush();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
   public static String getFileNameWithoutExtension(File file) {
    String fileName = file.getName();
    int dotIndex = fileName.lastIndexOf('.');
    if (dotIndex > 0) {
        return fileName.substring(0, dotIndex);
    }
    return fileName;
}



    
}