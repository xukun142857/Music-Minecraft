package command.plus;

import android.accessibilityservice.AccessibilityService;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.graphics.Path;
import android.accessibilityservice.GestureDescription;
import android.accessibilityservice.AccessibilityService;
import android.os.Build;
import androidx.annotation.RequiresApi;
import android.animation.ValueAnimator;
import android.app.Service;
import android.content.Intent;
import android.graphics.Point;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.datastore.preferences.core.Preferences;
import io.reactivex.rxjava3.core.SingleObserver;
import io.reactivex.rxjava3.disposables.Disposable;
import io.reactivex.rxjava3.schedulers.Schedulers;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;


public class MainAccessibilityService extends AccessibilityService {

    // 1. 添加静态实例，供外部调用
    private static MainAccessibilityService instance;

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams layoutParams;

    private DataManager dataManager;
    private TextView tvInfo;

    //private boolean isWindowAdded = false;
    
    private Handler handler = new Handler();
    private final long CHECK_INTERVAL_MS = 1000; // 检查间隔
    private Runnable checkRunnable;
    
    public interface WindowStateListener {
    void onWindowStateChanged(boolean isShown);
}
    
    private WindowStateListener listener;
    private boolean windowShown = false;

    public void setWindowStateListener(WindowStateListener l) {
        this.listener = l;
    }

    private void notifyState() {
        if (listener != null) {
            listener.onWindowStateChanged(windowShown);
        }
    }
   
    // 获取服务实例的方法
    public static MainAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
       
       instance = this;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }
    
   

    // 将原本的 init 改为 public 的 show 方法，供外部调用
    @SuppressLint("ClickableViewAccessibility")
    public void showFloatingWindow() {
        dataManager = HomeFragment.getDataManager();
        
        
        
        // 确保在主线程执行 UI 操作
        new Handler(Looper.getMainLooper()).post(() -> {
            if (windowShown) return;
            windowShown = true;
                
                notifyState();
                FloatToast.show(getApplicationContext(), "悬浮助手已开启");

            try {
                windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

                layoutParams = new WindowManager.LayoutParams();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    layoutParams.type = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
                } else {
                    layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
                }

                layoutParams.format = PixelFormat.TRANSLUCENT;
                layoutParams.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                        WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

                layoutParams.gravity = Gravity.TOP | Gravity.START;
                layoutParams.x = 100;
                layoutParams.y = 200;
                layoutParams.width = 500;
                layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;

                LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
                floatingView = inflater.inflate(R.layout.layout_floating_window, null);

                tvInfo = floatingView.findViewById(R.id.tv_info);
                Button btnBack = floatingView.findViewById(R.id.btn_back);
                Button btnNext = floatingView.findViewById(R.id.btn_next);
                View resizeHandle = floatingView.findViewById(R.id.view_resize_handle);

                updateInfoDisplay();

                // --- 事件绑定 ---
                btnBack.setOnClickListener(v -> {
                    dataManager.back();
                    updateInfoDisplay();
                });
                btnBack.setOnLongClickListener(v -> {
                    showJumpDialog();
                    return true;
                });

                btnNext.setOnClickListener(v -> {
                
                layoutParams.alpha = 0.4f;
                layoutParams.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                windowManager.updateViewLayout(floatingView, layoutParams);
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
            handleInputLogic();
        }, 100);
                
                    
                
                
                });

                tvInfo.setOnLongClickListener(v -> {
                    showMenuDialog();
                    return true;
                });

                // 移动逻辑
                floatingView.setOnTouchListener(new View.OnTouchListener() {
                    private int initialX, initialY;
                    private float initialTouchX, initialTouchY;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                initialX = layoutParams.x;
                                initialY = layoutParams.y;
                                initialTouchX = event.getRawX();
                                initialTouchY = event.getRawY();
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                layoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                                layoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                                try {
                                    windowManager.updateViewLayout(floatingView, layoutParams);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return true;
                        }
                        return false;
                    }
                });

                // 缩放逻辑
                resizeHandle.setOnTouchListener(new View.OnTouchListener() {
                    private int initialWidth, initialHeight;
                    private float initialTouchX, initialTouchY;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                initialWidth = floatingView.getWidth();
                                initialHeight = floatingView.getHeight();
                                initialTouchX = event.getRawX();
                                initialTouchY = event.getRawY();
                                return true;
                            case MotionEvent.ACTION_MOVE:
                                int newWidth = initialWidth + (int) (event.getRawX() - initialTouchX);
                                int newHeight = initialHeight + (int) (event.getRawY() - initialTouchY);
                                layoutParams.width = Math.max(newWidth, 250);
                                layoutParams.height = Math.max(newHeight, 200);
                                try {
                                    windowManager.updateViewLayout(floatingView, layoutParams);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                return true;
                        }
                        return false;
                    }
                });

                windowManager.addView(floatingView, layoutParams);
                

            } catch (Exception e) {
                e.printStackTrace();
                // 3. 替换 Toast
                FloatToast.show(getApplicationContext(), "悬浮窗启动失败: " + e.getMessage());
            }
            startAutoCheck();
        });
    }

    // 公开的关闭方法，供外部调用
    public void hideFloatingWindow() {
        if (!windowShown) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            if (windowShown && windowManager != null && floatingView != null) {
                try {
                    windowManager.removeView(floatingView);
                    windowShown = false;
                    notifyState();
                    // 3. 替换 Toast
                    FloatToast.show(getApplicationContext(), "悬浮窗已隐藏");
                } catch (Exception e) {
                    e.printStackTrace();
                    FloatToast.show(getApplicationContext(), "关闭失败: " + e.getMessage());
                }
            }
        });
    }

    // --- 内部逻辑 ---

    private void showJumpDialog() {
        try {
            Context ctx = new ContextThemeWrapper(getApplicationContext(), androidx.appcompat.R.style.Theme_AppCompat_Light_Dialog);
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setTitle("跳转位置");

            final EditText input = new EditText(ctx);
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
            input.setHint("输入数字索引");
            builder.setView(input);

            builder.setPositiveButton("确定", (dialog, which) -> {
                try {
                    int target = Integer.parseInt(input.getText().toString());
                    dataManager.jumpTo(target);
                    updateInfoDisplay();
                } catch (Exception e) {
                    FloatToast.show(getApplicationContext(), "输入错误");
                }
            });
            builder.setNegativeButton("取消", null);

            AlertDialog dialog = builder.create();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            } else {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
            }
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
            FloatToast.show(getApplicationContext(), "弹窗失败: " + e.getMessage());
        }
    }

    private void showMenuDialog() {
        try {
            Context ctx = new ContextThemeWrapper(getApplicationContext(), androidx.appcompat.R.style.Theme_AppCompat_Light_Dialog);
            String[] options = {"隐藏悬浮窗", "关闭服务", "选择文件", "取消"};
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setItems(options, (dialog, which) -> {
                switch (which) {
                    case 0: // 隐藏悬浮窗
                        hideFloatingWindow();
                        break;
                    case 1: // 关闭服务
                        hideFloatingWindow();
                        disableSelf();
                        break;
                    case 2: // 改变集合
                        showChangeSetDialog();
                        break;
                    case 3: // 取消
                        dialog.dismiss();
                        break;
                }
            });

            AlertDialog dialog = builder.create();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            } else {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
            }
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showChangeSetDialog() {
        try {
            Context ctx = new ContextThemeWrapper(getApplicationContext(), androidx.appcompat.R.style.Theme_AppCompat_Light_Dialog);
            AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
            builder.setTitle("加载指令文件");

            final EditText input = new EditText(ctx);
            input.setHint("/sdcard/Download/data.txt");
            builder.setView(input);

            builder.setPositiveButton("确定", (dialog, which) -> {
                String path = input.getText().toString();
                try {
                    dataManager.loadFromFile(path);
                    updateInfoDisplay();
                    FloatToast.show(getApplicationContext(), "集合已加载: " + dataManager.getTotalSize());
                } catch (Exception e) {
                    FloatToast.show(getApplicationContext(), "加载失败: " + e.getMessage());
                }
            });
            builder.setNegativeButton("取消", null);

            AlertDialog dialog = builder.create();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            } else {
                dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
            }
            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
 * 核心逻辑入口：改为链式调用
 */
private void handleInputLogic() {
    try {
        DataManager.DataItem current = dataManager.getCurrentItem();
        if (current == null) {
            FloatToast.show(getApplicationContext(), "完成");
            finishAll();
            return;
        }

        // 1. 执行初始点击 (1850, 560)
        performClickAt(getValueAsync("group_1",1,0), getValueAsync("group_1",2,0), getValueAsync("group_1",3,0), () -> {
           
            // 2. 初始点击完成并延迟0.3秒后，执行前置配置 A, B, C
            executePreActionsSequentially(current, () -> {
            
                // 点击输入框
                performClickAt(getValueAsync("group_9",1,0), getValueAsync("group_9",2,0), getValueAsync("group_9",3,0), () -> {
                
                // 3. 所有前置点击完成后，获取最新的根节点查找输入框
                AccessibilityNodeInfo rootNode = getRootInActiveWindow();
                if (rootNode == null) {
                    FloatToast.show(getApplicationContext(), "未获得根节点");
                    finishAll();
                    return;
                }

                AccessibilityNodeInfo focusNode = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
                if (focusNode == null) {
                    FloatToast.show(getApplicationContext(), "未找到输入框焦点");
                    rootNode.recycle();
                    finishAll();
                    return;
                }

                // 4. 执行文本输入
                Bundle arguments = new Bundle();
                arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, current.getText());
                boolean result = focusNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments);

                if (result) {
                    dataManager.next();
                    updateInfoDisplay();
                    // 5. 输入成功后执行最后的提交点击
                    performClickAt(getValueAsync("group_10",1,0), getValueAsync("group_10",2,0), getValueAsync("group_10",3,0), null);
                } else {
                    FloatToast.show(getApplicationContext(), "自动输入失败");
                    finishAll();
                }

                // 释放资源
                focusNode.recycle();
                rootNode.recycle();
                finishAll();
                
                });
            });
        });
        
        
        
    } catch (Exception e) {
        e.printStackTrace();
        FloatToast.show(getApplicationContext(), "输入异常: " + e.getMessage());
        finishAll();
    }
}

/**
 * 按顺序执行 A -> B -> C 的逻辑封装
 */
private void executePreActionsSequentially(DataManager.DataItem item, Runnable finalCallback) {
    // 顺序：执行A -> 完成后执行B -> 完成后执行C -> 完成后执行最终回调
    performActionForCode("A", item.block.configA, item, () -> {
        performActionForCode("B", item.block.configB, item, () -> {
            performActionForCode("C", item.block.configC, item, finalCallback);
        });
    });
}

/**
 * 对单个 code 执行动作，支持内部多步点击的回调嵌套
 */

    private void updateInfoDisplay() {
    if (tvInfo == null) return;
    tvInfo.post(() -> {
        try {
            // 1. 先获取对象并判空
            DataManager.DataItem item = dataManager.getCurrentItem();
            
            if (item == null) {
                // 如果数据为空，显示“完成”而不是让程序崩溃
                tvInfo.setText("状态: 已完成或未加载\n总数: " + dataManager.getTotalSize());
            } else {
                String content = item.getText();
                // 增加安全性判定：即使 getText() 返回 null 也能处理
                String safeContent = (content != null) ? content : "无内容";
                
                tvInfo.setText(String.format("当前索引: %d/%d\n下一条长度: %d\n下一条内容: %s",
                        dataManager.getCurrentIndex(),
                        dataManager.getTotalSize(),
                        safeContent.length(),
                        safeContent));
            }
        } catch (Exception e) {
            e.printStackTrace();
            tvInfo.setText("显示异常: " + e.getMessage());
        }
    });
}
    
    
    /**
     * 根据 block 的 configA/B/C 执行对应的“块点击操作”。
     * 若 config 为 0 则跳过对应动作（按你给定的规则）。
     *
     * 这里示例实现：
     * - 尝试按顺序执行 A、B、C 的操作（如果非0）
     * - 对应映射在 performActionForCode(...) 中实现（请按目标 App 修改）
     */
    
    /**
     * 对单个 code 执行动作。这里包含示例映射，请按实际场景替换映射内容。
     *
     * axis: "A" / "B" / "C"
     * code: 0/1/2
     */
    private void performActionForCode(String axis, int code, DataManager.DataItem item, Runnable next) {
    if (code == 0) {
        if (next != null) next.run();
        return;
    }

    String key = axis + "-" + code;
    switch (key) {
        case "A-1":
            performClickAt(getValueAsync("group_2",1,0), getValueAsync("group_2",2,0), getValueAsync("group_3",3,0), () -> 
                performClickAt(getValueAsync("group_3",1,0), getValueAsync("group_3",2,0), getValueAsync("group_3",3,0), next));
            break;
        case "A-2":
            performClickAt(getValueAsync("group_2",1,0), getValueAsync("group_2",2,0), getValueAsync("group_2",3,0), () -> 
                performClickAt(getValueAsync("group_4",1,0), getValueAsync("group_4",2,0), getValueAsync("group_4",3,0), next));
            break;
        case "B-1":
            performClickAt(getValueAsync("group_5",1,0), getValueAsync("group_5",2,0), getValueAsync("group_5",3,0), () -> 
                performClickAt(getValueAsync("group_6",1,0), getValueAsync("group_6",2,0), getValueAsync("group_6",3,0), next));
            break;
        case "C-1":
            performClickAt(getValueAsync("group_7",1,0), getValueAsync("group_7",2,0), getValueAsync("group_7",3,0), () -> 
                performClickAt(getValueAsync("group_8",1,0), getValueAsync("group_8",2,0), getValueAsync("group_8",3,0), next));
            break;
        default:
            if (next != null) next.run();
            break;
    }
}

/**
 * 执行点击并延迟，通过 Callback 实现真正的异步串行
 */
    
    /**
 * 执行点击并延迟
 * @param x 坐标X
 * @param y 坐标Y
 * @param delayMillis 点击完成后的延迟时间（毫秒）
 * @param callback 延迟结束后的回调逻辑（可选）
 */
private void performClickAt(int x, int y, long delayMillis, Runnable callback) {
    if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.N) return;

    Path clickPath = new Path();
    clickPath.moveTo(x, y);
    
    GestureDescription.Builder gestureBuilder = new GestureDescription.Builder();
    gestureBuilder.addStroke(new GestureDescription.StrokeDescription(clickPath, 0, 50));

    dispatchGesture(gestureBuilder.build(), new AccessibilityService.GestureResultCallback() {
        @Override
        public void onCompleted(GestureDescription gestureDescription) {
            super.onCompleted(gestureDescription);
            // 关键：手势完成后，在 Handler 中延迟执行回调
            if (callback != null) {
                new Handler(Looper.getMainLooper()).postDelayed(callback, Math.max(0, delayMillis));
            }
        }
        
        @Override
        public void onCancelled(GestureDescription gestureDescription) {
            super.onCancelled(gestureDescription);
            // 如果取消了，通常也要回调以避免逻辑卡死，或者进行错误处理
            if (callback != null) callback.run();
        }
    }, null);
}


    @Override
    public void onDestroy() {
        hideFloatingWindow();
        instance = null; // 销毁引用
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {
        hideFloatingWindow();
    }
    
    public boolean isWindow() {
    return windowShown;
}
    
    private void finishAll() {
    new Handler(Looper.getMainLooper()).post(() -> {
        layoutParams.alpha = 1.0f;
                    layoutParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                windowManager.updateViewLayout(floatingView, layoutParams);
    });
}

    private void startAutoCheck() {
        checkRunnable = new Runnable() {
            @Override
            public void run() {
                checkAndBringBackIfNeeded(true);
                handler.postDelayed(this, CHECK_INTERVAL_MS);
            }
        };
        handler.postDelayed(checkRunnable, CHECK_INTERVAL_MS);
    }

    /**
     * 检查悬浮窗是否在可见区域（以大部分在屏幕外或完全在外为准），
     * 若不可见，则移动到安全位置（屏幕中心或最近边）
     *
     * @param animate 是否用动画平滑移动
     */
    private void checkAndBringBackIfNeeded(boolean animate) {
        // 首先确保 view 已经测量完（宽高可用）
        int vw = floatingView.getWidth();
        int vh = floatingView.getHeight();
        if (vw == 0 || vh == 0) {
            // 如果尚未测量，延后一次检查
            floatingView.post(new Runnable() {
                @Override
                public void run() {
                    checkAndBringBackIfNeeded(animate);
                }
            });
            return;
        }

        Point real = getRealScreenSize();
        int screenW = real.x;
        int screenH = real.y;

        // 计算当前悬浮窗在屏幕上的矩形（params.x/y 结合 gravity=START|TOP）
        int left = layoutParams.x;
        int top = layoutParams.y;
        int right = left + vw;
        int bottom = top + vh;

        // 判定条件：完全在屏幕外 或者 可见面积小于阈值（例如 30%）
        boolean completelyOutside = (right < 0 || left > screenW || bottom < 0 || top > screenH);
        int visibleWidth = Math.max(0, Math.min(right, screenW) - Math.max(left, 0));
        int visibleHeight = Math.max(0, Math.min(bottom, screenH) - Math.max(top, 0));
        float visibleAreaRatio = (visibleWidth * visibleHeight) / (float) (vw * vh);

        if (completelyOutside || visibleAreaRatio == 0f) {
            // 需要把它“传送”回来，选择目标位置（这里示例：屏幕中心）
            int targetX = (screenW - vw) / 2;
            int targetY = (screenH - vh) / 2;

            // 也可以选择最近边：例如如果 left < 0 则靠左边，right>screenW 则靠右边等
            if (completelyOutside) {
                // 更智能的策略：把它移到最近可见边
                if (right < 0) targetX = 10; // 靠左
                else if (left > screenW) targetX = screenW - vw - 10; // 靠右
                if (bottom < 0) targetY = 10; // 靠上
                else if (top > screenH) targetY = screenH - vh - 10; // 靠下
            }

            if (animate) animateMoveTo(targetX, targetY);
            else {
                layoutParams.x = targetX;
                layoutParams.y = targetY;
                windowManager.updateViewLayout(floatingView, layoutParams);
            }
        }
    }

    private void animateMoveTo(final int targetX, final int targetY) {
        final int startX = layoutParams.x;
        final int startY = layoutParams.y;
        ValueAnimator anim = ValueAnimator.ofFloat(0f, 1f);
        anim.setDuration(300);
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                float t = (float) valueAnimator.getAnimatedValue();
                layoutParams.x = (int) (startX + (targetX - startX) * t);
                layoutParams.y = (int) (startY + (targetY - startY) * t);
                try {
                    windowManager.updateViewLayout(floatingView, layoutParams);
                } catch (IllegalArgumentException ignored) {
                }
            }
        });
        anim.start();
    }

    private Point getRealScreenSize() {
        Point p = new Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            final DisplayMetrics dm = getResources().getDisplayMetrics();
            p.x = dm.widthPixels;
            p.y = dm.heightPixels;
        } else {
            android.view.Display display = windowManager.getDefaultDisplay();
            display.getRealSize(p);
        }
        return p;
    }
    
    private int getValueAsync(String id, int index, int defaultValue) {
    androidx.datastore.preferences.core.Preferences prefs = DataStoreManager.get(getApplicationContext()).readOnce().blockingGet();
    Integer v = prefs.get(Keys.kInt(id, index));
    return v != null ? v : defaultValue;
}

}
