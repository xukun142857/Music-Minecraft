package command.plus;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.datastore.preferences.core.MutablePreferences;
import androidx.datastore.preferences.core.Preferences;
import androidx.datastore.preferences.rxjava3.RxPreferenceDataStoreBuilder;
import androidx.datastore.rxjava3.RxDataStore;

import io.reactivex.rxjava3.core.Single;

import androidx.datastore.preferences.core.PreferencesKeys;

public class DataStoreManager {
    private static final String NAME = "app_prefs"; // 与你原来的 PREFS_NAME 对应
    private static DataStoreManager instance;
    private final RxDataStore<Preferences> dataStore;

    private DataStoreManager(@NonNull Context ctx) {
        // 使用 RxPreferenceDataStoreBuilder 在 Java 中创建 DataStore（Rx-friendly）
        dataStore = new RxPreferenceDataStoreBuilder(ctx, NAME).build();
    }

    public static synchronized DataStoreManager get(@NonNull Context ctx) {
        if (instance == null) instance = new DataStoreManager(ctx.getApplicationContext());
        return instance;
    }

    // 一次性写入（事务）：接收一个写入回调，返回完成的 Single<Preferences>
    public Single<Preferences> writeAll(java.util.function.Function<Preferences, MutablePreferences> writer) {
    return dataStore.updateDataAsync(prefsIn -> {
        MutablePreferences mutable = writer.apply(prefsIn);
        return Single.just(mutable);
    });
}

    // 读取一次性快照（Single<Preferences>）
    public io.reactivex.rxjava3.core.Single<Preferences> readOnce() {
        // data() 流 -> 取第一项（快照）
        return dataStore.data().firstOrError();
    }

    // 常用 key helpers
    public static Preferences.Key<String> keyString(String name) {
        return PreferencesKeys.stringKey(name);
    }
    public static Preferences.Key<Integer> keyInt(String name) {
        return PreferencesKeys.intKey(name);
    }
}