package command.plus;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * DataManager - 解析新版文件格式并维护当前索引。
 *
 * 文件格式示例：
 * $1,0,1
 * /first line content
 * /second line content
 * $
 * $2,1,0
 * /another
 * $
 */
public class DataManager {
    public static class Block {
        public final int configA; // 0/1/2
        public final int configB; // 0/1
        public final int configC; // 0/1
        public final int startIndex; // 在全局 dataSet 中的起始索引
        public int endIndex; // 在全局 dataSet 中的结束索引（包含）

        public Block(int a, int b, int c, int start) {
            this.configA = a;
            this.configB = b;
            this.configC = c;
            this.startIndex = start;
            this.endIndex = start;
        }

        @Override
        public String toString() {
            return "Block{A=" + configA + ",B=" + configB + ",C=" + configC +
                    ",start=" + startIndex + ",end=" + endIndex + "}";
        }
    }

    public static class DataItem {
        public final String raw;   // 原始行，保留前导 '/' （或你也可以用 substring）
        public final Block block;  // 所属块（可能为 null，如果文件中有孤立行）
        public final int globalIndex; // 在全局 dataSet 中的位置（从0开始）
        public final int indexInBlock; // 在所属块内的位置，从0开始

        public DataItem(String raw, Block block, int globalIndex, int indexInBlock) {
            this.raw = raw;
            this.block = block;
            this.globalIndex = globalIndex;
            this.indexInBlock = indexInBlock;
        }

        public String getText() {
            // 返回要输入的字符串：去掉前导 '/'（如果需要）
            if (raw != null && raw.startsWith("/")) {
                return raw;
            }
            return raw;
        }

        @Override
        public String toString() {
            return "DataItem{" + "text='" + getText() + '\'' +
                    ", idx=" + globalIndex +
                    ", inBlock=" + indexInBlock +
                    ", block=" + (block == null ? "null" : block.toString()) + '}';
        }
    }

    private final List<DataItem> dataSet = new ArrayList<>();
    private final List<Block> blocks = new ArrayList<>();
    private int currentIndex = 0;

    public DataManager() {
        // 默认可以保留空实现或加载默认项
    }

    /**
     * 解析新版文件格式
     *
     * 支持多个块：
     *  $A,B,C    // 头行（A:0/1/2 ; B:0/1 ; C:0/1）
     *  /...
     *  /...
     *  $
     *
     *  每个 $...$ 里面的 / 行将被加入全局序列，并且记录所属 block 与 block 内的索引。
     */
    public void loadFromFile(String filePath) throws Exception {
        File file = new File(filePath);
        if (!file.exists()) throw new Exception("文件不存在: " + filePath);

        dataSet.clear();
        blocks.clear();
        currentIndex = 0;

        BufferedReader br = new BufferedReader(new FileReader(file));
        String line;
        Block currentBlock = null;
        int nextGlobalIndex = 0;
        int indexInCurrentBlock = 0;

        while ((line = br.readLine()) != null) {
            if (line == null) continue;
            String trimmed = line.trim();
            if (trimmed.isEmpty()) continue;

            // 如果是块头：例如 "$1,0,1"
            if (trimmed.startsWith("$") && trimmed.length() > 1) {
                // 解析 "$A,B,C"
                String remainder = trimmed.substring(1).trim();
                String[] parts = remainder.split(",");
                if (parts.length >= 3) {
                    try {
                        int a = Integer.parseInt(parts[0].trim());
                        int b = Integer.parseInt(parts[1].trim());
                        int c = Integer.parseInt(parts[2].trim());
                        currentBlock = new Block(a, b, c, nextGlobalIndex);
                        blocks.add(currentBlock);
                        indexInCurrentBlock = 0;
                        continue;
                    } catch (NumberFormatException ex) {
                        // 不是合法的头行，则当作普通行处理（回退到下面）
                        currentBlock = null;
                    }
                } else {
                    // 如果是单独的 "$" 表示块结束
                    if (trimmed.equals("$")) {
                        if (currentBlock != null) {
                            currentBlock.endIndex = nextGlobalIndex - 1;
                            currentBlock = null;
                        }
                        continue;
                    }
                }
            }

            // 单独的 "$" 作为块结束
            if (trimmed.equals("$")) {
                if (currentBlock != null) {
                    currentBlock.endIndex = nextGlobalIndex - 1;
                }
                currentBlock = null;
                continue;
            }

            // 仅处理以 '/' 开头的行（保持之前的习惯）
            if (trimmed.startsWith("/")) {
                DataItem item = new DataItem(trimmed, currentBlock, nextGlobalIndex, indexInCurrentBlock);
                dataSet.add(item);
                nextGlobalIndex++;
                indexInCurrentBlock++;
                if (currentBlock != null) {
                    currentBlock.endIndex = nextGlobalIndex - 1;
                }
            } else {
                // 如果遇到非 '/' 行，忽略或可选择将其加入（这里我们忽略）
                // 若需要保留，可把下面注释去掉
                // DataItem item = new DataItem(trimmed, currentBlock, nextGlobalIndex, indexInCurrentBlock);
                // dataSet.add(item);
                // nextGlobalIndex++;
                // indexInCurrentBlock++;
            }
        }
        br.close();
        reset();
    }

    public void reset() {
        currentIndex = 0;
    }

    public DataItem getCurrentItem() {
        if (dataSet == null || dataSet.isEmpty()) return null;
        if (currentIndex < dataSet.size()) {
            return dataSet.get(currentIndex);
        }
        return null;
    }

    public String getCurrentText() {
        DataItem it = getCurrentItem();
        return it == null ? null : it.getText();
    }

    public int getCurrentIndex() { return currentIndex; }
    public int getTotalSize() { return dataSet.size(); }

    public void next() { if (currentIndex < dataSet.size()) currentIndex++; }
    public void back() { if (currentIndex > 0) currentIndex--; }

    public void jumpTo(int index) {
        if (index >= 0 && index <= dataSet.size()) {
            currentIndex = index;
        }
    }

    public List<Block> getBlocks() { return blocks; }
    public List<DataItem> getAllItems() { return dataSet; }
}