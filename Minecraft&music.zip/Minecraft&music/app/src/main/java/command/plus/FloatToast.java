package command.plus; // <- 修改为你自己的包名

import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.TextView;

public final class FloatToast {

    private static TextView view; // 我们需要直接操作 alpha 和 text，所以用 TextView
    private static WindowManager windowManager;
    private static final Handler handler = new Handler(Looper.getMainLooper());
    private static Runnable removeRunnable;

    // 可调参数
    private static final long DEFAULT_DURATION = 2000L;    // 显示时长（ms）
    private static final long FADE_IN_MS = 250L;          // 淡入时长
    private static final long FADE_OUT_MS = 200L;         // 淡出时长
    private static final float DEFAULT_TARGET_ALPHA = 1f; // 最终不透明度（0 - 1），越小越透明

    private FloatToast() { }

    // 简单调用
    public static void show(Context context, String msg) {
        show(context, msg, DEFAULT_DURATION, DEFAULT_TARGET_ALPHA);
    }

    // 指定时长
    public static void show(Context context, String msg, long durationMs) {
        show(context, msg, durationMs, DEFAULT_TARGET_ALPHA);
    }

    // 指定时长 + 指定目标 alpha（例如 0.85f 或 0.7f）
    public static void show(Context context, String msg, long durationMs, float targetAlpha) {
        if (context == null) return;
        final Context appContext = context.getApplicationContext();

        handler.post(() -> {
            try {
                // 1) 取消计划移除（避免旧的 removeRunnable 在短时间内干掉新视图）
                if (removeRunnable != null) {
                    handler.removeCallbacks(removeRunnable);
                    removeRunnable = null;
                }

                // 2) 如果已有 view，先立即移除（或你也可选择更新文本并重置计时）
                if (windowManager != null && view != null) {
                    try {
                        windowManager.removeViewImmediate(view);
                    } catch (Exception ignored) {
                        try { windowManager.removeView(view); } catch (Exception ignored2) {}
                    }
                    view = null;
                    windowManager = null;
                }

                // 3) 创建 TextView（样式可按需改）
                windowManager = (WindowManager) appContext.getSystemService(Context.WINDOW_SERVICE);

                TextView tv = new TextView(appContext);
                tv.setText(msg);
                tv.setTextSize(14);
                int padH = dpToPx(appContext, 16);
                int padV = dpToPx(appContext, 10);
                tv.setPadding(padH, padV, padH, padV);
                tv.setBackgroundResource(android.R.drawable.toast_frame); // 系统风格背景
                tv.setAlpha(0f); // 从透明开始，淡入到 targetAlpha
                tv.setGravity(Gravity.CENTER);

                view = tv;

                int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE;

                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT
                );

                params.gravity = Gravity.CENTER;
                params.y = dpToPx(appContext, 100); // 向下偏移，更像系统 toast
                windowManager.addView(view, params);

                // 4) 淡入到 targetAlpha
                view.animate()
                        .alpha(clamp(targetAlpha, 0f, 1f))
                        .setDuration(FADE_IN_MS)
                        .setInterpolator(new DecelerateInterpolator())
                        .start();

                // 5) 安排移除（fade-out 后移除）
                removeRunnable = () -> {
                    if (view == null) {
                        removeRunnable = null;
                        return;
                    }
                    try {
                        // 淡出到 0，然后在 endAction 中移除 view
                        view.animate()
                                .alpha(0f)
                                .setDuration(FADE_OUT_MS)
                                .withEndAction(() -> {
                                    removeViewImmediate();
                                })
                                .start();
                    } finally {
                        // removeRunnable 会在动画 end 时清理视图，这里把引用设 null
                        removeRunnable = null;
                    }
                };

                handler.postDelayed(removeRunnable, Math.max(0, durationMs));
            } catch (Exception e) {
                // 如果 addView 抛异常（常见是权限问题），确保状态被清理，不崩溃
                e.printStackTrace();
                view = null;
                windowManager = null;
                removeRunnable = null;
            }
        });
    }

    // 立即（带淡出）关闭
    public static void dismiss() {
        handler.post(() -> {
            if (removeRunnable != null) {
                handler.removeCallbacks(removeRunnable);
                removeRunnable = null;
            }
            if (view != null) {
                try {
                    view.animate()
                            .alpha(0f)
                            .setDuration(FADE_OUT_MS)
                            .withEndAction(() -> removeViewImmediate())
                            .start();
                } catch (Exception e) {
                    // 动画失败时直接移除
                    removeViewImmediate();
                }
            } else {
                removeViewImmediate();
            }
        });
    }

    // 同步移除（安全包裹）
    private static void removeViewImmediate() {
        try {
            if (windowManager != null && view != null) {
                try {
                    windowManager.removeViewImmediate(view);
                } catch (Exception ex) {
                    try { windowManager.removeView(view); } catch (Exception ignore) {}
                }
            }
        } finally {
            view = null;
            windowManager = null;
        }
    }

    // dp 转 px
    private static int dpToPx(Context ctx, float dp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, ctx.getResources().getDisplayMetrics());
    }

    // 限制范围
    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }
}