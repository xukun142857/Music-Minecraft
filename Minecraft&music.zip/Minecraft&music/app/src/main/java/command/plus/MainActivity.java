package command.plus;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import java.io.IOException;
import android.net.Uri;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.List;
import java.util.concurrent.Executors;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.util.List;
import java.util.concurrent.Executors;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import com.google.android.material.appbar.MaterialToolbar;
// 或者


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

   private static final String TAG_HOME = "home";
private static final String TAG_SEARCH = "search";
private static final String KEY_CURRENT_TAG = "current_tag";

private Fragment homeFragment;
private Fragment searchFragment;
private Fragment currentFragment;
private String currentTag; // 记录当前显示的 Tag

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 请自建一个简单的布局，放3个按钮
        
        File noteDir = new File(getExternalFilesDir(null), "note");

if (!noteDir.exists()) {

    copyAssetsFolder(
            this,
            "note",   // assets里的文件夹
            noteDir
    );

}

        
        
        BottomNavigationView bottomNav = findViewById(R.id.bottom_nav);

    if (savedInstanceState == null) {
        // 1. 首次启动：初始化
        homeFragment = new HomeFragment();
        searchFragment = new SearchFragment();
        currentFragment = homeFragment;
        currentTag = TAG_HOME;

        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, homeFragment, TAG_HOME)
                .add(R.id.fragment_container, searchFragment, TAG_SEARCH)
                .hide(searchFragment)
                .commit();
                // 在 commit 之后


    } else {
        // 2. 配置更改后：通过 Tag 找回现有的 Fragment 实例
        homeFragment = getSupportFragmentManager().findFragmentByTag(TAG_HOME);
        searchFragment = getSupportFragmentManager().findFragmentByTag(TAG_SEARCH);
        
        // 恢复之前的状态
        currentTag = savedInstanceState.getString(KEY_CURRENT_TAG);
        currentFragment = getSupportFragmentManager().findFragmentByTag(currentTag);
        getSupportFragmentManager().beginTransaction()
    .show(searchFragment)
    .commitNow();

// 核心：立即把 View 变透明
if (searchFragment.getView() != null) {
    searchFragment.getView().setAlpha(0f);
}

// 延迟一小会儿（确保布局完成）后再隐藏并恢复透明度
new Handler(Looper.getMainLooper()).post(() -> {
    getSupportFragmentManager().beginTransaction()
        .hide(searchFragment)
        .commitNow();
    if (searchFragment.getView() != null) {
        searchFragment.getView().setAlpha(1f); // 恢复，否则下次 show 就是全透明
    }
});
    }
    
    

    bottomNav.setOnItemSelectedListener(item -> {
        Fragment targetFragment = null;
        String targetTag = "";

        if (item.getItemId() == R.id.nav_home) {
            targetFragment = homeFragment;
            targetTag = TAG_HOME;
        } else if (item.getItemId() == R.id.nav_search) {
            targetFragment = searchFragment;
            targetTag = TAG_SEARCH;
        }

        if (targetFragment != null && targetFragment != currentFragment) {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                    .hide(currentFragment)
                    .show(targetFragment)
                    .commit();
            currentFragment = targetFragment;
            currentTag = targetTag;
        }
        return true;
    });
     }
     
     @Override
protected void onSaveInstanceState(@NonNull Bundle outState) {
    super.onSaveInstanceState(outState);
    // 保存当前显示的 Fragment Tag，防止旋转后重置
    outState.putString(KEY_CURRENT_TAG, currentTag);
}
    

    public static void copyAssetsFolder(Context context, String assetFolder, File targetDir) {
        try {
            if (!targetDir.exists()) {
                targetDir.mkdirs();
            }

            String[] files = context.getAssets().list(assetFolder);

            for (String name : files) {
                String assetPath = assetFolder + "/" + name;
                File outFile = new File(targetDir, name);

                String[] subFiles = context.getAssets().list(assetPath);

                if (subFiles.length > 0) {
                    // 是文件夹
                    copyAssetsFolder(context, assetPath, outFile);
                } else {
                    // 是文件
                    copyFile(context, assetPath, outFile);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void copyFile(Context context, String assetPath, File outFile) {
        try {
            InputStream is = context.getAssets().open(assetPath);
            FileOutputStream fos = new FileOutputStream(outFile);

            byte[] buffer = new byte[4096];
            int len;

            while ((len = is.read(buffer)) != -1) {
                fos.write(buffer, 0, len);
            }

            is.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

public static boolean deleteDir(File dir) {
    if (dir != null && dir.isDirectory()) {
        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                deleteDir(child);
            }
        }
    }
    return dir != null && dir.delete();
}
   
}