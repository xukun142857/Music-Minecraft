package command.plus;

import androidx.datastore.preferences.core.Preferences;
import androidx.datastore.preferences.core.PreferencesKeys;

public class Keys {

    // int key（我们当前用这个）
    public static Preferences.Key<Integer> kInt(String id, int index) {
        return PreferencesKeys.intKey(id + "_" + index);
    }
}