package command.plus;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import androidx.datastore.preferences.core.MutablePreferences;
import androidx.datastore.preferences.core.Preferences;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import io.reactivex.rxjava3.schedulers.Schedulers;

public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.VH> {

    private final Context ctx;
    private final List<GroupItem> items;

    public GroupAdapter(Context ctx, List<GroupItem> items) {
        this.ctx = ctx.getApplicationContext();
        this.items = items;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_group, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        GroupItem it = items.get(pos);
        h.title.setText(it.getTitle());

        // 移除旧 watcher（避免重复）
        if (h.w1 != null) h.et1.removeTextChangedListener(h.w1);
        if (h.w2 != null) h.et2.removeTextChangedListener(h.w2);
        if (h.w3 != null) h.et3.removeTextChangedListener(h.w3);

        // 从 DataStore 读取 Integer 并显示（若为 null 则显示默认 int）
        DataStoreManager.get(ctx).readOnce()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(prefs -> {
                    Integer v1 = prefs.get(Keys.kInt(it.getId(), 1));
                    Integer v2 = prefs.get(Keys.kInt(it.getId(), 2));
                    Integer v3 = prefs.get(Keys.kInt(it.getId(), 3));

                    String s1 = v1 != null ? String.valueOf(v1) : String.valueOf(it.getDefault1());
                    String s2 = v2 != null ? String.valueOf(v2) : String.valueOf(it.getDefault2());
                    String s3 = v3 != null ? String.valueOf(v3) : String.valueOf(it.getDefault3());

                    if (!h.et1.getText().toString().equals(s1)) h.et1.setText(s1);
                    if (!h.et2.getText().toString().equals(s2)) h.et2.setText(s2);
                    if (!h.et3.getText().toString().equals(s3)) h.et3.setText(s3);
                }, throwable -> {
                    // 失败：显示默认
                    h.et1.setText(String.valueOf(it.getDefault1()));
                    h.et2.setText(String.valueOf(it.getDefault2()));
                    h.et3.setText(String.valueOf(it.getDefault3()));
                });

        // 绑定保存（每次文本改变即保存为 int，解析失败用默认值）
        h.w1 = new SimpleWatcher(s -> saveIntToDataStore(it.getId(), 1, parseOrDefault(s, it.getDefault1())));
        h.w2 = new SimpleWatcher(s -> saveIntToDataStore(it.getId(), 2, parseOrDefault(s, it.getDefault2())));
        h.w3 = new SimpleWatcher(s -> saveIntToDataStore(it.getId(), 3, parseOrDefault(s, it.getDefault3())));

        h.et1.addTextChangedListener(h.w1);
        h.et2.addTextChangedListener(h.w2);
        h.et3.addTextChangedListener(h.w3);
    }

    private int parseOrDefault(String s, int def) {
        if (s == null) return def;
        s = s.trim();
        if (s.isEmpty()) return def;
        try { return Integer.parseInt(s); } catch (NumberFormatException e) { return def; }
    }

    private void saveIntToDataStore(String id, int index, int value) {
        DataStoreManager.get(ctx).writeAll(prefsIn -> {
            MutablePreferences m = prefsIn.toMutablePreferences();
            m.set(Keys.kInt(id, index), Integer.valueOf(value));
            return m;
        })
        .subscribeOn(Schedulers.io())
        .observeOn(Schedulers.io())
        .subscribe(prefs -> { /* saved */ }, Throwable::printStackTrace);
    }

    @Override
    public int getItemCount() { return items.size(); }

    /** 同步获取所有 int 值（注意：会阻塞调用线程） */
    public List<Map<String, Integer>> getAllInputsSyncInts() {
        List<Map<String, Integer>> out = new ArrayList<>();
        Preferences prefs = DataStoreManager.get(ctx).readOnce().blockingGet();
        for (GroupItem it : items) {
            Map<String, Integer> m = new HashMap<>();
            Integer a = prefs.get(Keys.kInt(it.getId(), 1));
            Integer b = prefs.get(Keys.kInt(it.getId(), 2));
            Integer c = prefs.get(Keys.kInt(it.getId(), 3));
            m.put("v1", a != null ? a : it.getDefault1());
            m.put("v2", b != null ? b : it.getDefault2());
            m.put("v3", c != null ? c : it.getDefault3());
            out.add(m);
        }
        return out;
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView title;
        TextInputEditText et1, et2, et3;
        TextWatcher w1, w2, w3;
        VH(View v) {
            super(v);
            title = v.findViewById(R.id.tvTitle);
            et1 = v.findViewById(R.id.et1);
            et2 = v.findViewById(R.id.et2);
            et3 = v.findViewById(R.id.et3);
        }
    }

    private static class SimpleWatcher implements TextWatcher {
        interface Consumer { void accept(String s); }
        private final Consumer consumer;
        SimpleWatcher(Consumer consumer) { this.consumer = consumer; }
        @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
        @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
        @Override public void afterTextChanged(Editable s) { consumer.accept(s.toString()); }
    }
}