package command.plus;

public class GroupItem {
    private final String id;
    private final String title;
    private final int default1;
    private final int default2;
    private final int default3;

    public GroupItem(String id, String title, int default1, int default2, int default3) {
        this.id = id;
        this.title = title;
        this.default1 = default1;
        this.default2 = default2;
        this.default3 = default3;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public int getDefault1() { return default1; }
    public int getDefault2() { return default2; }
    public int getDefault3() { return default3; }
}