package command.plus;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.os.FileObserver;
import android.os.Handler;
import android.os.Looper;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;
import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.List;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import androidx.datastore.preferences.core.Preferences;
import io.reactivex.rxjava3.core.SingleObserver;
import io.reactivex.rxjava3.disposables.Disposable;
import android.app.AlertDialog;
import io.reactivex.rxjava3.schedulers.Schedulers;
import io.reactivex.rxjava3.android.schedulers.AndroidSchedulers;
import com.google.android.material.appbar.MaterialToolbar;

public class HomeFragment extends Fragment {

    Context context;
    private static final String KEY_VISIBLE_STATE = "visible_state";
    // 0 = none, 1 = known, 2 = link
    private int visibleState = 0;

    private Spinner spinnerSource;
    private LinearLayout layoutKnownOptions;
    private EditText edittextLink;
    private Spinner spinnerKnownItems;
    View view;
    private static DataManager dataManager;
    
private ArrayAdapter<FileItem> knownAdapter;
private List<FileItem> fileList;

private FileObserver musicFolderObserver;
private File targetDir;

private RecyclerView rvMap;
    private GroupAdapter adapter;
    private List<GroupItem> data;
    private Button btnRestoreDefaults;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
                             
                             context = getActivity();
        if (context == null) return null;

        view = inflater.inflate(R.layout.fragment_home, container, false);
        
        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        if (getActivity() instanceof androidx.appcompat.app.AppCompatActivity) {
((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
((AppCompatActivity) getActivity()).getSupportActionBar()
        .setTitle("半自动指令操作");
        }
        
        
        toolbar.setOnMenuItemClickListener(item -> {
    if (item.getItemId() == R.id.action_info) {
        new MaterialAlertDialogBuilder(getActivity())
            .setTitle("说明")
            .setMessage("1.打开悬浮窗后,长按信息窗口可以弹出菜单进行选择指令文件及隐藏悬浮窗等操作\n2.长按'←'可以弹出数字输入框,跳进到索引位置\n3.半自动操作只完成从打开命令方块到关闭命令方块的操作,请放置没有被设置过的命令方块\n4.你可以从开发者模式中的'指针位置'获取坐标\n5.指令音符盒的'乐器及音高'似乎没什么用,你可以不管.'事件值及乐器'这可以应对midi中的特殊事件,如海浪音等,你需要准备与你输入乐器名字相同的wav音效文件到音效目录,可以用'选择音频文件'")
            .setPositiveButton("知道了", null)
            .show();
        return true;
    }
    return false;
});

       Button btnOverlay = view.findViewById(R.id.btn_overlay); // 布局中对应的ID
    Button btnStart = view.findViewById(R.id.btn_start); // 布局中对应的ID
    btnStart.setOnClickListener(v -> {
    dataManager = new DataManager();
    MainAccessibilityService service = MainAccessibilityService.getInstance();
    if (service == null) {
        Toast.makeText(context, "服务未开启，请先开启无障碍", Toast.LENGTH_SHORT).show();
        return;
    }

    if (service.isWindow()) {
        
        service.hideFloatingWindow();
    } else {
        
        try {
                    Object selectedObject = spinnerKnownItems.getSelectedItem();

    // 2. 安全校验
    if (selectedObject instanceof FileItem && visibleState == 1) {
        FileItem selectedItem = (FileItem) selectedObject;
        String path = selectedItem.getFullPath();

        // 3. 判断是否为“无”
        if (path != null && !path.isEmpty()) {
            // 这里就是你要的完整路径
            dataManager.loadFromFile(path);
            //Toast.makeText(getActivity(), "当前选中的路径是: " + path, Toast.LENGTH_SHORT).show();
            //Log.d("Path", "当前选中的路径是: " + path);
            // 执行后续逻辑，如读取文件内容
        } else {
            // 选中的是“无”
            Toast.makeText(getActivity(), "当前未选择有效文件", Toast.LENGTH_SHORT).show();
        }
    } else if (visibleState == 2) {
        dataManager.loadFromFile(edittextLink.getText().toString());
    }
                    
                } catch (Exception e) {
                    Toast.makeText(context, "加载失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
        
        service.showFloatingWindow();
    }
    
if (service != null) {
    service.setWindowStateListener(isShown -> {
        requireActivity().runOnUiThread(() -> {
            btnStart.setText(isShown ? "关闭悬浮窗" : "开启悬浮窗");
            //Toast.makeText(getActivity(), "aaa", Toast.LENGTH_SHORT).show();
        });
    });
    }
});
       
        
        rvMap = view.findViewById(R.id.rvMap);

        data = new ArrayList<>();
        // 示例：你可以用你自己的标题数组和默认值来填充
        data.add(new GroupItem("group_1", "打开命令方块操作点", 1850, 560, 500));
        data.add(new GroupItem("group_2", "点'方块类型'", 840, 540, 100));
        data.add(new GroupItem("group_3", "点连锁", 585, 625, 100));
        data.add(new GroupItem("group_4", "点循环", 585, 715, 100));
        data.add(new GroupItem("group_5", "点'条件'", 840, 795, 100));
        data.add(new GroupItem("group_6", "点条件制约", 840, 765, 100));
        data.add(new GroupItem("group_7", "点'红石控制'", 840, 995, 100));
        data.add(new GroupItem("group_8", "点保持开启", 840, 780, 100));
        data.add(new GroupItem("group_9", "点命令输入框", 1470, 370, 100));
        data.add(new GroupItem("group_10", "点退出", 2250, 160, 50));
        adapter = new GroupAdapter(getActivity(), data);
        rvMap.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvMap.setAdapter(adapter);
        
        btnRestoreDefaults = view.findViewById(R.id.btnRestoreDefaults);
        
        // 点击恢复默认：先弹确认对话框
        btnRestoreDefaults.setOnClickListener(v -> {
            new AlertDialog.Builder(getActivity())
                    .setTitle("恢复默认设置")
                    .setMessage("确认要将所有输入恢复为默认值吗？此操作不可撤销。")
                    .setPositiveButton("确定", (dialog, which) -> resetAllToDefaults())
                    .setNegativeButton("取消", null)
                    .show();
        });
    
       

        // 1. 申请悬浮窗权限
        btnOverlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(context)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getActivity().getPackageName()));
                startActivity(intent);
            } else {
                Toast.makeText(context, "悬浮窗权限已获取", Toast.LENGTH_SHORT).show();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                if (!Environment.isExternalStorageManager()) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                    intent.setData(Uri.parse("package:" + getActivity().getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(context, "存储权限已获取", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Android 10及以下使用旧版权限请求，此处省略 ActivityCompat.requestPermissions...
                Toast.makeText(context, "请确保已授予读写权限", Toast.LENGTH_SHORT).show();
            }
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        });
       
       // 载入选项
       
       spinnerSource = view.findViewById(R.id.spinner_source);
        layoutKnownOptions = view.findViewById(R.id.layout_known_options);
        edittextLink = view.findViewById(R.id.edittext_link);
        spinnerKnownItems = view.findViewById(R.id.spinner_known_items);

        // 设置 spinner 数据（来源选项）
        ArrayAdapter<CharSequence> sourceAdapter = ArrayAdapter.createFromResource(
                context, R.array.source_options, android.R.layout.simple_spinner_item);
        sourceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSource.setAdapter(sourceAdapter);

    // 2. 初始化 List 和 Adapter
    fileList = new ArrayList<>();
    
    // 注意：这里泛型变成了 FileItem
    knownAdapter = new ArrayAdapter<>(
            getActivity(), 
            android.R.layout.simple_spinner_item, 
            fileList
    );
    knownAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    spinnerKnownItems.setAdapter(knownAdapter);

    // 3. 首次加载数据
    initFileMonitoring();
    refreshMusicFiles();
    

    // 4. 设置监听器：当选中某项时获取全路径
    spinnerKnownItems.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            // 获取选中的对象
            FileItem selectedItem = (FileItem) parent.getItemAtPosition(position);
            String fullPath = selectedItem.getFullPath();
            
            // 可以在这里处理路径，例如打印或赋值给变量
            System.out.println("选中路径: " + fullPath);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {
        }
    });

        // 默认选中 "无"（数组第0项）
        spinnerSource.setSelection(0);

        // 恢复旋转前状态（如果有）
        if (savedInstanceState != null) {
            visibleState = savedInstanceState.getInt(KEY_VISIBLE_STATE, 0);
            applyVisibleState();
        }

        // 监听选项变化
        spinnerSource.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // position: 0 = 无, 1 = 从已知中获取, 2 = 从链接中获取
                visibleState = position;
                applyVisibleState();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // 保持 "无"
                visibleState = 0;
                applyVisibleState();
            }
        });

       

        return view;
    }
    
    private void resetAllToDefaults() {
        // 使用你已有的 DataStoreManager.writeAll(Function<Preferences, MutablePreferences>)
        DataStoreManager.get(getActivity()).writeAll(prefsIn -> {
            androidx.datastore.preferences.core.MutablePreferences m = prefsIn.toMutablePreferences();
            // 遍历 data 列表，把默认值写入每个 key
            // 示例：在遍历 data 的地方（保证 data 已初始化）
for (GroupItem it : data) {
    String id = it.getId();
    m.set(Keys.kInt(id, 1), it.getDefault1());
    m.set(Keys.kInt(id, 2), it.getDefault2());
    m.set(Keys.kInt(id, 3), it.getDefault3());
}
            return m;
        })
        .subscribeOn(Schedulers.io())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe(new SingleObserver<Preferences>() {
            @Override
            public void onSubscribe(Disposable d) { /* 可保存 disposable 如需取消 */ }

            @Override
            public void onSuccess(Preferences prefs) {
                // 通知适配器刷新界面（Adapter 的 onBind 会重新从 DataStore 读取显示）
                if (adapter != null) adapter.notifyDataSetChanged();
                //Toast.makeText(MainActivity.this, "已恢复为默认设置", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable e) {
                Log.e("MainActivity", "恢复默认失败", e);
                Toast.makeText(getActivity(), "恢复默认失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
    
    
    private void applyVisibleState() {
        if (visibleState == 0) { // 无
            layoutKnownOptions.setVisibility(View.GONE);
            edittextLink.setVisibility(View.GONE);
        } else if (visibleState == 1) { // 从已知中获取
            layoutKnownOptions.setVisibility(View.VISIBLE);
            edittextLink.setVisibility(View.GONE);
        } else if (visibleState == 2) { // 从链接中获取
            layoutKnownOptions.setVisibility(View.GONE);
            edittextLink.setVisibility(View.VISIBLE);
        }
    }
    
    
    /**
 * 刷新文件列表的方法
 * 你可以在按钮点击事件或 onResume 中调用此方法来实现“及时刷新”
 */
private void refreshMusicFiles() {
    fileList.clear();

    if (targetDir.exists() && targetDir.isDirectory()) {
        File[] files = targetDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));

        if (files != null && files.length > 0) {
            for (File file : files) {
                fileList.add(new FileItem(file));
            }
        } else {
            // 如果没有符合的文件，添加“无”
            fileList.add(new FileItem("无"));
        }
    } else {
        fileList.add(new FileItem("无"));
    }

    knownAdapter.notifyDataSetChanged();
}

/**
 * 必须在 Activity 销毁时停止监听，防止内存泄漏
 */
@Override
public void onDestroy() {
    super.onDestroy();
    if (musicFolderObserver != null) {
        musicFolderObserver.stopWatching();
    }
}

private void initFileMonitoring() {
    targetDir = new File(getActivity().getExternalFilesDir(null), "MusicOutput");
    
    // 如果目录不存在则创建，否则 Observer 无法启动
    if (!targetDir.exists()) {
        targetDir.mkdirs();
    }

    // 1. 定义文件夹监听器
    // 监听：创建、删除、移动（覆盖了文件增加和减少的情况）
    musicFolderObserver = new FileObserver(targetDir.getPath(), 
            FileObserver.CREATE | FileObserver.DELETE | FileObserver.MOVED_TO | FileObserver.MOVED_FROM) {
        @Override
        public void onEvent(int event, String path) {
            // 注意：onEvent 在后台线程运行，刷新 UI 必须回到主线程
            new Handler(Looper.getMainLooper()).post(() -> {
                // 如果改变的是 .txt 文件，或者干脆每次改变都刷新
                refreshMusicFiles();
            });
        }
    };

    // 2. 开始监听
    musicFolderObserver.startWatching();

    // 3. 初始加载一次
    refreshMusicFiles();
}

// --- 辅助内部类 ---
/**
 * 这个类用于同时保存文件对象和定义显示名称
 */
private class FileItem {
    private File file;
    private String displayName; // 用于特殊显示，如“无”

    // 正常文件的构造函数
    public FileItem(File file) {
        this.file = file;
        this.displayName = file.getName();
    }

    // “无文件”状态的构造函数
    public FileItem(String placeholder) {
        this.file = null;
        this.displayName = placeholder;
    }

    public String getFullPath() {
        return file != null ? file.getAbsolutePath() : "";
    }

    @Override
    public String toString() {
        return displayName;
    }
}

public static DataManager getDataManager() {
        return dataManager;
    }
    
    
   
    
}