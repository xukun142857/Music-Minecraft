package command.plus;

import android.util.Log;

import com.leff.midi.MidiFile;
import com.leff.midi.MidiTrack;
import com.leff.midi.event.MidiEvent;
import com.leff.midi.event.NoteOn;
import com.leff.midi.event.ProgramChange;
import com.leff.midi.event.Controller;
import com.leff.midi.event.meta.Tempo;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Locale;

/**
 * 可配置的 McMusicConverter：实例化时通过 Builder 传入参数与文件路径，
 * 提供 convertAndRender(callback) 方法用于执行完整流程并回调进度/完成/错误。
 */
public class McMusicConverter {
    private static final String TAG = "McConverter";

    // ====== 可配置参数（每个实例独有） ======
    private double mcTick = 0.05;
    private int maxSimulNotes = 5;
    private int pitchPrecision = 4;
    private double globalPitchFactor = 0.5;
    private int volumeMode = 0; // "MATCH" or "FIXED"
    private int simplificationLevel = 0;

    private Map<Integer, String> sfxMapping;
    private Map<String, Integer> instBases;

    // 输入/输出文件（可由外部设置）
    private File midiFile;
    private File sampleFolder;
    private File outputWav;
    private File outputTxt;

    // ====== 回调接口 ======
    public interface Callback {
        void onProgress(String message, int percent); // percent 0..100, -1 表示未知
        void onComplete(File wavFile, File txtFile);
        void onError(Exception e);
    }

    // ====== 构造器（私有）+ Builder ======
    private McMusicConverter() {
        initDefaultMappings();
    }

    private void initDefaultMappings() {
        // 默认 SFX 映射
        sfxMapping = new HashMap<>();
        sfxMapping.put(122, "seashore");
        sfxMapping.put(127, "gunshot");

        // 默认 instrument bases
        instBases = new HashMap<>();
        instBases.put("harp", 54);
        instBases.put("bass", 30);
        instBases.put("pling", 78);
        instBases.put("bell", 78);
        instBases.put("flute", 66);
        instBases.put("guitar", 42);
        instBases.put("chime", 78);
        instBases.put("xylophone", 78);
        instBases.put("iron_xylophone", 54);
        instBases.put("cow_bell", 66);
        instBases.put("didgeridoo", 30);
        instBases.put("bit", 54);
        instBases.put("banjo", 54);
        instBases.put("bd", 0);
        instBases.put("snare", 0);
    }

    public static class Builder {
        private final McMusicConverter inst = new McMusicConverter();

        public Builder setMcTick(double v) { inst.mcTick = v; return this; }
        public Builder setMaxSimulNotes(int v) { inst.maxSimulNotes = v; return this; }
        public Builder setPitchPrecision(int v) { inst.pitchPrecision = v; return this; }
        public Builder setGlobalPitchFactor(double v) { inst.globalPitchFactor = v; return this; }
        public Builder setVolumeMode(int v) { inst.volumeMode = v; return this; }
        public Builder setSimplificationLevel(int v) { inst.simplificationLevel = v; return this; }

        public Builder setMidiFile(File f) { inst.midiFile = f; return this; }
        public Builder setSampleFolder(File f) { inst.sampleFolder = f; return this; }
        public Builder setOutputWav(File f) { inst.outputWav = f; return this; }
        public Builder setOutputTxt(File f) { inst.outputTxt = f; return this; }

        public Builder setSfxMapping(Map<Integer, String> map) { inst.sfxMapping = map; return this; }
        public Builder setInstBases(Map<String, Integer> map) { inst.instBases = map; return this; }

        public McMusicConverter build() { return inst; }
    }

    // =========== 数据结构（保留） ===========
    public static class McNote {
        public double time;
        public int tick;
        public String inst;
        public int midiNote;
        public int velocity;
        public double volume;
        public double pitch;
        public boolean isSfx;
        public boolean isDrum;

        public McNote copy() {
            McNote n = new McNote();
            n.time = time; n.tick = tick; n.inst = inst;
            n.midiNote = midiNote; n.velocity = velocity;
            n.volume = volume; n.pitch = pitch;
            n.isSfx = isSfx; n.isDrum = isDrum;
            return n;
        }
    }

    // =========== 主要外部方法 ===========
    /**
     * 执行完整流程：parse -> process -> simplify -> render -> saveText
     * 回调会在关键节点被调用（在调用线程内执行 — 若在 UI 线程请改为异步调用）。
     */
    public void convertAndRender(Callback callback) {
        if (callback == null) callback = new Callback() {
            @Override public void onProgress(String message, int percent) {}
            @Override public void onComplete(File wavFile, File txtFile) {}
            @Override public void onError(Exception e) { e.printStackTrace(); }
        };

        try {
            callback.onProgress("Parsing MIDI...", 5);
            if (midiFile == null) throw new IllegalArgumentException("midiFile is not set");
            List<McNote> parsed = parseMidi(midiFile);
            callback.onProgress("Processing notes...", 25);
            List<McNote> processed = process(parsed);
            callback.onProgress("Simplifying notes...", 45);
            List<McNote> simplified = simplify(processed);
            callback.onProgress("Rendering audio...", 70);
            if (outputWav == null) throw new IllegalArgumentException("outputWav is not set");
            renderAudio(simplified, sampleFolder, outputWav);
            callback.onProgress("Saving text...", 95);
            String input = saveTextToString(simplified);
            if (outputTxt != null) saveCommandText(input, outputTxt);
            callback.onProgress("Done", 100);
            callback.onComplete(outputWav, outputTxt);
        } catch (Exception e) {
            callback.onError(e);
        }
    }

    // =========== 1) MIDI 解析（实例方法，使用实例参数/映射） ===========
    public List<McNote> parseMidi(File midiFile) throws IOException {
        List<McNote> rawEvents = new ArrayList<>();
        try (InputStream is = new FileInputStream(midiFile)) {
            MidiFile midi = new MidiFile(is);
            ArrayList<MidiEvent> allEvents = new ArrayList<>();
            for (MidiTrack track : midi.getTracks()) {
                allEvents.addAll(track.getEvents());
            }
            Collections.sort(allEvents);

            int resolution = midi.getResolution();
            long lastTick = 0;
            double currentTimeSec = 0.0;
            double secondsPerTick = 500000.0 / 1_000_000.0 / (double) resolution;

            int[] channelProgram = new int[16];
            int[] channelBankMsb = new int[16];
            int[] channelBankLsb = new int[16];
            for (int i = 0; i < 16; i++) { channelProgram[i] = 0; channelBankMsb[i] = 0; channelBankLsb[i] = 0; }

            for (MidiEvent E : allEvents) {
                long tick = E.getTick();
                long delta = tick - lastTick;
                if (delta != 0) {
                    currentTimeSec += delta * secondsPerTick;
                    lastTick = tick;
                }

                if (E instanceof Tempo) {
                    Tempo t = (Tempo) E;
                    secondsPerTick = t.getMpqn() / 1_000_000.0 / (double) resolution;
                    continue;
                }
                if (E instanceof ProgramChange) {
                    ProgramChange pc = (ProgramChange) E;
                    int ch = pc.getChannel() & 0x0F;
                    int prg = pc.getProgramNumber() & 0x7F;
                    channelProgram[ch] = prg;
                    continue;
                }
                if (E instanceof Controller) {
                    Controller c = (Controller) E;
                    int ch = c.getChannel() & 0x0F;
                    int controller = c.getControllerType();
                    int value = c.getValue();
                    if (controller == 0) channelBankMsb[ch] = value & 0x7F;
                    else if (controller == 32) channelBankLsb[ch] = value & 0x7F;
                    continue;
                }
                if (E instanceof NoteOn) {
                    NoteOn noteOn = (NoteOn) E;
                    if (noteOn.getVelocity() > 0) {
                        int note = noteOn.getNoteValue();
                        int velocity = noteOn.getVelocity();
                        int channel = noteOn.getChannel() & 0x0F;
                        int program = channelProgram[channel];
                        int bankMsb = channelBankMsb[channel];
                        int programWithBank = (bankMsb << 8) | program;

                        boolean isSfx = (sfxMapping != null && (sfxMapping.containsKey(programWithBank) || sfxMapping.containsKey(program)));
                        String inst;
                        if (isSfx) {
                            if (sfxMapping.containsKey(programWithBank)) inst = sfxMapping.get(programWithBank);
                            else inst = sfxMapping.get(program);
                        } else {
                            inst = mapInstrument(channel, program);
                        }

                        McNote mcNote = new McNote();
                        mcNote.time = currentTimeSec;
                        mcNote.midiNote = note;
                        mcNote.velocity = velocity;
                        mcNote.inst = inst;
                        mcNote.isSfx = isSfx;
                        mcNote.isDrum = (channel == 9);
                        rawEvents.add(mcNote);
                    }
                }
            }
        }
        return rawEvents;
    }

    private String mapInstrument(int ch, int prg) {
        if (ch == 9) return (prg < 36) ? "bd" : "snare";
        if (prg < 8) return "harp";
        if (prg >= 8 && prg < 16) return "pling";
        if (prg >= 24 && prg < 32) return "guitar";
        if (prg >= 32 && prg < 40) return "bass";
        if (prg >= 56 && prg < 64) return "pling";
        if (prg >= 64 && prg < 80) return "flute";
        if (prg >= 113 && prg < 120) return "bell";
        return "harp";
    }

    // =========== 2) Processor（实例方法，使用实例参数） ===========
    public List<McNote> process(List<McNote> events) {
        List<McNote> processed = new ArrayList<>();
        for (McNote e : events) {
            McNote finalE = e.copy();
            finalE.tick = (int) Math.round(e.time / mcTick);
            if (volumeMode == 0) {
                finalE.volume = Math.round((e.velocity / 127.0) * 1000.0) / 1000.0;
            } else {
                finalE.volume = 1.0;
            }
            if (e.isSfx || e.isDrum) {
                finalE.pitch = 1.0 * globalPitchFactor;
            } else {
                int base = instBases.containsKey(e.inst) ? instBases.get(e.inst) : 54;
                double rawPitch = Math.pow(2, (e.midiNote - base) / 12.0);
                double p = rawPitch * globalPitchFactor;
                double scale = Math.pow(10, pitchPrecision);
                finalE.pitch = Math.round(p * scale) / scale;
            }
            processed.add(finalE);
        }
        return processed;
    }

    public List<McNote> simplify(List<McNote> processed) {
        if (simplificationLevel == 0) return hardLimit(processed);

        Map<Integer, List<McNote>> tickMap = new TreeMap<>();
        for (McNote n : processed) {
            if (!tickMap.containsKey(n.tick)) tickMap.put(n.tick, new ArrayList<>());
            tickMap.get(n.tick).add(n);
        }

        double volThreshold = simplificationLevel * 0.05;
        int maxCount = Math.max(1, maxSimulNotes - (simplificationLevel * 3));
        List<McNote> finalEvents = new ArrayList<>();

        for (List<McNote> notes : tickMap.values()) {
            Collections.sort(notes, (o1, o2) -> Double.compare(o2.volume, o1.volume));
            List<McNote> kept = new ArrayList<>();
            for (int i = 0; i < notes.size(); i++) {
                if (i == 0) { kept.add(notes.get(i)); continue; }
                if (notes.get(i).volume >= volThreshold && kept.size() < maxCount) {
                    kept.add(notes.get(i));
                }
            }
            finalEvents.addAll(kept);
        }
        return finalEvents;
    }

    private List<McNote> hardLimit(List<McNote> notes) {
        Map<Integer, List<McNote>> tickMap = new TreeMap<>();
        for (McNote n : notes) {
            if (!tickMap.containsKey(n.tick)) tickMap.put(n.tick, new ArrayList<>());
            tickMap.get(n.tick).add(n);
        }
        List<McNote> finalEvents = new ArrayList<>();
        for (List<McNote> group : tickMap.values()) {
            Collections.sort(group, (o1, o2) -> Double.compare(o2.volume, o1.volume));
            if (group.size() > maxSimulNotes) {
                finalEvents.addAll(group.subList(0, maxSimulNotes));
            } else {
                finalEvents.addAll(group);
            }
        }
        Collections.sort(finalEvents, (o1, o2) -> Integer.compare(o1.tick, o2.tick));
        return finalEvents;
    }

    // =========== 3) Audio rendering（使用实例的 sampleFolder） ===========
    private static class WavSample {
        float[] monoData;
        int sampleRate;
        int channels;
        int bitsPerSample;
        public WavSample(float[] d, int sr, int ch, int bps) { monoData = d; sampleRate = sr; channels = ch; bitsPerSample = bps; }
    }

    private static class AudioBuffer {
        float[] data;
        int sampleRate;
        public AudioBuffer(int size, int sampleRate) { this.data = new float[size]; this.sampleRate = sampleRate; }
    }

    private WavSample loadWavSampleDetailed(File file) {
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] header12 = new byte[12];
            if (fis.read(header12) != 12) return new WavSample(new float[0], 44100, 1, 16);

            int channels = 1;
            int sampleRate = 44100;
            int bitsPerSample = 16;
            int dataSize = 0;

            byte[] chunkHeader = new byte[8];
            while (fis.read(chunkHeader) == 8) {
                String chunkId = new String(chunkHeader, 0, 4, "US-ASCII");
                int chunkSize = ((chunkHeader[4] & 0xff)) |
                                ((chunkHeader[5] & 0xff) << 8) |
                                ((chunkHeader[6] & 0xff) << 16) |
                                ((chunkHeader[7] & 0xff) << 24);
                if ("fmt ".equals(chunkId)) {
                    byte[] fmt = new byte[chunkSize];
                    fis.read(fmt);
                    int audioFormat = (fmt[0] & 0xff) | ((fmt[1] & 0xff) << 8);
                    channels = fmt[2] & 0xff;
                    sampleRate = (fmt[4] & 0xff) | ((fmt[5] & 0xff) << 8) | ((fmt[6] & 0xff) << 16) | ((fmt[7] & 0xff) << 24);
                    bitsPerSample = (fmt[14] & 0xff) | ((fmt[15] & 0xff) << 8);
                } else if ("data".equals(chunkId)) {
                    dataSize = chunkSize;
                    byte[] data = new byte[dataSize];
                    int read = 0;
                    while (read < dataSize) {
                        int r = fis.read(data, read, dataSize - read);
                        if (r < 0) break;
                        read += r;
                    }
                    int bytesPerSample = bitsPerSample / 8;
                    int frameCount = dataSize / (bytesPerSample * channels);
                    float[] mono = new float[frameCount];
                    ByteBuffer bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
                    if (bitsPerSample == 16) {
                        for (int i = 0; i < frameCount; i++) {
                            int acc = 0;
                            for (int ch = 0; ch < channels; ch++) {
                                short s = bb.getShort();
                                acc += s;
                            }
                            float avg = (float) acc / (channels * 32768.0f);
                            mono[i] = Math.max(-1.0f, Math.min(1.0f, avg));
                        }
                    } else if (bitsPerSample == 8) {
                        for (int i = 0; i < frameCount; i++) {
                            int acc = 0;
                            for (int ch = 0; ch < channels; ch++) {
                                int u = bb.get() & 0xff;
                                int s = u - 128;
                                acc += s;
                            }
                            float avg = (float) acc / (channels * 128.0f);
                            mono[i] = Math.max(-1.0f, Math.min(1.0f, avg));
                        }
                    } else {
                        return new WavSample(new float[0], sampleRate, channels, bitsPerSample);
                    }
                    return new WavSample(mono, sampleRate, channels, bitsPerSample);
                } else {
                    long skipped = 0;
                    while (skipped < chunkSize) {
                        long s = fis.skip(chunkSize - skipped);
                        if (s <= 0) break;
                        skipped += s;
                    }
                }
            }
            return new WavSample(new float[0], sampleRate, channels, bitsPerSample);
        } catch (Exception e) {
            Log.e(TAG, "Failed to load sample: " + file.getName(), e);
            return new WavSample(new float[0], 44100, 1, 16);
        }
    }

    private static float[] resampleLinear(float[] src, int srcRate, int targetRate) {
        if (srcRate == targetRate) return src;
        double ratio = (double) srcRate / (double) targetRate;
        int targetLen = (int) Math.round(src.length / ratio);
        if (targetLen <= 0) return new float[0];
        float[] out = new float[targetLen];
        for (int i = 0; i < targetLen; i++) {
            double srcPos = i * ratio;
            int i0 = (int) Math.floor(srcPos);
            int i1 = Math.min(i0 + 1, src.length - 1);
            double frac = srcPos - i0;
            float v0 = src[i0];
            float v1 = src[i1];
            out[i] = (float) (v0 * (1.0 - frac) + v1 * frac);
        }
        return out;
    }

    public void renderAudio(List<McNote> events, File sampleFolder, File outputWav) {
        final int targetRate = 44100;
        Map<String, float[]> samples = new HashMap<>();

        if (sampleFolder != null && sampleFolder.exists() && sampleFolder.isDirectory()) {
            File[] files = sampleFolder.listFiles();
            if (files != null) {
                for (File f : files) {
                    String name = f.getName();
                    if (!(name.endsWith(".wav") || name.endsWith(".WAV"))) continue;
                    String key = name.replaceAll("(?i)\\.wav$", "");
                    WavSample ws = loadWavSampleDetailed(f);
                    if (ws.monoData.length == 0) continue;
                    float[] s = ws.monoData;
                    if (ws.sampleRate != targetRate) s = resampleLinear(s, ws.sampleRate, targetRate);
                    samples.put(key, s);
                }
            }
        }
        if (samples.isEmpty()) {
            Log.w(TAG, "No samples loaded; abort render.");
            return;
        }

        double maxTime = 0;
        for (McNote e : events) if (e.time > maxTime) maxTime = e.time;
        int totalSamples = (int) ((maxTime + 4.0) * targetRate);
        float[] mixBuffer = new float[totalSamples];

        int attackMs = 6;
        int releaseMs = 12;
        int minAttack = Math.max(1, (int) (targetRate * attackMs / 1000.0));
        int minRelease = Math.max(1, (int) (targetRate * releaseMs / 1000.0));

        for (McNote e : events) {
            if (!samples.containsKey(e.inst)) continue;
            float[] original = samples.get(e.inst);
            if (original.length == 0) continue;

            double pitch = Math.max(0.01, Math.min(16.0, e.pitch));
            int targetLen = (int) (original.length / pitch);
            if (targetLen <= 0) continue;

            int startIdx = (int) (e.time * targetRate);
            if (startIdx >= totalSamples) continue;

            for (int i = 0; i < targetLen; i++) {
                int outIdx = startIdx + i;
                if (outIdx >= totalSamples) break;
                double srcPos = i * pitch;
                int idx0 = (int) Math.floor(srcPos);
                int idx1 = Math.min(idx0 + 1, original.length - 1);
                double frac = srcPos - idx0;
                float val = (float) (original[idx0] * (1.0 - frac) + original[idx1] * frac);

                int relPos = i;
                float env = 1.0f;
                if (relPos < minAttack) env = (float) relPos / (float) minAttack;
                else if (i > targetLen - minRelease) {
                    int tailPos = i - (targetLen - minRelease);
                    env = 1.0f - (float) tailPos / (float) minRelease;
                }
                float gain = (float) e.volume;
                mixBuffer[outIdx] += val * gain * env;
            }
        }

        float peak = 0f;
        for (float v : mixBuffer) {
            if (Float.isNaN(v)) v = 0f;
            peak = Math.max(peak, Math.abs(v));
        }
        if (peak > 0.99f) {
            float scale = 0.99f / peak;
            for (int i = 0; i < mixBuffer.length; i++) mixBuffer[i] *= scale;
        }

        writeWavMono(outputWav, mixBuffer, targetRate);
        Log.d(TAG, "Render finished.");
    }

    private void writeWavMono(File file, float[] data, int sampleRate) {
        try (FileOutputStream fos = new FileOutputStream(file)) {
            int channels = 1;
            int bitsPerSample = 16;
            int byteRate = sampleRate * channels * bitsPerSample / 8;
            int blockAlign = channels * bitsPerSample / 8;
            int subchunk2Size = data.length * channels * bitsPerSample / 8;
            int chunkSize = 36 + subchunk2Size;

            byte[] header = new byte[44];
            header[0] = 'R'; header[1] = 'I'; header[2] = 'F'; header[3] = 'F';
            header[4] = (byte) (chunkSize & 0xff);
            header[5] = (byte) ((chunkSize >> 8) & 0xff);
            header[6] = (byte) ((chunkSize >> 16) & 0xff);
            header[7] = (byte) ((chunkSize >> 24) & 0xff);
            header[8] = 'W'; header[9] = 'A'; header[10] = 'V'; header[11] = 'E';
            header[12] = 'f'; header[13] = 'm'; header[14] = 't'; header[15] = ' ';
            header[16] = 16; header[17] = 0; header[18] = 0; header[19] = 0;
            header[20] = 1; header[21] = 0;
            header[22] = (byte) channels; header[23] = 0;
            header[24] = (byte) (sampleRate & 0xff);
            header[25] = (byte) ((sampleRate >> 8) & 0xff);
            header[26] = (byte) ((sampleRate >> 16) & 0xff);
            header[27] = (byte) ((sampleRate >> 24) & 0xff);
            header[28] = (byte) (byteRate & 0xff);
            header[29] = (byte) ((byteRate >> 8) & 0xff);
            header[30] = (byte) ((byteRate >> 16) & 0xff);
            header[31] = (byte) ((byteRate >> 24) & 0xff);
            header[32] = (byte) (blockAlign & 0xff);
            header[33] = 0;
            header[34] = (byte) bitsPerSample;
            header[35] = 0;
            header[36] = 'd'; header[37] = 'a'; header[38] = 't'; header[39] = 'a';
            header[40] = (byte) (subchunk2Size & 0xff);
            header[41] = (byte) ((subchunk2Size >> 8) & 0xff);
            header[42] = (byte) ((subchunk2Size >> 16) & 0xff);
            header[43] = (byte) ((subchunk2Size >> 24) & 0xff);

            fos.write(header, 0, 44);

            byte[] pcm = new byte[data.length * 2];
            int idx = 0;
            for (float f : data) {
                float clamped = Math.max(-1.0f, Math.min(1.0f, f));
                short s = (short) (clamped * 32767);
                pcm[idx++] = (byte) (s & 0xff);
                pcm[idx++] = (byte) ((s >> 8) & 0xff);
            }
            fos.write(pcm);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // =========== 4) 文本导出 ===========
//    public void saveText(List<McNote> events, File outFile) {
//        try (FileWriter fw = new FileWriter(outFile)) {
//            fw.write("\"\"\"\nPitch Factor: " + globalPitchFactor + " | Vol Mode: " + volumeMode + "\n\"\"\"\n");
//            for (McNote e : events) {
//                String line = String.format(Locale.US, "%d %s %.3f %.4f\n", e.tick, e.inst, e.volume, e.pitch);
//                fw.write(line);
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

public String saveTextToString(List<McNote> events) {
    StringBuilder sb = new StringBuilder();
    sb.append("\"\"\"\n")
      .append("Pitch Factor: ").append(globalPitchFactor)
      .append(" | Vol Mode: ").append(volumeMode)
      .append("\n\"\"\"\n");
    
    for (McNote e : events) {
        String line = String.format(Locale.US, "%d %s %.3f %.4f%n", 
            e.tick, e.inst, e.volume, e.pitch);
        sb.append(line);
    }
    
    return sb.toString();
}
    
    public void saveCommandText(String input, File outFile)  {
        MinecraftMusicConverter conv = new MinecraftMusicConverter.Builder()
                .setMode(0)
                .setScoreboardName("t")
                .setStartOffset(0)
                .setEnableStacking(true)
                .setMaxChars(0)
                .setInputString(input)
                .build();

        // 若要写入文件:
        conv.convertToFile(outFile);
    }

    // ======== getter / setter（如果你需要运行时修改） ========
    public void setMidiFile(File midiFile) { this.midiFile = midiFile; }
    public void setSampleFolder(File sampleFolder) { this.sampleFolder = sampleFolder; }
    public void setOutputWav(File outputWav) { this.outputWav = outputWav; }
    public void setOutputTxt(File outputTxt) { this.outputTxt = outputTxt; }

    public void setGlobalPitchFactor(double p) { this.globalPitchFactor = p; }
    public void setMcTick(double t) { this.mcTick = t; }
    public void setVolumeMode(int m) { this.volumeMode = m; }
    public void setMaxSimulNotes(int n) { this.maxSimulNotes = n; }
    public void setSimplificationLevel(int l) { this.simplificationLevel = l; }

}