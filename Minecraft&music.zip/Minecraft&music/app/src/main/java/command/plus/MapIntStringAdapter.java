package command.plus;

import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MapIntStringAdapter extends RecyclerView.Adapter<MapIntStringAdapter.VH> {
    public static class Entry{
        public int key;
        public String value;
        public Entry(int k, String v){ this.key = k; this.value = v; }
    }

    private final List<Entry> items;
    private final LayoutInflater inflater;
    private Runnable onDataChanged;

    public MapIntStringAdapter(Context ctx, List<Entry> items){
        this.items = items == null ? new ArrayList<>() : items;
        this.inflater = LayoutInflater.from(ctx);
    }

    public void setOnDataChanged(Runnable r){ this.onDataChanged = r; }
    private void notifyChanged(){ if (onDataChanged != null) onDataChanged.run(); }

    public void addItem(Entry e){ items.add(e); notifyItemInserted(items.size()-1); notifyChanged(); }
    public void removeAt(int pos){ if (pos>=0 && pos<items.size()){ items.remove(pos); notifyItemRemoved(pos); notifyChanged(); } }
    public void clear(){ items.clear(); notifyDataSetChanged(); notifyChanged(); }
    public List<Entry> getItems(){ return items; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = inflater.inflate(R.layout.item_map_int_string, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH holder, int position) {
        Entry e = items.get(position);
        if (holder.keyWatcher != null) holder.etKey.removeTextChangedListener(holder.keyWatcher);
        if (holder.valueWatcher != null) holder.etValue.removeTextChangedListener(holder.valueWatcher);

        holder.etKey.setText(String.valueOf(e.key));
        holder.etValue.setText(e.value);

        holder.keyWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override
            public void afterTextChanged(Editable s) {
                try { e.key = Integer.parseInt(s.toString()); } catch (Exception ex){ e.key = 0; }
                notifyChanged();
            }
        };
        holder.etKey.addTextChangedListener(holder.keyWatcher);

        holder.valueWatcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override
            public void afterTextChanged(Editable s) {
                e.value = s.toString();
                notifyChanged();
            }
        };
        holder.etValue.addTextChangedListener(holder.valueWatcher);

        holder.btnDelete.setOnClickListener(v -> removeAt(holder.getAdapterPosition()));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder{
        EditText etKey, etValue;
        ImageButton btnDelete;
        TextWatcher keyWatcher, valueWatcher;
        VH(@NonNull View v){
            super(v);
            etKey = v.findViewById(R.id.etKey);
            etValue = v.findViewById(R.id.etValue);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}