package command.plus

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.* 
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.DisposableEffect

import androidx.compose.material.icons.filled.ArrowBack

import android.content.SharedPreferences
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

// --- 数据模型 ---
data class InstrumentDef(
    var channels: List<Int>,
    var events: List<Int>,
    var name: String,
    var basePitch: Int,
    var isDrum: Boolean
)

data class InstrumentItem(
    val id: Long = System.nanoTime(),
    val def: InstrumentDef
)

@Composable
fun musicCommand(onBack: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        SearchScreen(onBack = onBack)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val sp = remember { context.getSharedPreferences("search_prefs", Context.MODE_PRIVATE) }
    var showResetDialog by remember { mutableStateOf(false) }

    // --- 状态管理 ---
    var input1 by remember { mutableStateOf(sp.getString("input1", "input.mid") ?: "input.mid") }
    var outType by remember { mutableStateOf(sp.getInt("outType", 0)) }
    var mode by remember { mutableStateOf(sp.getInt("mode", 0)) }
    var extPath by remember { mutableStateOf(sp.getString("extPath", "output") ?: "output") }
    var stackEnabled by remember { mutableStateOf(sp.getBoolean("stack", true)) }
    var params by remember {
        mutableStateOf(List(9) { i -> sp.getString("p${i + 1}", getDefaultParam(i)) ?: getDefaultParam(i) })
    }
    val channelsTextMap = remember { mutableStateMapOf<Long, String>() }
val eventsTextMap = remember { mutableStateMapOf<Long, String>() }
    var instrumentList by remember { mutableStateOf(loadInstrumentMap(sp)) }

    // --- 核心优化：实时自动保存 ---
    // 监听所有状态变量，一旦改变就执行保存逻辑
    LaunchedEffect(input1, outType, mode, extPath, stackEnabled, params, instrumentList) {
        // 这里的逻辑会在状态改变后稍作等待，防止输入过快导致的频繁写入
        delay(300) 
        sp.edit().apply {
            putString("input1", input1)
            putInt("outType", outType)
            putInt("mode", mode)
           
            putString("extPath", extPath)
            putBoolean("stack", stackEnabled)
            params.forEachIndexed { i, value -> putString("p${i + 1}", value) }
            
            
            apply()
        }
        saveInstrumentMap(sp, instrumentList)
    }

    // 播放器状态
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(0) }
    var totalDuration by remember { mutableStateOf(0) }
    var wavName by remember { mutableStateOf("本地 WAV") }
    var isUserSeeking by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }

    // 保存设置的函数
    val saveAllPrefs = {
        sp.edit().apply {
            putString("input1", input1)
            putInt("outType", outType)
            putInt("mode", mode)
           
            putString("extPath", extPath)
            putBoolean("stack", stackEnabled)
            params.forEachIndexed { i, value -> putString("p${i + 1}", value) }
            
           
            apply()
        }
        saveInstrumentMap(sp,instrumentList)
    }

    // 恢复默认的函数
    val restoreDefaults = {
        input1 = "input.mid"
        params = List(9) { i -> getDefaultParam(i) }
        defaultInstrumentMap()
        saveAllPrefs()
        Toast.makeText(context, "已恢复默认设置", Toast.LENGTH_SHORT).show()
    }

    // --- 播放器进度更新循环 ---
    LaunchedEffect(isPlaying, isUserSeeking) {
        while (isPlaying && !isUserSeeking) {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    currentPosition = it.currentPosition
                }
            }
            delay(500)
        }
    }

    // 资源释放
    DisposableEffect(Unit) {
        onDispose { mediaPlayer?.release() }
    }
    
    val lifecycleOwner = LocalLifecycleOwner.current

// 监听生命周期：进入后台时暂停
DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
        if (event == Lifecycle.Event.ON_PAUSE) {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                    isPlaying = false
                }
            }
        }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
        lifecycleOwner.lifecycle.removeObserver(observer)
    }
}

    // --- 文件选取器 ---
    val pickWavLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            coroutineScope.launch(Dispatchers.IO) {
                val name = queryName(context, it) ?: "temp.wav"
                if (!name.endsWith(".wav", true)) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "仅限 WAV 文件", Toast.LENGTH_SHORT).show() }
                    return@launch
                }
                val targetDir = File(context.getExternalFilesDir(null), "note")
                targetDir.mkdirs()
                val targetFile = File(targetDir, name)
                try {
                    context.contentResolver.openInputStream(it)?.use { input ->
                        FileOutputStream(targetFile).use { output -> input.copyTo(output) }
                    }
                    withContext(Dispatchers.Main) { Toast.makeText(context, "导入成功", Toast.LENGTH_SHORT).show() }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "导入失败: ${e.message}", Toast.LENGTH_SHORT).show() }
                }
            }
        }
    }

    Scaffold(
    topBar = {
        // 使用 Column 将标题栏和下方的返回条组合在一起
        Column {
            TopAppBar(
                title = { Text("指令音符盒") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
            
            // 标题栏下方的自定义小长条
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant, // 设置长条背景色
                modifier = Modifier
                .fillMaxWidth()
                .height(35.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onBack() }) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                    // 如果长条里还需要文字，可以加在这里
                    Text("返回主页", style = MaterialTheme.typography.labelMedium)
                    // Text("返回", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 生成按钮
            Button(
                onClick = {
                    saveAllPrefs()
                    isGenerating = true
                    // 在协程中执行生成任务
                    coroutineScope.launch(Dispatchers.IO) {
                        try {
                            val inputMidi = File(input1)
                            val outFolder = if (outType == 1) File(extPath) else File(context.getExternalFilesDir(null), "MusicOutput")
                            outFolder.mkdirs()

                            // 注意：这里假设你的 McMusicConverter 可以在协程中同步或通过回调运行
                            // 为了将其适配进协程，我们用回调试配
                            val converter = McMusicConverter.Builder()
                                .setMidiFile(inputMidi)
                                .setSampleFolder(File(context.getExternalFilesDir(null), "note"))
                                .setOutputWav(File(outFolder, "${inputMidi.nameWithoutExtension}.wav"))
                                .setOutputTxt(File(outFolder, "${inputMidi.nameWithoutExtension}.txt"))
                                .setMcTick(params[0].toDoubleOrNull() ?: 0.05)
                                .setMaxSimulNotes(params[1].toIntOrNull() ?: 5)
                                .setVolumeMode(mode)
                                .setInstrumentMappings(
    instrumentList.map {
        McMusicConverter.InstrumentDef(
            it.def.channels,
            it.def.events,
            it.def.name,
            it.def.basePitch,
            it.def.isDrum
        )
    }.toMutableList()
)
                                .setProcessTracksIndependently(0)
                                .setEnableStacking(stackEnabled)
                                .setScoreboardName(params[5] ?: "t")
                                .setStartOffset(params[7].toIntOrNull() ?: 0)
                                .setEnableStacking(stackEnabled)
                                .setMaxChars(params[6].toIntOrNull() ?: 10000)
                                .setForBiddenScores(java.util.HashSet(parseIntList(params[8])))
                                .build()

                            converter.convertAndRender(object : McMusicConverter.Callback {
                                override fun onProgress(msg: String?, p: Int) {}
                                override fun onComplete(wav: File, txt: File) {
                                    coroutineScope.launch(Dispatchers.Main) {
                                        isGenerating = false
                                        wavName = wav.name
                                        
                                        isPlaying = false
                                        currentPosition = 0
                                        totalDuration = 0                                   
                                        mediaPlayer?.stop()
                                        
                                        // 初始化播放器
                                        mediaPlayer?.release()
                                        mediaPlayer = MediaPlayer().apply {
                                            setDataSource(wav.absolutePath)
                                            setOnPreparedListener { mp ->
                                                totalDuration = mp.duration
                                            }
                                            setOnCompletionListener {
                                                isPlaying = false
                                                currentPosition = 0
                                            }
                                            prepareAsync()
                                        }
                                        Toast.makeText(context, "生成成功", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                override fun onError(e: Exception) {
                                    coroutineScope.launch(Dispatchers.Main) {
                                        isGenerating = false
                                        Toast.makeText(context, "失败: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                isGenerating = false
                                Toast.makeText(context, "错误: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isGenerating
            ) {
                Text(if (isGenerating) "正在生成..." else "生成", fontSize = 16.sp)
            }

            // 试听卡片
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_launcher), // 替换为你的 ic_launcher
                            contentDescription = "Album Art",
                            modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)).background(Color.LightGray)
                        )
                        Column(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                            Text("Wav音频试听", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text(wavName, fontSize = 14.sp, color = Color.Gray)
                        }
                        FilledIconButton(
                            onClick = {
                                mediaPlayer?.let {
                                    if (it.isPlaying) {
                                        it.pause()
                                        isPlaying = false
                                    } else {
                                        it.start()
                                        isPlaying = true
                                    }
                                }
                            },
                            enabled = mediaPlayer != null
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                                ),
                                contentDescription = "Play/Pause"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(currentPosition), fontSize = 12.sp)
                        Slider(
                            value = if (totalDuration > 0) currentPosition.toFloat() else 0f,
                            onValueChange = {
                                isUserSeeking = true
                                currentPosition = it.toInt()
                            },
                            onValueChangeFinished = {
                                isUserSeeking = false
                                mediaPlayer?.seekTo(currentPosition)
                            },
                            valueRange = 0f..(totalDuration.toFloat().takeIf { it > 0f } ?: 1f),
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                        )
                        Text(formatTime(totalDuration), fontSize = 12.sp)
                    }
                }
            }

            // 文件输入位置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("文件输入位置", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = input1,
                        onValueChange = { input1 = it },
                        label = { Text("midi文件路径") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    OutlinedCard(onClick = { pickWavLauncher.launch(arrayOf("audio/*")) }) {
                        Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("添加或覆盖wav音效", fontSize = 12.sp, color = Color.Gray)
                            Text("(也可直接在 /Android/data/command.plus/files/note/ 下修改)", fontSize = 10.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(onClick = { pickWavLauncher.launch(arrayOf("audio/*")) }) {
                                Text("选择音频文件")
                            }
                        }
                    }
                }
            }

            // 文件输出位置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("文件输出位置", style = MaterialTheme.typography.titleMedium)
                    SimpleDropdown(
                        label = "输出类型",
                        items = listOf("内部路径", "外部路径"),
                        selectedIndex = outType,
                        onItemSelected = { outType = it }
                    )
                    if (outType == 1) {
                        OutlinedTextField(
                            value = extPath,
                            onValueChange = { extPath = it },
                            label = { Text("外部路径 (请输入一个输出的目录)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // 参数配置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("参数配置", style = MaterialTheme.typography.titleMedium)
                    
                    val paramLabels = listOf(
                        "游戏中一刻代表多少秒 (默认0.05)", "同刻最大连续量 (默认5)", 
                        "精度位数 (默认4)", "音调系数 (默认1,推荐0.5)", 
                        "音乐简化等级 (默认0,不超过5)"
                    )
                    
                    paramLabels.forEachIndexed { index, label ->
                        OutlinedTextField(
                            value = params[index],
                            onValueChange = { newText -> 
                                params = params.toMutableList().apply { this[index] = newText }
                            },
                            label = { Text(label) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    SimpleDropdown(
                        label = "音量模式",
                        items = listOf("模拟音量", "固定音量"),
                        selectedIndex = mode,
                        onItemSelected = { mode = it }
                    )
                    
                   
                }
            }

            // 指令配置
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("指令配置", style = MaterialTheme.typography.titleMedium)
                    
                    val cmdLabels = listOf("计分板名称 (默认t)", "单条字符上限 (默认10000)", "音乐相对起始点 (默认0)", "违禁数值 (用逗号分隔)")
                    cmdLabels.forEachIndexed { i, label ->
                        val actualIndex = i + 5
                        OutlinedTextField(
                            value = params[actualIndex],
                            onValueChange = { newText ->
                                params = params.toMutableList().apply { this[actualIndex] = newText }
                            },
                            label = { Text(label) },
                            keyboardOptions = if (i == 0 || i == 3) KeyboardOptions.Default else KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("是否保留同刻重复音", style = MaterialTheme.typography.titleMedium)
                        Switch(checked = stackEnabled, onCheckedChange = { stackEnabled = it })
                    }
                }
            }

            // Map 配置
            // 注意：这些组件的 onValueChange 会触发上面的 LaunchedEffect 自动保存

            // --- 动态列表部分：乐器及其音高 ---
            // =========================
// 3) UI 适配
// =========================

ElevatedCard(modifier = Modifier.fillMaxWidth()) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("乐器及其参数", style = MaterialTheme.typography.titleMedium)

        LazyColumn(modifier = Modifier.heightIn(max = 520.dp)) {
            items(
                items = instrumentList,
                key = { it.id }
            ) { item ->
                Box(modifier = Modifier.animateItem()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = item.def.name,
                                    onValueChange = { newName ->
                                        instrumentList = instrumentList.map {
                                            if (it.id == item.id) it.copy(
                                                def = it.def.copy(name = newName)
                                            ) else it
                                        }
                                    },
                                    label = { Text("name") },
                                    modifier = Modifier.weight(1f)
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                OutlinedTextField(
                                    value = item.def.basePitch.toString(),
                                    onValueChange = { newV ->
                                        val vInt = newV.toIntOrNull() ?: 0
                                        instrumentList = instrumentList.map {
                                            if (it.id == item.id) it.copy(
                                                def = it.def.copy(basePitch = vInt)
                                            ) else it
                                        }
                                    },
                                    label = { Text("basePitch") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.width(110.dp)
                                )

                                IconButton(onClick = {
                                    instrumentList = instrumentList.filter { it.id != item.id }
                                }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("isDrum", modifier = Modifier.width(72.dp))
                                Switch(
                                    checked = item.def.isDrum,
                                    onCheckedChange = { checked ->
                                        instrumentList = instrumentList.map {
                                            if (it.id == item.id) it.copy(
                                                def = it.def.copy(isDrum = checked)
                                            ) else it
                                        }
                                    }
                                )
                            }

                            OutlinedTextField(
    // 优先显示 Map 中的原始输入文本，如果没有则显示数据模型转换后的文本
    value = channelsTextMap[item.id] ?: intListToText(item.def.channels),
    onValueChange = { text ->
        // 同步更新原始文本缓存，确保逗号、空格能正常显示
        channelsTextMap[item.id] = text
        
        // 解析并更新后台数据模型
        val newList = parseIntList(text)
        instrumentList = instrumentList.map {
            if (it.id == item.id) it.copy(
                def = it.def.copy(channels = newList)
            ) else it
        }
    },
    label = { Text("channels（用逗号分隔）") },
    modifier = Modifier.fillMaxWidth()
)

                            OutlinedTextField(
    value = eventsTextMap[item.id] ?: intListToText(item.def.events),
    onValueChange = { text ->
        eventsTextMap[item.id] = text
        
        val newList = parseIntList(text)
        instrumentList = instrumentList.map {
            if (it.id == item.id) it.copy(
                def = it.def.copy(events = newList)
            ) else it
        }
    },
    label = { Text("events（用逗号分隔）") },
    modifier = Modifier.fillMaxWidth()
)
                        }
                    }
                }
            }
        }

        Button(onClick = {
            instrumentList = instrumentList + InstrumentItem(
                def = InstrumentDef(
                    channels = emptyList(),
                    events = emptyList(),
                    name = "new_inst",
                    basePitch = 0,
                    isDrum = false
                )
            )
        }) {
            Text("添加映射")
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

        OutlinedButton(
            onClick = { showResetDialog = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("重置所有配置")
        }
    }
}}}
    
if (showResetDialog) {
    AlertDialog(
        onDismissRequest = { showResetDialog = false },
        title = { Text("重置所有设置？") },
        text = { Text("这将重置所有文本框及映射。") },
        confirmButton = {
            TextButton(
                onClick = {
                    input1 = "input.mid"
                    params = List(8) { i -> getDefaultParam(i) }
                    instrumentList = defaultInstrumentMap().map { InstrumentItem(def = it) }
                    stackEnabled = true
                    outType = 0
                    mode = 0
                    extPath = "output"
                    showResetDialog = false
                }
            ) {
                Text("确定重置", color = Color.Red)
            }
        },
        dismissButton = {
            TextButton(onClick = { showResetDialog = false }) {
                Text("取消")
            }
        }
    )
}
}

// --- 辅助组件与函数 ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleDropdown(label: String, items: List<String>, selectedIndex: Int, onItemSelected: (Int) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = items.getOrElse(selectedIndex) { "" },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors(),
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            items.forEachIndexed { index, text ->
                DropdownMenuItem(
                    text = { Text(text) },
                    onClick = {
                        onItemSelected(index)
                        expanded = false
                    }
                )
            }
        }
    }
}

private fun getDefaultParam(i: Int) = when(i) {
    0 -> "0.05"; 1 -> "5"; 2 -> "4"; 3 -> "1"; 4 -> "0"; 5 -> "t"; 6 -> "10000"; 7 -> "0"; 8 -> "6489,8964" ; else -> ""
}

private fun queryName(context: Context, uri: Uri): String? {
    return context.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
    }
}

private fun formatTime(ms: Int): String {
    val s = ms / 1000
    return String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60)
}

private fun loadInstrumentMap(sp: SharedPreferences): List<InstrumentItem> {
    val json = sp.getString("map_sinfo", null) ?: return defaultInstrumentMap().map { InstrumentItem(def = it) }
    val list = mutableListOf<InstrumentItem>()

    try {
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)

            val channels = mutableListOf<Int>()
            val chArr = obj.optJSONArray("channels")
            if (chArr != null) {
                for (j in 0 until chArr.length()) channels.add(chArr.optInt(j))
            }

            val events = mutableListOf<Int>()
            val evArr = obj.optJSONArray("events")
            if (evArr != null) {
                for (j in 0 until evArr.length()) events.add(evArr.optInt(j))
            }

            list.add(
                InstrumentItem(
                    def = InstrumentDef(
                        channels = channels,
                        events = events,
                        name = obj.optString("name", ""),
                        basePitch = obj.optInt("basePitch", 0),
                        isDrum = obj.optBoolean("isDrum", false)
                    )
                )
            )
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return if (list.isEmpty()) defaultInstrumentMap().map { InstrumentItem(def = it) } else list
}

private fun saveInstrumentMap(sp: SharedPreferences, list: List<InstrumentItem>) {
    try {
        val arr = JSONArray()
        list.forEach { item ->
            val obj = JSONObject().apply {
                put("name", item.def.name)
                put("basePitch", item.def.basePitch)
                put("isDrum", item.def.isDrum)

                val chArr = JSONArray()
                item.def.channels.forEach { chArr.put(it) }
                put("channels", chArr)

                val evArr = JSONArray()
                item.def.events.forEach { evArr.put(it) }
                put("events", evArr)
            }
            arr.put(obj)
        }
        sp.edit().putString("map_sinfo", arr.toString()).apply()
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun parseIntList(text: String): List<Int> {
    return text
        .split(',', '，', ' ', ';', '|')
        .mapNotNull { it.trim().takeIf { s -> s.isNotEmpty() }?.toIntOrNull() }
}

private fun intListToText(list: List<Int>): String = list.joinToString(",")

private fun defaultInstrumentMap(): List<InstrumentDef> {
    return listOf(
    // --- 1. 常规乐器 (isDrum = false) ---
    // 根据 mapInstrument(ch, prg) 逻辑
    InstrumentDef(listOf(), (0..7).toList() + (40..47).toList(), "note.harp", 54, false), // 钢琴 & 弦乐
    InstrumentDef(listOf(), (8..15).toList(), "note.pling", 78, false),                  // 半音打击乐
    InstrumentDef(listOf(), (16..23).toList() + (64..79).toList(), "note.flute", 66, false), // 风琴、萨克斯、笛子
    InstrumentDef(listOf(), (24..31).toList(), "note.guitar", 42, false),                // 吉他
    InstrumentDef(listOf(), listOf(35, 38), "note.didgeridoo", 30, false),               // 特定贝斯
    InstrumentDef(listOf(), (32..34).toList() + listOf(36, 37, 39), "note.bass", 30, false), // 常规贝斯
    InstrumentDef(listOf(), (48..55).toList(), "note.chime", 78, false),                 // 合奏
    InstrumentDef(listOf(), (56..63).toList(), "npte.bell", 78, false),                  // 铜管
    InstrumentDef(listOf(), (80..87).toList(), "note.bit", 54, false),                    // 合成主音
    InstrumentDef(listOf(), (88..95).toList(), "note.iron_xylophone", 54, false),        // 合成柔板
    InstrumentDef(listOf(), listOf(105), "note.banjo", 54, false),                       // 班卓琴
    InstrumentDef(listOf(), (104..111).filter { it != 105 }, "note.didgeridoo", 30, false), // 其他民族乐器
    InstrumentDef(listOf(), (112..119).toList(), "note.xylophone", 78, false),           // 打击乐器

    // --- 2. 打击乐器 (isDrum = true, Channel 9) ---
    // 根据 mapDrumNote(note) 逻辑
    InstrumentDef(listOf(9), listOf(35, 36), "note.bd", 0, true),                        // 大鼓
    InstrumentDef(listOf(9), listOf(37, 38, 40), "note.snare", 0, true),                 // 军鼓
    InstrumentDef(listOf(9), listOf(42, 44), "note.bit", 0, true),                       // 闭合踏板 (bit)
    InstrumentDef(listOf(9), listOf(46), "note.pling", 0, true),                         // 开启踏板 (pling)
    InstrumentDef(listOf(9), listOf(41, 43, 45, 47, 48, 50), "note.bass", 0, true),      // 通通鼓 (bass)
    InstrumentDef(listOf(9), listOf(49, 51, 52, 55, 57), "note.chime", 0, true),         // 镲片 (chime)
    InstrumentDef(listOf(9), listOf(56), "note.cow_bell", 0, true),                      // 牛铃
    InstrumentDef(listOf(9), listOf(53), "note.xylophone", 0, true)                      // 叠音镲
)
}