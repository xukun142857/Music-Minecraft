package command.plus

import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files
import java.io.BufferedWriter
import java.io.IOException
import java.util.TreeSet

/**
 * 我的世界 Minecraft 盔甲架命令生成器
 * 已整合：
 * 1) 记分板相对起始点（startScoreOffset）
 * 2) 违禁数值处理（forbiddenScores）
 */
class McCommandGenerator private constructor(
    private val inputData: String,
    private val scoreboardObj: String,
    private val entityName: String,
    private val charLimit: Int,
    private val startLength: Int, // X
    private val startDepth: Int,   // Y
    private val startWidth: Int,   // Z
    private val mirrorHorizontal: Boolean,
    private val mirrorVertical: Boolean,
    private val innerAxis: Axis,
    private val innerStep: Int,
    private val outerAxis: Axis,
    private val outerStep: Int,
    private val startScoreOffset: Int,          // 新增：记分板相对起始点
    private val forbiddenScores: Set<Int>,      // 新增：违禁数值
    private val saveFile: File?,
    private val callback: (List<String>) -> Unit
) {

    // 坐标轴枚举
    enum class Axis { 长, 深, 宽 }

    private data class RangeResult(
        var selectorPart: String,
        val corrections: MutableList<Int> = mutableListOf()
    )

    private data class CommandNote(
        val time: Int,
        val inst: String,
        val pitch: String,
        val volume: String
    )

    fun generate() {
        try {
            var matrix = parseInput(inputData)
            if (matrix.isEmpty()) {
                callback(emptyList())
                return
            }

            matrix = applyMirror(matrix)
            val commands = generateCommands(matrix)

            saveFile?.let { file ->
                try {
                    file.parentFile?.mkdirs()
                    FileOutputStream(file).use { fos ->
                        commands.forEach { line ->
                            fos.write((line + "\n").toByteArray(Charsets.UTF_8))
                        }
                    }
                    println("文件已成功保存至: ${file.absolutePath}")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            callback(commands)
        } catch (e: Exception) {
            e.printStackTrace()
            callback(emptyList())
        }
    }

    private fun parseInput(data: String): List<List<String>> {
        val matrix = mutableListOf<List<String>>()
        val lines = data.lines()

        // 简单提取单引号或双引号内的方块 ID
        val regex = "'([^']*)'|\"([^\"]*)\"".toRegex()

        for (line in lines) {
            var cleanLine = line.trim()
            if (cleanLine.contains(".")) {
                cleanLine = cleanLine.substringAfter(".").trim()
            }
            if (cleanLine.isEmpty()) continue

            val row = regex.findAll(cleanLine).map {
                it.groupValues[1].ifEmpty { it.groupValues[2] }
            }.toList()

            if (row.isNotEmpty()) {
                matrix.add(row)
            }
        }
        return matrix
    }

    private fun applyMirror(matrix: List<List<String>>): List<List<String>> {
        var processed = matrix
        if (mirrorHorizontal) {
            processed = processed.map { it.reversed() }
        }
        if (mirrorVertical) {
            processed = processed.reversed()
        }
        return processed
    }

    private fun getConsecutiveRanges(numbers: List<Int>): List<String> {
        if (numbers.isEmpty()) return emptyList()
        val sorted = numbers.distinct().sorted()
        val ranges = mutableListOf<String>()
        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val x = sorted[i]
            if (x == prev + 1) {
                prev = x
            } else {
                ranges.add(if (start == prev) "$start" else "$start..$prev")
                start = x
                prev = x
            }
        }
        ranges.add(if (start == prev) "$start" else "$start..$prev")
        return ranges
    }

    /**
     * 参考 Java 逻辑：对一个连续范围做“安全化”处理。
     * - 起点/终点若落在违禁值上，则向外扩一格
     * - 若扩展出来的补丁点不在原始链内，则记录到 corrections
     */
    private fun getSafeRange(start: Int, end: Int, allTimesInChain: Set<Int>): RangeResult {
        var finalStart = start
        var finalEnd = end
        val res = RangeResult(selectorPart = "")

        if (forbiddenScores.contains(start) && !isConsecutiveForbidden(start)) {
            finalStart = start - 1
            if (!allTimesInChain.contains(finalStart)) {
                res.corrections.add(finalStart)
            }
        }

        if (forbiddenScores.contains(end) && !isConsecutiveForbidden(end)) {
            finalEnd = end + 1
            if (!allTimesInChain.contains(finalEnd)) {
                res.corrections.add(finalEnd)
            }
        }

        res.selectorPart = if (finalStart == finalEnd) {
            "$scoreboardObj=!$finalStart"
        } else {
            "$scoreboardObj=!$finalStart..$finalEnd"
        }
        return res
    }

    /**
     * 判断某个违禁值是否与另一个违禁值相邻。
     */
    private fun isConsecutiveForbidden(valNum: Int): Boolean {
        return forbiddenScores.contains(valNum - 1) || forbiddenScores.contains(valNum + 1)
    }

    /**
     * 把一组分数整理成安全范围（同时保留 corrections）。
     */
    private fun buildSafeRanges(numbers: List<Int>): List<RangeResult> {
        if (numbers.isEmpty()) return emptyList()

        val sorted = numbers.distinct().sorted()
        val allTimesInChain = sorted.toSet()
        val results = mutableListOf<RangeResult>()

        var start = sorted[0]
        var prev = sorted[0]

        for (i in 1 until sorted.size) {
            val cur = sorted[i]
            if (cur != prev + 1) {
                results.add(getSafeRange(start, prev, allTimesInChain))
                start = cur
            }
            prev = cur
        }
        results.add(getSafeRange(start, prev, allTimesInChain))
        return results
    }

    /**
     * 生成一个 setblock 指令块，内部会自动做：
     * - 连续范围压缩
     * - 违禁数值安全处理
     * - 字符长度拆分
     */
    private fun buildSetblockCommands(blockId: String, scores: List<Int>): List<String> {
        val rangeResults = buildSafeRanges(scores)
        if (rangeResults.isEmpty()) return emptyList()

        val cmds = mutableListOf<String>()
        val currentSelectors = mutableListOf<String>()
        val currentCorrections = TreeSet<Int>()

        val prefix = "/execute as @e[name=\"$entityName\"] at @s unless entity @s[scores={"
        val suffixStart = "}]"
        val runPart = " run setblock ~ ~ ~ $blockId"

        val baseLen = prefix.length + suffixStart.length + runPart.length + 10
        var currentLen = baseLen

        for (rr in rangeResults) {
            val partLen = rr.selectorPart.length + 1 // 逗号
            var correctionExtraLen = 0

            for (c in rr.corrections) {
                if (!currentCorrections.contains(c)) {
                    correctionExtraLen += (scoreboardObj.length + c.toString().length + 2)
                }
            }

            if (currentCorrections.isEmpty() && rr.corrections.isNotEmpty()) {
                correctionExtraLen += 30
            }

            if (charLimit > 0 && currentLen + partLen + correctionExtraLen > charLimit) {
                flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
                currentSelectors.clear()
                currentCorrections.clear()
                currentLen = baseLen
            }

            currentSelectors.add(rr.selectorPart)
            currentCorrections.addAll(rr.corrections)
            currentLen += (partLen + correctionExtraLen)
        }

        flushSetblockCommand(cmds, currentSelectors, currentCorrections, blockId)
        return cmds
    }

    private fun flushSetblockCommand(
        out: MutableList<String>,
        selectors: List<String>,
        corrections: Set<Int>,
        blockId: String
    ) {
        if (selectors.isEmpty()) return

        val sb = StringBuilder()
        sb.append("/execute as @e[name=\"")
            .append(entityName)
            .append("\"] at @s unless entity @s[scores={")
            .append(selectors.joinToString(","))
            .append("}]")

        if (corrections.isNotEmpty()) {
            sb.append(" unless entity @s[scores={")
            var count = 0
            for (c in corrections) {
                sb.append(scoreboardObj).append("=").append(c)
                count++
                if (count < corrections.size) sb.append(",")
            }
            sb.append("}]")
        }

        sb.append(" run setblock ~ ~ ~ ").append(blockId)
        out.add(sb.toString())
    }

    private fun generateCommands(matrix: List<List<String>>): List<String> {
        val cmds = mutableListOf<String>()

        val flatBlocks = mutableListOf<String>()
        val rowEndIndices = mutableListOf<Int>()
        var currentCount = 0

        for (row in matrix) {
            currentCount += row.size
            rowEndIndices.add(currentCount)
            flatBlocks.addAll(row)
        }

        val totalBlocks = flatBlocks.size
        if (totalBlocks == 0) return emptyList()

        // ===== 初始化指令 =====
        cmds.add("### 初始化指令 ###")
        cmds.add("$0,0,0")
        cmds.add("/scoreboard objectives add $scoreboardObj dummy")
        cmds.add("$")

        // 记分板相对起始点：从 startScoreOffset + 1 开始
        cmds.add("$1,0,1")
        cmds.add("/summon armor_stand $startLength $startDepth $startWidth ~ ~ . $entityName")
        cmds.add("/execute as @e[name=\"$entityName\"] run scoreboard players set @s $scoreboardObj ${startScoreOffset + 1}")
        cmds.add("$")
        cmds.add("")

        // ===== 循环指令链 =====
        cmds.add("### 循环命令链 ###")
        cmds.add("$2,0,0")

        // totalBlocks 个方块后，下一次进入循环就该清理实体
        cmds.add("/kill @e[name=\"$entityName\",scores={$scoreboardObj=${startScoreOffset + totalBlocks + 1}}]")
        cmds.add("$")

        cmds.add("$1,0,1")

        // 换行逻辑：到达每一行末尾后，提前切换到下一行
        val jumpScores = rowEndIndices.dropLast(1).map { startScoreOffset + it + 1}
        if (jumpScores.isNotEmpty()) {
            val jumpRanges = getConsecutiveRanges(jumpScores)
            val scoreSelector = jumpRanges.joinToString(",") { "$scoreboardObj=!$it" }

            val xyzMap = mapOf(Axis.长 to 0, Axis.深 to 1, Axis.宽 to 2)
            val tpCoords = arrayOf("~", "~", "~")

            // 内轴回到绝对起始点
            when (innerAxis) {
                Axis.长 -> tpCoords[0] = startLength.toString()
                Axis.深 -> tpCoords[1] = startDepth.toString()
                Axis.宽 -> tpCoords[2] = startWidth.toString()
            }

            // 外轴相对位移
            val idxOuter = xyzMap[outerAxis]!!
            tpCoords[idxOuter] = "~$outerStep"

            val tpStr = tpCoords.joinToString(" ")
            cmds.add("/execute as @e[name=\"$entityName\"] at @s unless entity @s[scores={$scoreSelector}] run tp $tpStr")
        }

        // 放置方块：按 blockId 分组
        val blockMap = mutableMapOf<String, MutableList<Int>>()
        flatBlocks.forEachIndexed { i, blockId ->
            val score = startScoreOffset + i + 1
            blockMap.getOrPut(blockId) { mutableListOf() }.add(score)
        }

        for ((blockId, scores) in blockMap) {
            cmds.addAll(buildSetblockCommands(blockId, scores))
        }

        // 步进：内轴移动 + 记分板加 1
        val xyzMap = mapOf(Axis.长 to 0, Axis.深 to 1, Axis.宽 to 2)
        val stepCoords = arrayOf("~", "~", "~")
        stepCoords[xyzMap[innerAxis]!!] = "~$innerStep"
        val stepTpStr = stepCoords.joinToString(" ")

        cmds.add("/execute as @e[name=\"$entityName\"] at @s run tp $stepTpStr")
        cmds.add("/execute as @e[name=\"$entityName\"] run scoreboard players add @s $scoreboardObj 1")
        cmds.add("$")

        return cmds
    }

    // Builder 设计模式实现
    class Builder {
        private var saveFile: File? = null
        private var inputData: String = ""
        private var scoreboardObj: String = "n"
        private var entityName: String = "C"
        private var charLimit: Int = 10000
        private var startLength: Int = 0
        private var startDepth: Int = 0
        private var startWidth: Int = 0
        private var mirrorHorizontal: Boolean = false
        private var mirrorVertical: Boolean = false

        private var innerAxis: Axis = Axis.长
        private var innerStep: Int = 1
        private var outerAxis: Axis = Axis.宽
        private var outerStep: Int = 1

        // 新增
        private var startScoreOffset: Int = 1
        private var forbiddenScores: Set<Int> = emptySet()

        private var callback: ((List<String>) -> Unit)? = null

        fun setInputData(data: String) = apply { this.inputData = data }
        fun setScoreboardObj(obj: String) = apply { this.scoreboardObj = obj }
        fun setEntityName(name: String) = apply { this.entityName = name }
        fun setCharLimit(limit: Int) = apply { this.charLimit = limit }

        fun setStartCoords(长: Int, 深: Int, 宽: Int) = apply {
            this.startLength = 长
            this.startDepth = 深
            this.startWidth = 宽
        }

        fun setMirror(horizontal: Boolean, vertical: Boolean) = apply {
            this.mirrorHorizontal = horizontal
            this.mirrorVertical = vertical
        }

        fun setAxisConfig(innerAxis: Axis, innerStep: Int, outerAxis: Axis, outerStep: Int) = apply {
            require(innerAxis != outerAxis) { "内部行进轴和换行轴不能是同一个！" }
            this.innerAxis = innerAxis
            this.innerStep = innerStep
            this.outerAxis = outerAxis
            this.outerStep = outerStep
        }

        // 新增：记分板起始偏移
        fun setStartScoreOffset(offset: Int) = apply {
            this.startScoreOffset = offset
        }

        // 新增：违禁数值
        fun setForbiddenScores(values: Set<Int>) = apply {
            this.forbiddenScores = values.toSet()
        }

        fun setCallback(callback: (List<String>) -> Unit) = apply {
            this.callback = callback
        }

        fun setOutputFile(path: String) = apply {
            this.saveFile = File(path)
        }

        fun setOutputFile(file: File) = apply {
            this.saveFile = file
        }

        fun build(): McCommandGenerator {
            requireNotNull(callback) { "必须设置 Callback" }
            return McCommandGenerator(
                inputData = inputData,
                scoreboardObj = scoreboardObj,
                entityName = entityName,
                charLimit = charLimit,
                startLength = startLength,
                startDepth = startDepth,
                startWidth = startWidth,
                mirrorHorizontal = mirrorHorizontal,
                mirrorVertical = mirrorVertical,
                innerAxis = innerAxis,
                innerStep = innerStep,
                outerAxis = outerAxis,
                outerStep = outerStep,
                startScoreOffset = startScoreOffset,
                forbiddenScores = forbiddenScores,
                saveFile = saveFile,
                callback = callback!!
            )
        }
    }
}